#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "rtp.h"

/* GIVEN Function:
 * Handles creating the client's socket and determining the correct
 * information to communicate to the remote server
 */
CONN_INFO* setup_socket(char *ip, char *port){
	struct addrinfo *connections, *conn = NULL;
	struct addrinfo info;
	memset(&info, 0, sizeof(struct addrinfo));
	int sock = 0;

	info.ai_family = AF_INET;
	info.ai_socktype = SOCK_DGRAM;
	info.ai_protocol = IPPROTO_UDP;
	getaddrinfo(ip, port, &info, &connections);

	/*for loop to determine corr addr info*/
	for(conn = connections; conn != NULL; conn = conn->ai_next){
		sock = socket(conn->ai_family, conn->ai_socktype, conn->ai_protocol);
		if (sock <0) {
			#ifdef DEBUG
				perror("Failed to create socket\n");
			#endif
			continue;
		}
		#ifdef DEBUG
			printf("Created a socket to use.\n");
		#endif
		break;
	}
	if(conn == NULL){
		perror("Failed to find and bind a socket\n");
		return NULL;
	}
	CONN_INFO* conn_info = malloc(sizeof(CONN_INFO));
	conn_info->socket = sock;
	conn_info->remote_addr = conn->ai_addr;
	conn_info->addrlen = conn->ai_addrlen;
	return conn_info;
}

void shutdown_socket(CONN_INFO *connection){
	if(connection)
		close(connection->socket);
}

/* 
 * ===========================================================================
 *
 *			STUDENT CODE STARTS HERE. PLEASE COMPLETE ALL FIXMES
 *
 * ===========================================================================
*/


/*
 *  Returns a number computed based on the data in the buffer.
*/
static int checksum(const char *buffer, int length){

	/*  ----  FIXME  ----
	 *
	 *  The goal is to return a number that is determined by the contents
	 *  of the buffer passed in as a parameter.  There a multitude of ways
	 *  to implement this function.  For simplicity, simply sum the ascii
	 *  values of all the characters in the buffer, and return the total.
	*/
	/* this will be the total value of the data in the buffer */
	int buffer_total =  0;
	/* this will for loop through the length of the buffer */
	for(int i = 0; i < length; i++){
		/* this gets the ascii value of the character at the index */
		int ascii_value = buffer[i];
		/* this adds that ascii value to the rolling sum */
		buffer_total = buffer_total + ascii_value;
	}
	/* returns the rollinng sum of the value inside the buffer */
	return buffer_total;
}

/*
 *  Converts the given buffer into an array of PACKETs and returns
 *  the array.  The value of (*count) should be updated so that it 
 *  contains the length of the array created.
 */
static PACKET* packetize(const char *buffer, int length, int *count){

	/*  ----  FIXME  ----
	 *  The goal is to turn the buffer into an array of packets.
	 *  You should allocate the space for an array of packets and
	 *  return a pointer to the first element in that array.  Each 
	 *  packet's type should be set to DATA except the last, as it 
	 *  should be LAST_DATA type. The integer pointed to by 'count' 
	 *  should be updated to indicate the number of packets in the 
	 *  array.
	*/
	/* Buffer is the data that needs to be converted into packets and sent */
	/* length is the length of the buffer, ie the number of characters in it*/
	/* count will be the length of the array created */

	/* Max_Payload_length is the maximum length of characters that */
	/* can be in a packet so dividing the total number of characters by */
	/* it, gives you the number of packets you will use*/
	int number_of_packets_being_sent = length/MAX_PAYLOAD_LENGTH;
	/* howevor if the length of the buffer does not fit evenly into the */
	/* number of packets, which you can find by doing the mod and seeing if */
	/* there is any remainder, then you need to add one additional packet */
	if ( length % MAX_PAYLOAD_LENGTH != 0){
		number_of_packets_being_sent = number_of_packets_being_sent + 1;
	}
	/* now that you know the number of packets being sent you need to allocate */
	/* space for the contents of the packets, which can be done by using malloc */
	/* on the size of a packet multiplied by the number of packets in the array */
	PACKET *array_of_packets = malloc(sizeof(PACKET) * number_of_packets_being_sent);
	/* now to iterate through the array and assign each one of the packets *
	/* and sets their type to DATA */
	for(int packet_index = 0; packet_index < number_of_packets_being_sent; packet_index++) {
		int payload_index = MAX_PAYLOAD_LENGTH * (packet_index + 1);
		if (payload_index < length) {
			array_of_packets[packet_index].payload_length = MAX_PAYLOAD_LENGTH;
			array_of_packets[packet_index].type = DATA; 
		} else {
			int other_payload_index = MAX_PAYLOAD_LENGTH*packet_index;
			array_of_packets[packet_index].payload_length = length - other_payload_index;
			array_of_packets[packet_index].type = LAST_DATA;
	}
		/* now to actually put the contents of the buffer inside each of thier */
		/* respective packets */
		for (int buffer_index = 0; buffer_index < array_of_packets[packet_index].payload_length; buffer_index++) {
			/* to get the starting point of what from the buffer is going into */
			/* the packet we simply multiply MAX_PAYLOAD_LENGTH*i */
			int where_a_new_packet_starts_in_buffer = MAX_PAYLOAD_LENGTH * packet_index;
			/* we can now add the starting point with the buffer index to get the next character */
			/* to put in the packets payload */
			int character_to_put_in_payload = where_a_new_packet_starts_in_buffer + buffer_index;
			/* this puts that character innto the payload */
			array_of_packets[packet_index].payload[buffer_index] = buffer[character_to_put_in_payload];
			}
			/* this determines and assignes the checksum value for the packet so that if any */
			/* information is lost it can quickly by determined by seeing if there is a missmatch *
			/* in the expected size of the packet */
			int checksum_value = checksum(
				array_of_packets[packet_index].payload,
				array_of_packets[packet_index].payload_length);
		array_of_packets[packet_index].checksum = checksum_value;
	}
	/*updates count so that its the number of packets in the array. */
	*count = number_of_packets_being_sent;
	/* returns the array of packets */
	return array_of_packets;

}

/*
 * Send a message via RTP using the connection information
 * given on UDP socket functions sendto() and recvfrom()
 */
int rtp_send_message(CONN_INFO *connection, MESSAGE *msg){
	/* ---- FIXME ----
	 * The goal of this function is to turn the message buffer
	 * into packets and then, using stop-n-wait RTP protocol,
	 * send the packets and re-send if the response is a NACK.
	 * If the response is an ACK, then you may send the next one
	*/
	/* this allocates the space for the count pointer */
	/* which holdes the size of the array */
	int *count = malloc(sizeof(int));
	/*gets the length of the message */
	int length = msg -> length;
	/* gets the characters buffer from the message */
	char *buffer = msg-> buffer;
	PACKET *packet_array = packetize(buffer,length,count);
	/* creates a pointer for the response packet */
	PACKET* response_packet = malloc(sizeof(PACKET));
	/*loops through the whole packet array, using count as length */
	for (int i = 0; i < *count; i++){
	/*sends the packet to the connection socket */
	sendto(
		(*connection).socket, 
		&packet_array[i],
		sizeof(PACKET),
		0,
		(*connection).remote_addr,
		(*connection).addrlen);
	/* gets the response packet back from the connection socket */
	recvfrom(
		(*connection).socket,
		response_packet,
		sizeof(PACKET),
		0,
		(*connection).remote_addr,
		&connection->addrlen );
		
		//If the packet was failed to send we simply keep sending it till it successedes
		while (response_packet->type == NACK){
					sendto(
						connection->socket, 
						&packet_array[i],
						sizeof(PACKET),
						0,
						(*connection).remote_addr,
						(*connection).addrlen);

					recvfrom(
						(*connection).socket,
						response_packet,
						sizeof(PACKET),
						0,
						(*connection).remote_addr,
						&connection->addrlen );
			}
		}
	return 1;
}

/*
 * Receive a message via RTP using the connection information
 * given on UDP socket functions sendto() and recvfrom()
 */
MESSAGE* rtp_receive_message(CONN_INFO *connection){
	/* ---- FIXME ----
	 * The goal of this function is to handle 
	 * receiving a message from the remote server using
	 * recvfrom and the connection info given. You must 
	 * dynamically resize a buffer as you receive a packet
	 * and only add it to the message if the data is considered
	 * valid. The function should return the full message, so it
	 * must continue receiving packets and sending response 
	 * ACK/NACK packets until a LAST_DATA packet is successfully 
	 * received.
	*/
	
	PACKET *response_packet = malloc(sizeof(PACKET));
	PACKET *package = malloc(sizeof(PACKET));
	MESSAGE *message = malloc(sizeof(MESSAGE));
	(*message).length = 0;
	do {
	recvfrom((*connection).socket, package, sizeof(PACKET), 0, (*connection).remote_addr, &connection->addrlen);
	if (checksum((*package).payload,(*package).payload_length)==(*package).checksum) {
		(*response_packet).type=ACK;
		sendto((*connection).socket, response_packet, sizeof(PACKET),0,(*connection).remote_addr,(*connection).addrlen);
		char* part = malloc(((*package).payload_length + message->length)*sizeof(char));
			int i = 0;
			while(i < (*message).length){
				part[i] = (*message).buffer[i];
				i++;
			}
			i = 0;
			while(i < (*package).payload_length) {
				part[i + (*message).length] = package->payload[i];
				i++;
			}
			(*message).buffer = part;
			(*message).length = (*message).length + (*package).payload_length;
	} else {
		(*response_packet).type = NACK;
		sendto((*connection).socket, response_packet, sizeof(PACKET),0,(*connection).remote_addr,(*connection).addrlen);
		continue;
	}}
	while ((*response_packet).type!=ACK || (*package).type!=LAST_DATA );
	return message;
}

