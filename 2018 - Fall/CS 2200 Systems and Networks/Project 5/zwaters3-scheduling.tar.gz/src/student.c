/*
 * student.c
 * Multithreaded OS Simulation for CS 2200
 *
 * This file contains the CPU scheduler for the simulation.
 */

#include <assert.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

#include "os-sim.h"

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-parameter"

/** Function prototypes **/
extern void idle(unsigned int cpu_id);
extern void preempt(unsigned int cpu_id);
extern void yield(unsigned int cpu_id);
extern void terminate(unsigned int cpu_id);
extern void wake_up(pcb_t *process);

/** Function Prototypes for Helper Methods */
void add_to_ready_queue(pcb_t* process_to_add);
pcb_t* get_fifo_process(void);
pcb_t* get_rr_process(void);
pcb_t* get_srtf_process(void);

/*
 * current[] is an array of pointers to the currently running processes.
 * There is one array element corresponding to each CPU in the simulation.
 *
 * current[] should be updated by schedule() each time a process is scheduled
 * on a CPU.  Since the current[] array is accessed by multiple threads, you
 * will need to use a mutex to protect it.  current_mutex has been provided
 * for your use.
 */
static pcb_t **current;
static pthread_mutex_t current_mutex;

/* head of ready queue */
static pcb_t *ready_queue_head;

/* the mutex for the ready queue */
static pthread_mutex_t ready_queue_mutex;

/* condition variable for idle function */
static pthread_cond_t idle_condition;

/* the time slice used in round robin */
static int quantum;

/* the number of cpus in use, 1,2, or 4 */
static int number_of_cpus;

/*the kind of algorithm currently being run 1=FIFO,2=ROUND ROBIN, 3=SRTF */
static int scheduler_algorithm;



/*
 * schedule() is your CPU scheduler.  It should perform the following tasks:
 *
 *   1. Select and remove a runnable process from your ready queue which 
 *	you will have to implement with a linked list or something of the sort.
 *
 *   2. Set the process state to RUNNING
 *
 *   3. Call context_switch(), to tell the simulator which process to execute
 *      next on the CPU.  If no process is runnable, call context_switch()
 *      with a pointer to NULL to select the idle process.
 *	The current array (see above) is how you access the currently running process indexed by the cpu id. 
 *	See above for full description.
 *	context_switch() is prototyped in os-sim.h. Look there for more information 
 *	about it and its parameters.
 */
static void schedule(unsigned int cpu_id)
{
    /* Locks the ready queue of processes waiting to run */
    /* to prevent other threads from interfering */
    pthread_mutex_lock(&ready_queue_mutex);
    /* this is process that our algorithm will select */
    /* from the ready queue  */
    pcb_t* selected_process;
    /* this determines what algorithm is used to select  */
    /* the process from the ready queue  */
    if (scheduler_algorithm == 1) { 
        /*the FIFO algorithm */
        selected_process = get_fifo_process();
    } else if(scheduler_algorithm == 2) {
        /*the ROUND ROBIN algorithm */
        selected_process = get_rr_process();
    } else {
        /*the SRTF algorithm */
        selected_process = get_srtf_process();
    }
    /* Unlocks the ready queue of processes waiting to run */
    /* so other threads can now do what they want */ 
    pthread_mutex_unlock(&ready_queue_mutex);

    /* If the process we got was not null, meaning that */
    /* the ready queue was not empty */
    if(selected_process != NULL) {
        /* sets the state of the selected process to running */
        /* which means the process assigned to the cpu */
        selected_process->state = PROCESS_RUNNING;
        /* Locks the queue of currently running processes */
        /* to prevent other threads from interfering */ 
        pthread_mutex_lock(&current_mutex);
        /* sets the current cpu_id equal to the selected process */
        /* so that its clear what process that cpu is running */
        current[cpu_id] = selected_process;
        /* Unlocks the queue of currently running processes */
        /* so other threads can now do what they want */
        pthread_mutex_unlock(&current_mutex);
        /* we call context switch to tell the simulator what  */
        /* process to execute next on the selected cpu */
        /* cpu_id : the # of the CPU on which to execute the process */
        /* pcb : a pointer to the process's PCB */
        /* time_slice : an integer containing the time slice to allocate to the */
        /* process (in ticks--1/10th sec.).  Use -1 to give a process an */
        /* infinite time slice (for FIFO and SRTF scheduling). */
        context_switch(cpu_id, selected_process, quantum);
    }     
    /* else, otherwise the process we got was null, meaning that */
    /* the ready queue was  empty */
    else {
        /* Locks the queue of currently running processes */
        /* to prevent other threads from interfering */ 
        pthread_mutex_lock(&current_mutex);
        /* sets the current cpu_id equal to NULL */
        /* so that its clear that the cpu is empty and just idling */
        current[cpu_id] = NULL;
        /* Unlocks the queue of currently running processes */
        /* so other threads can now do what they want */
        pthread_mutex_unlock(&current_mutex);
        /* We call context switch with NULL for the process */
        /* this causes the CPU to select the idle process */
        context_switch(cpu_id, NULL, quantum);
    }
}


/*
 * idle() is your idle process.  It is called by the simulator when the idle
 * process is scheduled.
 *
 * This function should block until a process is added to your ready queue.
 * It should then call schedule() to select the process to run on the CPU.
 */
extern void idle(unsigned int cpu_id)
{
    /* Locks the ready queue of processes waiting to run */
    /* to prevent other threads from interfering */ 
    pthread_mutex_lock(&ready_queue_mutex);
    /* While the ready queue is empty,meaning there are no */
    /* processes that want to be run,*/
    while(ready_queue_head == NULL) {
        /* atomically unlocks the ready_queue_mutex and waits for */
        /* the conditional variable, idle_condition, to be signalled */
        /* While waiting The thread execution is suspended and does */
        /* not consume any CPU time until the condition variable is signalled */
        pthread_cond_wait(&idle_condition, &ready_queue_mutex);
    }
    /* Once you Leave the while loop that means a new process */
    /* has just arrived in the ready queue and is ready to be scheduled */

    /* Unlocks the ready queue of processes waiting to run */
    /* so other threads can now do what they want */ 
    pthread_mutex_unlock(&ready_queue_mutex);
   /* calls schedule() to select a new process for the cpu*/
   /* we use the same cpu_id because thats the cpu that is now empty */ 
    schedule(cpu_id);
    /*
     * REMOVE THE LINE BELOW AFTER IMPLEMENTING IDLE()
     *
     * idle() must block when the ready queue is empty, or else the CPU threads
     * will spin in a loop.  Until a ready queue is implemented, we'll put the
     * thread to sleep to keep it from consuming 100% of the CPU time.  Once
     * you implement a proper idle() function using a condition variable,
     * remove the call to mt_safe_usleep() below.
     *
     * mt_safe_usleep(1000000);
     */
}


/*
 * preempt() is the handler called by the simulator when a process is
 * preempted due to its timeslice expiring.
 *
 * This function should place the currently running process back in the
 * ready queue, and call schedule() to select a new runnable process.
 *
 * Remember to set the status of the process to the proper value.
 */
extern void preempt(unsigned int cpu_id)
{
    /* is getting the preempted process that  */
    /* corosponds to the CPU_id */
    pcb_t* expired_process = current[cpu_id];
    /* sets the value of the preempted process to PROCESS_READY */
    /* so that the scheduler knows its ready to run again */
    expired_process -> state = PROCESS_READY;
    /* adds the preempted process back to the ready queue */
    add_to_ready_queue(expired_process);
    /* calls schedule() to select a new process for the cpu*/
    /* we use the same cpu_id because thats the cpu that is now empty */ 
    schedule(cpu_id);
}


/*
 * yield() is the handler called by the simulator when a process yields the
 * CPU to perform an I/O request.
 *
 * It should mark the process as WAITING, then call schedule() to select
 * a new process for the CPU.
 */
extern void yield(unsigned int cpu_id)
{
   /* Locks the queue of currently running processes */
   /* to prevent other threads from interfering */ 
   pthread_mutex_lock(&current_mutex); 
   /* Gets the process that wants to perform an I/O request */
   /* does so by entering the given cpu_id which is the number*/
   /* of the cpu that the process is currently running on */ 
   pcb_t *io_requesting_process = current[cpu_id];
   /* Sets the requesting process's state to waiting */
   /* which means the process is waiting to be assigned to the I/O */
   io_requesting_process->state = PROCESS_WAITING;
   /* Unlocks the queue of currently running processes */
   /* so other threads can now do what they want */ 
   pthread_mutex_unlock(&current_mutex);
   /* calls schedule() to select a new process for the cpu*/
   /* we use the same cpu_id because thats the cpu that is now empty */ 
   schedule(cpu_id);
}


/*
 * terminate() is the handler called by the simulator when a process completes.
 * It should mark the process as terminated, then call schedule() to select
 * a new process for the CPU.
 */
extern void terminate(unsigned int cpu_id)
{
    /* Locks the queue of currently running processes */
    /* to prevent other threads from interfering */ 
    pthread_mutex_lock(&current_mutex); 
    /* Gets the process that just completed */
    /* does so by entering the given cpu_id which is the number*/
    /* of the cpu that the process is currently running on */ 
    pcb_t *completed_process = current[cpu_id];
    /* Sets the requesting process's state to terminated */
    /* which means the process is completed */
    completed_process->state = PROCESS_TERMINATED;
    /* Unlocks the queue of currently running processes */
    /* so other threads can now do what they want */ 
    pthread_mutex_unlock(&current_mutex);
    /* calls schedule() to select a new process for the cpu*/
    /* we use the same cpu_id because thats the cpu that is now empty */ 
    schedule(cpu_id);
}


/*
 * wake_up() is the handler called by the simulator when a process's I/O
 * request completes.  It should perform the following tasks:
 *
 *   1. Mark the process as READY, and insert it into the ready queue.
 *
 *   2. If the scheduling algorithm is SRTF, wake_up() may need
 *      to preempt the CPU with the highest remaining time left to allow it to
 *      execute the process which just woke up.  However, if any CPU is
 *      currently running idle, or all of the CPUs are running processes
 *      with a lower remaining time left than the one which just woke up, wake_up()
 *      should not preempt any CPUs.
 *	To preempt a process, use force_preempt(). Look in os-sim.h for 
 * 	its prototype and the parameters it takes in.
 */
extern void wake_up(pcb_t *process)
{
    /* marks the process that completed its I/O as READY */
    process -> state = PROCESS_READY;
    /* adds the ready process back to the ready queue */
    add_to_ready_queue(process);
    /* checks if the current algorithm is SRTF */
    if (scheduler_algorithm == 3) {
        /* Locks the queue of currently running processes */
        /* to prevent other threads from interfering */ 
        pthread_mutex_lock(&current_mutex);
        int i = 0;
        int brakes = -1;
        unsigned int maximum_time = process->time_remaining;
        int id_of_preening_process = -1;
        while(i < number_of_cpus && brakes < 0) {
            pcb_t* potential_maximum_process = current[i];
            if (potential_maximum_process == NULL) {
                brakes = 1;
            } 
            else {
                unsigned int process_time = potential_maximum_process -> time_remaining;
                if(process_time > maximum_time) {
                    maximum_time = process_time;
                    id_of_preening_process = i;
                    }
                i++;
            } 
        }
        /* Unlocks the queue of currently running processes */
        /* so other threads can now do what they want */ 
        pthread_mutex_unlock(&current_mutex);
        if (brakes != -1 && id_of_preening_process != -1) {
            force_preempt(id_of_preening_process);
        }

    }
}

/* this is a helper method that adds a process to the ready queue */
void add_to_ready_queue(pcb_t* process_to_add)
{
    /* Sets the next pointer of this process to NULL */
    /* in the ready queue, because its being added to the back of the queue */
    process_to_add->next = NULL;
    /* If the ready_queue is empty, checked by seeing if the head */
    /* pointer is pointing to null, */
    if (ready_queue_head == NULL) {
        /* then the ready queue is just filled with */
        /* the prcocess to be added, by setting the head equal to it */
        ready_queue_head = process_to_add;
    } 
    /* otherwise the ready_queue is not empty */
    else {
        /* this means we have to find the end of the ready queue */
        /* which we do by using a iterator in a while loop that  */
        /* continues till it finds the next value is equal to NULL */
        pcb_t* iterator = ready_queue_head;
        while (iterator -> next != NULL) {
            iterator = iterator -> next;
        }
        /* now that the iterator is at the end of the array we just */
        /* set it equal to the process to be added */
        iterator -> next = process_to_add;
    }
    /* we now send a control signal that would stop the idle process */
    pthread_cond_signal(&idle_condition);
}

/* this is a helper method that gets the next process to run  using FIFO*/
pcb_t* get_fifo_process() {
    /* if the ready queue is empty return null */
    if (ready_queue_head == NULL) {
        return NULL;
    } 
    /* otherwise return the first value of the queue */
    /* and remove it from the queue, and then move the  */
    /* head pointer to the remainder of the queue */
    else {
        pcb_t* first_process = ready_queue_head;
        ready_queue_head = ready_queue_head -> next;
        return first_process;
    }
}

/* this is a helper method that gets the next process to run  using RR*/
pcb_t* get_rr_process() {
    /* if the ready queue is empty return null */
    if (ready_queue_head == NULL) {
        return NULL;
    } 
    /* otherwise return the first value of the queue */
    /* and remove it from the queue, and then move the  */
    /* head pointer to the remainder of the queue */
    else {
        pcb_t* first_process = ready_queue_head;
        ready_queue_head = ready_queue_head -> next;
        return first_process;
    }
}

/* this is a helper method that gets the next process to run  using SRTF*/
pcb_t* get_srtf_process() {
    /* if the ready queue is empty return null */
    if (ready_queue_head == NULL) {
        return NULL;
    } 
    /* this means we have to loop through to the end of the ready */
    /* queue which we do by using a iterator in a while loop  */
    /* while keeping track of the minimum value */
    else {
        pcb_t* iterator = ready_queue_head;
        pcb_t* minimum_process = ready_queue_head;
        unsigned int minimum_process_time = minimum_process -> time_remaining;
        while (iterator -> next != NULL) {
        unsigned int comparison = iterator -> time_remaining;
            if(comparison < minimum_process_time){
                minimum_process = iterator;
            }
            iterator = iterator -> next;
        }
        //now to remove the minimum process from the ready queue */
        if(ready_queue_head -> pid == minimum_process->pid) {
            ready_queue_head = ready_queue_head -> next;
        } else {
            pcb_t* iterator2 = ready_queue_head;
            while (iterator2 -> next -> pid != minimum_process->pid) {
                iterator2 = iterator2 -> next;
            }
        iterator2 -> next = minimum_process -> next;
        }
        //returning the minimum_process
        return minimum_process;
    }
}


/*
 * main() simply parses command line arguments, then calls start_simulator().
 * You will need to modify it to support the -r and -s command-line parameters.
 */

int main(int argc, char *argv[])
{
    /* Parse command-line arguments */
    if (argc < 2 || argc > 4)
    {
        fprintf(stderr, "CS 2200 Project 4 -- Multithreaded OS Simulator\n"
            "Usage: ./os-sim <# CPUs> [ -r <time slice> | -s ]\n"
            "    Default : FIFO Scheduler\n"
            "         -r : Round-Robin Scheduler\n"
            "         -s : Shortest Remaining Time First Scheduler\n\n");
        return -1;
    }
    number_of_cpus = atoi(argv[1]);
    /* FIX ME - Add support for -r and -p parameters*/
    scheduler_algorithm = 0;
    if (argc == 2) {
        scheduler_algorithm = 1;
        quantum = -1;
    } else if (argv[2][1] == 'r') {
            scheduler_algorithm = 2;
            quantum = atoi(argv[3]);
    } else if(argv[2][1] == 's') {
            scheduler_algorithm = 3;
            quantum = -1;
    } else {
        fprintf(stderr, "CS 2200 Project 4 -- Multithreaded OS Simulator\n"
            "Usage: ./os-sim <# CPUs> [ -r <time slice> | -s ]\n"
            "    Default : FIFO Scheduler\n"
            "         -r : Round-Robin Scheduler\n"
            "         -s : Shortest Remaining Time First Scheduler\n\n");
        return -1;
    }

    /* Allocate the current[] array and its mutex */
    current = malloc(sizeof(pcb_t*) * number_of_cpus);
    assert(current != NULL);
    pthread_mutex_init(&current_mutex, NULL);

    /* Start the simulator in the library */
    start_simulator(number_of_cpus);

    return 0;
}


#pragma GCC diagnostic pop
