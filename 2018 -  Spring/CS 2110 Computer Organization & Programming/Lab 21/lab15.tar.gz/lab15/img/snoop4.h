/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 snoop4 snoop4.bmp 
 * Time-stamp: Wednesday 03/28/2018, 13:25:10
 * 
 * Image Information
 * -----------------
 * snoop4.bmp 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SNOOP4_H
#define SNOOP4_H

extern const unsigned short snoop4[38400];
#define SNOOP4_SIZE 76800
#define SNOOP4_LENGTH 38400
#define SNOOP4_WIDTH 240
#define SNOOP4_HEIGHT 160

#endif

