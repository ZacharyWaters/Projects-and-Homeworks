/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 snoop6 snoop6.bmp 
 * Time-stamp: Wednesday 03/28/2018, 13:25:10
 * 
 * Image Information
 * -----------------
 * snoop6.bmp 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SNOOP6_H
#define SNOOP6_H

extern const unsigned short snoop6[38400];
#define SNOOP6_SIZE 76800
#define SNOOP6_LENGTH 38400
#define SNOOP6_WIDTH 240
#define SNOOP6_HEIGHT 160

#endif

