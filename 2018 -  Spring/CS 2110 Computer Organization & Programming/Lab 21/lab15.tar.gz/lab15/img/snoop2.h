/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 snoop2 snoop2.bmp 
 * Time-stamp: Wednesday 03/28/2018, 13:25:10
 * 
 * Image Information
 * -----------------
 * snoop2.bmp 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SNOOP2_H
#define SNOOP2_H

extern const unsigned short snoop2[38400];
#define SNOOP2_SIZE 76800
#define SNOOP2_LENGTH 38400
#define SNOOP2_WIDTH 240
#define SNOOP2_HEIGHT 160

#endif

