/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 snoop1 snoop1.bmp 
 * Time-stamp: Wednesday 03/28/2018, 13:25:10
 * 
 * Image Information
 * -----------------
 * snoop1.bmp 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SNOOP1_H
#define SNOOP1_H

extern const unsigned short snoop1[38400];
#define SNOOP1_SIZE 76800
#define SNOOP1_LENGTH 38400
#define SNOOP1_WIDTH 240
#define SNOOP1_HEIGHT 160

#endif

