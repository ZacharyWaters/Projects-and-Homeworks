/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 snoop5 snoop5.bmp 
 * Time-stamp: Wednesday 03/28/2018, 13:25:10
 * 
 * Image Information
 * -----------------
 * snoop5.bmp 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SNOOP5_H
#define SNOOP5_H

extern const unsigned short snoop5[38400];
#define SNOOP5_SIZE 76800
#define SNOOP5_LENGTH 38400
#define SNOOP5_WIDTH 240
#define SNOOP5_HEIGHT 160

#endif

