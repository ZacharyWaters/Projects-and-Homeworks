/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 snoop3 snoop3.bmp 
 * Time-stamp: Wednesday 03/28/2018, 13:25:10
 * 
 * Image Information
 * -----------------
 * snoop3.bmp 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SNOOP3_H
#define SNOOP3_H

extern const unsigned short snoop3[38400];
#define SNOOP3_SIZE 76800
#define SNOOP3_LENGTH 38400
#define SNOOP3_WIDTH 240
#define SNOOP3_HEIGHT 160

#endif

