/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 rotate_puppy_blue rotate_puppy_blue.jpg 
 * Time-stamp: Monday 04/02/2018, 13:31:09
 * 
 * Image Information
 * -----------------
 * rotate_puppy_blue.jpg 62@62
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ROTATE_PUPPY_BLUE_H
#define ROTATE_PUPPY_BLUE_H

extern const unsigned short rotate_puppy_blue[3844];
#define ROTATE_PUPPY_BLUE_SIZE 7688
#define ROTATE_PUPPY_BLUE_LENGTH 3844
#define ROTATE_PUPPY_BLUE_WIDTH 62
#define ROTATE_PUPPY_BLUE_HEIGHT 62

#endif

