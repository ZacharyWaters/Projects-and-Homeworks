/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 rotate_puppy_red rotate_puppy_red.jpg 
 * Time-stamp: Monday 04/02/2018, 13:31:17
 * 
 * Image Information
 * -----------------
 * rotate_puppy_red.jpg 62@62
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ROTATE_PUPPY_RED_H
#define ROTATE_PUPPY_RED_H

extern const unsigned short rotate_puppy_red[3844];
#define ROTATE_PUPPY_RED_SIZE 7688
#define ROTATE_PUPPY_RED_LENGTH 3844
#define ROTATE_PUPPY_RED_WIDTH 62
#define ROTATE_PUPPY_RED_HEIGHT 62

#endif

