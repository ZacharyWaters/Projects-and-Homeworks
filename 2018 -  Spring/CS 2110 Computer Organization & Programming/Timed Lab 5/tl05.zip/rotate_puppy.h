/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 rotate_puppy rotate_puppy.jpg 
 * Time-stamp: Monday 04/02/2018, 13:33:53
 * 
 * Image Information
 * -----------------
 * rotate_puppy.jpg 62@62
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ROTATE_PUPPY_H
#define ROTATE_PUPPY_H

extern const unsigned short rotate_puppy[3844];
#define ROTATE_PUPPY_SIZE 7688
#define ROTATE_PUPPY_LENGTH 3844
#define ROTATE_PUPPY_WIDTH 62
#define ROTATE_PUPPY_HEIGHT 62

#endif

