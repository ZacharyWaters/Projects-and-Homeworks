#!/usr/bin/env bash

if [ -e tl6a.tar.gz ]
 then cp tl6a.tar.gz tl6.tar.gz
fi

if [ -e tl6b.tar.gz ]
 then cp tl6b.tar.gz tl6.tar.gz
fi
