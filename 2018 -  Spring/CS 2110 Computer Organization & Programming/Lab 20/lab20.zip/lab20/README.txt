======================================================================
CS2110                        Lab 20                       Spring 2018
======================================================================
Read the instructions in the lab20.c file

First ensure you have the software required for HW09 installed:

	$ sudo apt update
	$ sudo apt install gcc-arm-none-eabi cs2110-vbam-sdl cs2110-gba-linker-script nin10kit

(If you don't have it already from installing complx, you may need to
 add Brandon's 2110 package repository with

    $ sudo add-apt-repository ppa:tricksterguy87/ppa-gt-cs2110
 
 and then re-run the two commands above.)

cd into directory containing lab20.c and Makefile

Compile it with 'make'

Run it with 'make vba'

When you are done, come show it to us
