======================================================================
CS2110                         Lab #09                     Spring 2018
======================================================================

(This lab is collaborative, so feel free to work with friends or TAs.)

Objective: To get comfortable with our Linux environment, and to
           practice using the basic assembly instructions (such as
           LEA, LD, LDR, LDI, ST, STR, STI, AND, ADD, BR).

You can find an appendix of basic assembly instructions on Canvas under:
   Files > Assembly Resources > PattPatelAppA.pdf

Focus on the program design process:
   1) Start with Pseudo-code
   2) Decide on a register-usage scheme
   3) Translate your psuedo-code into assembly one block at a time
   4) Test each block
   5) Debug
   6) Repeat steps 3-5 until your entire program is complete

================
Your Assignment:
================

We have provided you with a skeleton assembly file called "minimum.asm".

Included with the installation of complx is a program called lc3test, which
uses a set of test values defined in an XML file to test your LC3 code. To get
credit for this lab, you must implement the code in the provided template, then
use the provided XML test to see if your code is correct.

Edit this file and turn in the following:

    1) You will write an assembly program that finds the smallest element in
    an array. After writing and running your code in complx you can check your
    work by either running:

    lc3test minimum.xml minimum.asm

    or by loading in sum.asm into complx, and then using the run tests feature
    in complx with the minimum.xml file.

===========
Submission:
===========

When you finish show a TA all your tests passing
