#include <check.h>

extern Suite *graphics_suite(void);
