/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 azul azul.png 
 * Time-stamp: Tuesday 03/06/2018, 00:21:09
 * 
 * Image Information
 * -----------------
 * azul.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef AZUL_H
#define AZUL_H

extern const unsigned short azul[38400];
#define AZUL_SIZE 76800
#define AZUL_LENGTH 38400
#define AZUL_WIDTH 240
#define AZUL_HEIGHT 160

#endif

