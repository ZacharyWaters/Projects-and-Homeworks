/**
* @file graphics.c
* @author YOUR NAME HERE
* @date DATE HERE
* @brief A graphics library for drawing geometry, for Homework 8 of Georgia Tech
*        CS 2110, Spring 2018.
*/

// Please take a look at the header file below to understand what's required for
// each of the functions.
#include "graphics.h"

Pixel noFilter(Pixel c) {
    // This is the correct implementation, please do not edit it.
    return c;
}

// TODO: Complete according to the prototype in graphics.h
Pixel greyscaleFilter(Pixel c) {
    return c;
}

// TODO: Complete according to the prototype in graphics.h
Pixel redOnlyFilter(Pixel c) {
    return c;
}

// TODO: Complete according to the prototype in graphics.h
Pixel brighterFilter(Pixel c) {
    return c;
}

// TODO: Take a look at this function, which we have readily implemented,
// to see the coding style and logic. This function is not required, delete it
// if you want, or keep it if it's useful to look at for help.
void drawHorizontalLine(Screen *screen, Line *line) {
    // Check if the line is actually horizontal
    if (line->start.y != line->end.y) {
        return;
    }

    // Okay, so it is horizontal. Let's find which one is the left-side vertex
    unsigned int l = line->start.x <= line->end.x ? line->start.x : line->end.x;
    unsigned int r = line->start.x > line->end.x ? line->start.x : line->end.x;

    // Keep a vector that we can pass to drawPixel
    Vector v = {0, line->start.y};
    for (unsigned int x = l; x <= r; x++) {
        v.x = x;
        drawPixel(screen, v, line->color);
    }
}

// TODO: Complete according to the prototype in graphics.h
void drawPixel(Screen *screen, Vector coordinates, Pixel pixel) {
    UNUSED(screen);
    UNUSED(coordinates);
    UNUSED(pixel);
}

// TODO: Complete according to the prototype in graphics.h
void drawFilledRectangle(Screen *screen, Rectangle *rectangle) {
    UNUSED(screen);
    UNUSED(rectangle);
}

// TODO: Complete according to the prototype in graphics.h
void drawLine(Screen *screen, Line *line) {
    UNUSED(screen);
    UNUSED(line);
}

// TODO: Complete according to the prototype in graphics.h
void drawPolygon(Screen *screen, Polygon *polygon) {
    UNUSED(screen);
    UNUSED(polygon);
}

// TODO: Complete according to the prototype in graphics.h
void drawRectangle(Screen *screen, Rectangle *rectangle) {
    UNUSED(screen);
    UNUSED(rectangle);
}

// TODO: Complete according to the prototype in graphics.h
void drawCircle(Screen *screen, Circle *circle) {
    UNUSED(screen);
    UNUSED(circle);
}

// TODO: Complete according to the prototype in graphics.h
void drawFilledCircle(Screen *screen, Circle *circle) {
    UNUSED(screen);
    UNUSED(circle);
}

// TODO: Complete according to the prototype in graphics.h
void drawImage(Screen *screen, Image *image, CropWindow *cropWindow,
                 Pixel (*colorFilter)(Pixel)) {
    UNUSED(screen);
    UNUSED(image);
    UNUSED(cropWindow);
    UNUSED(colorFilter);
}
