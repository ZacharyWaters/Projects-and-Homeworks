
----------------------------------------------------------------------------------

Name, Email, Class Name, Date, Assignment Title:

Zachary Waters
zwaters3@gatech.edu
CS3251 Computer Networks I
Feb 14, 2019
Programming Assignment 1

----------------------------------------------------------------------------------

Files Submitted:

ttweetcli.py
Description: The client, it sends either upload or download requests to the server.

ttweetsrv.py
Description: the server, it receives the requests from the client and responds accordingly

----------------------------------------------------------------------------------

Instructions:

Step 1:
While using the shuttle terminals, in the command line type without quotes "ifconfig"

Step 2: 
In the first section labeled "eth0" get the inet address, it will have 11 digits separated out through 3 periods

Step 3: 
In the command line type without quotes or braces 
"python ttweetsrv.py <IPaddress> <port>"
 where the IPaddress is equal to the inet address found in step 2. 
and the port is a free port, recommended between the range of 13000 and 140000
this starts the ttweet server.

If no parameter values are provided when you run the server it defaults to port 13000 and IP localhost.(this will not work on the shuttle machine).

Step 4:
Open a separate shuttle machine tab, and within it, type without quotes
"python ttweetcli.py"
this starts the ttweet client

Step 5:
The client will now prompt you to specify what mode it will run in.
you can achieve this by typing one of the two commands in the user prompt as follows:

Command 1, Upload Mode: 

ttweetcl -u <ServerIP> <ServerPort> �message�

Command 2, Download Mode: 

ttweetcl -d <ServerIP> <ServerPort>

DO NOT REMOVE THE BRACES
Only replace the value of ServerIP and ServerPort with the values of the corresponding ttweet server you wish for the client to connect to.

STEP 6:
After declaring the mode for the client, the client will execute the corresponding command and will then terminate its connection with the server. to reestablish a connection with the server please repeat steps 4 and then 5.

----------------------------------------------------------------------------------

Output Sample:

refer to Sample.txt

----------------------------------------------------------------------------------

Protocol Description:
 
The ttweet server and ttweet client communicate through a TCP connection. the messages are formatted in one of two ways. 

If the client is seeking to upload a message to the server, the format is like so:

"message"

Where the intended message to be uploaded is wrapped in parenthesis and is then sent to the client. Once the client receives the message the parenthesis are discarded and the message is stored.


if the client wants to download the stored message from the server, the client sends the following message to the server.

	-d

where the server recognizes it as the key for downloading, and sends the stored message back to the client, without parenthesis.

 


