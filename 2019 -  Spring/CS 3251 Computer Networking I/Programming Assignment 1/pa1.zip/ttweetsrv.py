import socket
import sys

host = 'localhost'
port = 13000
if len(sys.argv) == 3:
    host = str(sys.argv[1])
    rawPort = str(sys.argv[2])
    port = int(rawPort)

storedMessage = "EMPTY Message"

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

try:
    sock.bind((host, port))
except socket.error as msg:
    print 'Bind failed. Error Code: ' + str(msg[0]) + 'Message ' + msg[1]

print("Socket successfully bound to port: " + str(port) + " and IP: " + str(host))




sock.listen(1)
print("Server socket established waiting for connection")

while True:
    conn, addr = sock.accept()
    print("CONNECTION MADE BY:" +addr[0])
    try:
        data = conn.recv(1024)
        if not data: break
        print("RECEIVED MESSAGE: " + data)
        if data == '-d':
            conn.sendall(storedMessage)
        else:
            message = data[1:-1]
            storedMessage = message
            print("Stored message is now: " +storedMessage)
    except socket.error:
        print "Error Occured"
        break
conn.close()

