import socket

try:


    import re
    rawInput = raw_input("invoke the client mode \n")

    varSplits = re.split(" ", rawInput)

    varSplitsLength = len(varSplits)

    if varSplitsLength < 4:
        raise IndexError('Too few arguments provided')

    clientName = varSplits[0]
    clientType = varSplits[1]
    rawserverIP = varSplits[2]
    rawserverPort = varSplits[3]

    if clientName != 'ttweetcl':
        print(2.1)
        raise IndexError
    if not(clientType == '-u' or clientType == '-d'):
        print(2.2)
        raise IndexError('Type is incorrect')
    if rawserverIP[0] != '<' or rawserverIP[-1] != '>':
        print(2.3)
        raise IndexError('ServerIP argument not surrounded by < and > ')
    if rawserverPort[0] != '<' or rawserverPort[-1] != '>':
        print(2.4)
        raise IndexError('ServerPort argument not surrounded by < and > ')
    if clientType == '-d' and varSplitsLength > 4:
        print(2.5)
        raise IndexError('Too many arguments provided for download mode')



    serverIP = rawserverIP[1:-1]
    serverPort = int(rawserverPort[1:-1])

    # _________THIS IS THE START OF UPLOAD CONNECTION_____________
    if clientType == '-u':
        message = ""
        if varSplitsLength < 5:
            message = "EMPTY Message"
        else:
            firstQuote = rawInput.find('"')
            if firstQuote == -1:
                raise IndexError('Message argument not surrounded by " and " ')
            message = rawInput[firstQuote:]

        if len(message)== 1:
            raise IndexError('Message argument not surrounded by " and " ')

        if (len(message) - 2) > 150:
            raise IndexError('150 character message limit exceeded')

        if message[0] != '"' or message[-1] != '"':
            raise IndexError('Message argument not surrounded by " and " ')

        clientSock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        clientSock.connect((serverIP, serverPort))
        clientSock.sendall(message)
        print("Output: Upload Successful")
        clientSock.close()


    # _________THIS IS THE START OF DOWNLOAD CONNECTION_____________
    if clientType == '-d':
        message = "-d"
        clientSock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        clientSock.connect((serverIP, serverPort))
        clientSock.sendall(message)
        receivedData = clientSock.recv(1024)
        clientSock.close()
        print("OUTPUT: " +receivedData)

except IndexError as e:
    print("Output: ERROR \n")
    print ("\n")
    print("ERROR: Incorrectly invoked the client \n")
    print(e)
    #print("\n")
    #print("The client should be invoked in this format for upload:")
    #print("ttweetcl -u <ServerIP> <ServerPort> \"message\" \n")
    #print("The client should be invoked in this format for download:")
    #print("ttweetcl -d <ServerIP> <ServerPort>")
except socket.error, exc:
    print("Output: ERROR \n")
    print("Caught exception socket.error : %s" % exc)
except Exception as e:
    print("Output: ERROR \n")
    print("Unexpected exception occurred")