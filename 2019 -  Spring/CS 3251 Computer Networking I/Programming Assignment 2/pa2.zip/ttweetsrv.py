import socket
import sys
from threading import Thread
import thread
import re

# THESE ARE ALL THE ARRAYS
# ================================================================

# THIS ARRAY BRIEFLY HOLDS THE CONNECTION INFORMATION BEFORE PASSING IT ON TO crossRefList
# ================================================================
clientList = []

# THIS ARRAY HOLDS A TUPLE (Username, CONNECTION_TUPLE)
# WHERE CONNECTION_TUPLE IS ITS OWN TUPLE (connection,address)
# ================================================================
crossRefList = []

# THIS ARRAY HOLDS ALL THE USER-NAMES IN CURRENT USE
# ================================================================
usernameList = []


# THIS ARRAY HOLDS ALL THE TWEETS THAT CORRESPOND TO THE USERNAME INDEX

# ================================================================
tweets_For_Users = []

# THIS ARRAY HOLDS A TUPLE (Username, HashTag)
# where the username is subscribed to the HashTag
# hashTag does not actually contain the character '#'
# ================================================================
subscriptionList = []

# THIS ARRAY HOLDS ALL THE USER-NAMES FOR PEOPLE SUBBED TO ~#ALL
# ================================================================
allSubscriptions = []






try:

    # getting host and port
    # ================================================================
    #host = '127.0.0.1'
    host = 'localhost'
    port = 13000
    if len(sys.argv) == 2:
        rawPort = str(sys.argv[1])
        port = int(rawPort)
    else:
        raise IndexError('no port argument provided/too many arguments')
    # ================================================================

    # creating socket
    # ================================================================
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    except socket.error:
        print("Could not create socket")
        sys.exit(0)
        raise IndexError('failed to create a socket')
    # ================================================================

    #setting the host value for the shuttle machines
    # ================================================================
    # host = s.gethostbyname(s.gethostname())
    host = socket.gethostbyname(socket.gethostname())
    # ================================================================

    # bind socket
    # ================================================================
    try:
        s.bind((host, port))
        print("[-] Socket Bound to host: " +host +" and port: " + str(port))
    except socket.error:
        print("Bind Failed")
        sys.exit()
        raise IndexError('failed to bind socket')
    # ================================================================

    # listening for clients
    # ================================================================
    s.listen(5)
    # ================================================================

    # client threads
    # ================================================================
    def client_thread(conn):
        subscriptions = 0
        thread_boolean = True
        while thread_boolean == True:
            raw_data = conn.recv(1024)
            data = raw_data.decode()
            # ========================================================================
            # /\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
            # ========================================================================

            # Handles the newUser Command
            # -------------------------------------------
            if (data[0:7] == "newUser"):
                if ( (data[8:]) in usernameList):
                    #print("A new user is trying to sign in, but failed due to duplicate username: " + data[8:])
                    print("A new user failed to sign in with duplicate username: " + data[8:])
                    conn.send("Invalid username".encode())
                    clientList.remove(clientList[len(clientList) - 1])
                else:
                    #print("A new user is trying to sign in, and succeeded, with username: " + data[8:])
                    print("A new user successfully signed in with username: " + data[8:])
                    conn.send("Valid username".encode())
                    usernameList.append(data[8:])
                    crossRefList.append((data[8:], clientList[len(clientList) - 1]))
                    tweets_For_Users.append("")
                    clientList.remove(clientList[len(clientList) - 1])
                    client = data[8:]

            # ========================================================================
            # /\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
            # ========================================================================

            # Handles the tweet command
            # -------------------------------------------
            elif(data[0:6] == "tweet\""):

                # Gets the index of the right-most quotation character
                # -------------------------------------------
                rightquote = (len(data) - 1)
                while (data[rightquote] != "\""):
                    rightquote = rightquote - 1
                # -------------------------------------------

                # Gets the index for the quotes, and the tweet
                # -------------------------------------------
                leftquote = 5
                tweet = data[leftquote + 1: rightquote]
                # -------------------------------------------

                # Gets the block of hashTags
                # -------------------------------------------
                hashTagBlock = data[rightquote + 1:]
                # -------------------------------------------

                # Separates the block into individual hashTags
                # -------------------------------------------
                hashTagsList = re.split("#", hashTagBlock)
                # -------------------------------------------

                # Creates an array to hold users for preventing duplication,
                # -------------------------------------------
                dupliate_Array = set()
                # -------------------------------------------

                # Gets all the users who are subbed to ALL
                # -------------------------------------------
                for user in allSubscriptions:
                    dupliate_Array.add(user)
                # -------------------------------------------

                # iterates through the hashTag list
                # and gets all the users who are subbed to each
                # -------------------------------------------
                for aHashTag in hashTagsList:
                    for subTuple in subscriptionList:
                        user = subTuple[0]
                        subbedTag = subTuple[1]
                        if(aHashTag == subbedTag):
                            dupliate_Array.add(user)
                # -------------------------------------------

                # Getting the index of Receiving Users
                for recievingUser in dupliate_Array:
                    print(client + " is sending a tweet to: " + recievingUser);
                    index_of_User = usernameList.index(recievingUser)
                    timelineTweetBlock = ""
                    timelineTweetBlock = timelineTweetBlock + client +" "
                    timelineTweetBlock = timelineTweetBlock + recievingUser + " : "
                    timelineTweetBlock = timelineTweetBlock + "\"" + tweet +"\" "
                    timelineTweetBlock = timelineTweetBlock + hashTagBlock + "\n"
                    tweets_For_Users[index_of_User] = tweets_For_Users[index_of_User] + timelineTweetBlock


                # # iterates through duplicate array and sends the tweets to each
                # # -------------------------------------------
                # realTweet = tweet.encode()
                # for recievingUser in dupliate_Array:
                #     for cross in crossRefList:
                #         crossUserName = cross[0]
                #         c_tuple = cross[1]
                #         connection = c_tuple[0]
                #         addr = c_tuple[1]
                #         if(crossUserName == recievingUser):
                #             print(client +" is sending a tweet to: " + crossUserName +" at: %s" %(addr,))
                #             #print(addr)
                #             connection.sendall(realTweet)
                #
                #             #conn.sendto(realTweet, tuple)
                # # -------------------------------------------

            # ========================================================================
            # /\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
            # ========================================================================

            # Handles the subscribe command
            # -------------------------------------------
            elif (data[0:9] == "subscribe"):
                if(data[9:] == "#ALL"):
                    print(client +" subscribed to ~ALL")
                    allSubscriptions.append(client);
                elif(data[9] == "#"):
                    print(client + " subscribed to: " +data[10:])
                    subscriptionList.append((client, data[10:]))


            # ========================================================================
            # /\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
            # ========================================================================

            # Handles the unsubscribe command
            # -------------------------------------------
            elif (data[0:11] == "unsubscribe"):
                hashTagBlock = data[11:]

                # If the user is unsubbing to #ALl, then removes from the All array
                # -------------------------------------------
                if(hashTagBlock == "#ALL"):
                    try:
                        allSubscriptions.remove(client)
                        print(client + " unsubscribed from ~#ALL")
                    except ValueError:
                        print(client + " failed to unsubscribe from ~#ALL")

                # Otherwise, it gets the hash-Tag they want to be removed from,
                # And iterates through the sub array till they are found and then
                # they are removed
                # -------------------------------------------
                else:
                    subbed_user_to_Remove = client
                    subscription_Name = hashTagBlock[1:]
                    i = 0
                    sub_delete_boolean = False
                    while(i < len(subscriptionList)):
                        subTuple = subscriptionList[i]
                        user = subTuple[0]
                        subbedTag = subTuple[1]
                        if (user == subbed_user_to_Remove) and (subbedTag == subscription_Name):
                            del subscriptionList[i]
                            sub_delete_boolean = True
                        i = i + 1
                    if(sub_delete_boolean == True):
                        print(client + " unsubscribed from: #" + subscription_Name)
                    else:
                        print(client + " failed to unsubscribe from: #" + subscription_Name)

            # ========================================================================
            # /\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
            # ========================================================================

            # Handles the timeline command
            # -------------------------------------------
            elif (data[0:8] == "timeline"):
                print(client +" called timeline command")

                # Gets the Users Index
                # -------------------------------------------
                client_index = usernameList.index(client)
                timeline_Reply = tweets_For_Users[client_index]
                if(timeline_Reply == ""):
                    timeline_Reply = "Your Timeline is Empty"
                conn.send(timeline_Reply.encode())
                tweets_For_Users[client_index] = ""



            # ========================================================================
            # /\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
            # ========================================================================

            # Handles the exit command
            # -------------------------------------------
            elif (data[0:4] == "exit"):
                user_to_Exit = client
                print(user_to_Exit + " exiting the server")

                # Deletes the user from the allSub Array, otherwise does nothing
                # -------------------------------------------
                try:
                    allSubscriptions.remove(user_to_Exit)
                except ValueError:
                    pass

                # Deletes the user from the subs list
                # -------------------------------------------
                i = 0
                while (i < len(subscriptionList)):
                    subTuple = subscriptionList[i]
                    user = subTuple[0]
                    if (user == user_to_Exit):
                        del subscriptionList[i]
                    i = i + 1

                # Deletes the user from tweets_For_Users array
                # -------------------------------------------
                client_index = usernameList.index(client)
                del tweets_For_Users[client_index]

                # Deletes the user from the usernameList
                # -------------------------------------------
                i = 0
                while (i < len(usernameList)):
                    name = usernameList[i]
                    if (name == user_to_Exit):
                        del usernameList[i]
                    i = i + 1


                # Deletes the user from crossRefList
                # -------------------------------------------
                i = 0
                while (i < len(crossRefList)):
                    cross = crossRefList[i]
                    crossUserName = cross[0]
                    if (crossUserName == user_to_Exit):
                        # c_tuple = cross[1]
                        # connection = c_tuple[0]
                        # addr = c_tuple[1]
                        del crossRefList[i]
                    i = i + 1

                # Sends a message to the client to terminate themselves
                # -------------------------------------------
                conn.send("Terminate".encode())


                # Terminates the Connection
                # -------------------------------------------
                conn.close()
                thread_boolean = False


            # ========================================================================
            # /\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
            # ========================================================================

            # Handles the unexpected command
            # -------------------------------------------
            else:
                conn.send("Invalid request".encode());



        conn.close()
    # ================================================================

    # establishing connection loop
    # ================================================================
    while True:
        conn, addr = s.accept()
        if not(addr in clientList):
            client_tuple = (conn, addr)
            #clientList.append(addr)
            clientList.append(client_tuple)
        print("[-] Connected to ('" + addr[0] + "', " + str(addr[1]) +")")
        thread.start_new_thread(client_thread, (conn,))
    s.close
    # ================================================================


except IndexError as e:
    print("Output: ERROR \n")
    print(e)