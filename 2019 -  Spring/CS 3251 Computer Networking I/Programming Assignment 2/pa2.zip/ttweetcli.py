import sys
import re
import socket
# import _thread


try:
    subscriptionList = []

    # Default variables
    # ================================================================
    serverIp = "default"
    serverPort = 0
    userName = "default"
    numberOfArgs = len(sys.argv)
    # ================================================================

    # getting serverIp,ServerPort,Username
    # ================================================================
    if numberOfArgs == 4:
        serverIp = str(sys.argv[1])
        userName = str(sys.argv[3])
    elif numberOfArgs < 4:
        raise IndexError("Too few arguments provided")
    elif numberOfArgs > 4:
        raise IndexError("Too many arguments provided")
    else:
        raise IndexError("Something Unexpected Happened")
    # ================================================================

    # serverPort valid check
    # ================================================================
    try:
        serverPort = int(sys.argv[2])
    except ValueError:
        raise IndexError("Invalid server port argument provided")
    # ================================================================

    # Username alphanumeric check
    # ================================================================
    if not(re.match('^[a-zA-Z0-9_]+$', userName)):
        raise IndexError
    # ================================================================

    # creating client socket
    # ================================================================
    try:
        clientSock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    except socket.error:
        print("Could not create socket")
        sys.exit(0)
        # raise IndexError('failed to create a socket')
    # ================================================================

    # Connect client socket to the Server
    # ================================================================
    try:
        clientSock.connect((serverIp, serverPort))
    except:
        raise IndexError('failed to connect to the client server')
    # ================================================================

    # Username duplicate check Part 1
    # ================================================================
    username_message = "newUser " + userName
    try:
        clientSock.send(username_message.encode())
    except:
        raise IndexError('failed to send the server the username')
    # ================================================================

    # Username duplicate check Part 2
    # ================================================================
    recieved_raw_data = clientSock.recv(1024)
    recieved_data = recieved_raw_data.decode()
    if recieved_data == "Invalid username":
        raise IndexError("Username already Taken")
    if recieved_data != "Valid username":
        raise IndexError("Something Unexpected Happened")
    else:
        print("username legal, connection established, welcome: " + userName + "\n")
    # ================================================================

    # # Listening Thread Code Body
    # # ================================================================
    # def listen_thread():
    #     while True:
    #         recieved_raw_data = clientSock.recv(1024)
    #         recieved_data = recieved_raw_data.decode()
    #         print(recieved_data)
    # # ================================================================
    #
    # # Start Listening Thread
    # # ================================================================
    # _thread.start_new_thread(listen_thread,())
    # # ================================================================

    # Command Input Loop
    # ================================================================
    while True:
        raw_UserCommand = raw_input("Enter your command \n")
        # ================================================================

        # Command Parsing
        # ================================================================

        # ========================================================================
        # /\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
        # ========================================================================

        # Parsing for Tweet Command
        # -------------------------------------------
        if (raw_UserCommand[0:7] == "tweet \""):
            varSplits = re.split(" ", raw_UserCommand)
            varSplitsEnd = len(varSplits) - 1
            rawHashTags = varSplits[varSplitsEnd]

            # Checks if the start of the hashTag block begins with a #
            # -------------------------------------------
            if (rawHashTags[0] != '#'):
                reason = "HashTags must begin with the # character"
                print("incorrect command entered: ")
                print(reason + " \n")
                # raise IndexError('incorrect command entered')
                continue
            # -------------------------------------------

            # Checking to see if the hashTag block is alphaNumeric and or hashTags
            # -------------------------------------------
            if (re.search('[^a-zA-Z0-9#]+', rawHashTags)):
                reason = "hashTag block is not alphaNumeric or hashTags"
                print("incorrect command entered: ")
                print(reason + " \n")
                # raise IndexError('incorrect command entered')
                continue
            # -------------------------------------------

            # Checks to see if the hashTag block ends with a #, which breaks the rule
            # -------------------------------------------
            if (rawHashTags[len(rawHashTags) - 1] == "#"):
                reason = "You cannot have an empty hashTag"
                print("incorrect command entered: ")
                print(reason + " \n")
                # raise IndexError('incorrect command entered')
                continue
            # -------------------------------------------

            # Checks to see if the message block ends with a quotation character
            # -------------------------------------------
            lastMessage = varSplits[varSplitsEnd - 1]
            if (lastMessage[len(lastMessage) - 1] != "\""):
                reason = "the message must be surrounded with quotes"
                print("incorrect command entered: ")
                print(reason + " \n")
                # raise IndexError('incorrect command entered')
                continue
            # -------------------------------------------

            # Gets the index of the right-most quotation character
            # Also does a check to make sure there are no hashTags adjacent to eachOther
            # Also does a check to make sure the tweet command doesnt end with whitespace
            # ALso does a check to make sure they dont separate hashTags with whitespace
            # -------------------------------------------
            escapeBoolean = False
            index = (len(raw_UserCommand) - 1)
            while (raw_UserCommand[index] != "\""):
                if (raw_UserCommand[index] == " "):

                    if (index == (len(raw_UserCommand) - 1)):
                        reason = "Whitespace was left at the end of command"
                        print("incorrect command entered: ")
                        print(reason + " \n")
                        # raise IndexError('incorrect command entered')
                        escapeBoolean = True
                        break

                    if (not ((raw_UserCommand[index - 1] == "\"") and (raw_UserCommand[index + 1] == "#"))):
                        reason = "You cannot separate hashTags with spaces"
                        print("incorrect command entered: ")
                        print(reason + " \n")
                        # raise IndexError('incorrect command entered')
                        escapeBoolean = True
                        break

                if (raw_UserCommand[index] == "#"):
                    if (raw_UserCommand[index - 1] == "#"):
                        reason = "You cannot have an empty hashTag"
                        print("incorrect command entered: ")
                        print(reason + " \n")
                        # raise IndexError('incorrect command entered')
                        escapeBoolean = True
                        break

                index = index - 1

            if (escapeBoolean == True):
                continue
            # -------------------------------------------

            # Checks to see if there are more than 8 hashTags
            # any of the hashTags are greater than 25 characters
            # -------------------------------------------
            escapeBoolean = False
            hashTags = re.split("#", rawHashTags)
            if (len(hashTags) > 9):
                reason = "no more than 8 hashTags"
                print("incorrect command entered: ")
                print(reason + " \n")
                continue
            for singleHashTag in hashTags:
                if (len(singleHashTag) > 25):
                    reason = "a hashTag was longer than 25 characters"
                    print("incorrect command entered: ")
                    print(reason + " \n")
                    # raise IndexError('incorrect command entered')
                    escapeBoolean = True
                    break

            if (escapeBoolean == True):
                continue
            # -------------------------------------------

            # Checks to make sure the last quote index is not the same as the first quote
            # -------------------------------------------
            lastQuoteIndex = index
            if (lastQuoteIndex == 6):
                reason = "the message must be surrounded with quotes"
                print("incorrect command entered: ")
                print(reason + " \n")
                # raise IndexError('incorrect command entered')
                continue
            # -------------------------------------------

            # Gets the message block itself
            # -------------------------------------------
            message = raw_UserCommand[7:lastQuoteIndex]
            # -------------------------------------------

            # Makes sure the message block is of appropriate size
            # -------------------------------------------
            if (len(message) == 0 or len(message) > 150):
                reason = "the message is of incorrect size"
                print("incorrect command entered: ")
                print(reason + " \n")
                # raise IndexError('incorrect command entered')
                continue
            # -------------------------------------------

            # Creates the tweet message to send to the server
            # -------------------------------------------
            tweet_message = "tweet" + "\"" + message + "\"" + rawHashTags
            try:
                clientSock.send(tweet_message.encode())
            except:
                raise IndexError('failed to send the server tweet message')
            # -------------------------------------------

            # Printing success
            # -------------------------------------------
            print("operation success \n")
            # -------------------------------------------
        # ========================================================================
        # /\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
        # ========================================================================

        # Parsing for Subscribe Command
        # -------------------------------------------
        elif(raw_UserCommand[0:11] == "subscribe #"):

            # Splits the user command by whitespace
            # -------------------------------------------
            varSplits = re.split(" ", raw_UserCommand)
            # -------------------------------------------

            # Checks to make sure there are only two blocks, subscribe and hashTag
            # -------------------------------------------
            if(len(varSplits) > 2):
                reason = "You cannot separate hashTags with whitespace"
                print("incorrect command entered: ")
                print(reason + " \n")
                # raise IndexError('incorrect command entered')
                continue
            # -------------------------------------------

            # Checks if the hashTag block is alphaNumeric, or has extra hashTags
            # ================================================================
            hashBlock = varSplits[1]
            hashBlock_noTag = hashBlock[1:len(hashBlock)-1]
            if (re.search('[^a-zA-Z0-9]+', hashBlock_noTag)):
                reason = "The hashTag block is not alphaNumeric, or has extra hashTags"
                print("incorrect command entered: ")
                print(reason + " \n")
                # raise IndexError('incorrect command entered')
                continue
            # ================================================================

            # Sees if the hashTag is longer than 25 characters
            # ================================================================
            if(len(hashBlock) > 25):
                reason = "the hashTag was longer than 25 characters"
                print("incorrect command entered: ")
                print(reason + " \n")
                # raise IndexError('incorrect command entered')
                continue
            # ================================================================

            # Creates the subscribe message to send to the server
            # -------------------------------------------
            subscribe_message = "subscribe" + hashBlock
            if (hashBlock in subscriptionList):
                print("operation success \n")
            elif(len(subscriptionList) == 3):
                print("You are subscribed too many hashtags to subscribe to another")
            else:
                subscriptionList.append(hashBlock)
                try:
                    clientSock.send(subscribe_message.encode())
                except:
                    raise IndexError('failed to send the server the subscribe message')
        # ========================================================================
        # /\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
        # ========================================================================

        # Parsing for Unsubscribe Command
        # -------------------------------------------
        elif(raw_UserCommand[0:13] == "unsubscribe #"):
            # Splits the user command by whitespace
            # -------------------------------------------
            varSplits = re.split(" ", raw_UserCommand)
            # -------------------------------------------

            # Checks to make sure there are only two blocks, unsubscribe and hashTag
            # -------------------------------------------
            if (len(varSplits) > 2):
                reason = "You cannot separate hashTags with whitespace"
                print("incorrect command entered: ")
                print(reason + " \n")
                # raise IndexError('incorrect command entered')
                continue
            # -------------------------------------------

            # Checks if the hashTag block is alphaNumeric, or has extra hashTags
            # ================================================================
            hashBlock = varSplits[1]
            hashBlock_noTag = hashBlock[1:len(hashBlock) - 1]
            if (re.search('[^a-zA-Z0-9]+', hashBlock_noTag)):
                reason = "The hashTag block is not alphaNumeric, or has extra hashTags"
                print("incorrect command entered: ")
                print(reason + " \n")
                # raise IndexError('incorrect command entered')
                continue
            # ================================================================

            # Sees if the hashTag is longer than 25 characters
            # ================================================================
            if (len(hashBlock) > 25):
                reason = "the hashTag was longer than 25 characters"
                print("incorrect command entered: ")
                print(reason + " \n")
                # raise IndexError('incorrect command entered')
                continue
            # ================================================================

            # Creates the unsubscribe message to send to the server
            # -------------------------------------------
            subscriptionList.remove(hashBlock)
            unsubscribe_message = "unsubscribe" + hashBlock
            try:
                clientSock.send(unsubscribe_message.encode())
            except:
                raise IndexError('failed to send the server the unsubscribe message')
            # -------------------------------------------

            # Printing success
            # -------------------------------------------
            print("operation success \n")
            # -------------------------------------------

        # ========================================================================
        # /\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
        # ========================================================================
        elif(raw_UserCommand == "timeline"):
            timeline_message = "timeline"
            try:
                clientSock.send(timeline_message.encode())
            except:
                raise IndexError('failed to send the server the timeline message')

            recieved_raw_timeline_data = clientSock.recv(2048)
            recieved_timeline_data = recieved_raw_timeline_data.decode()
            print("operation success:")
            print(recieved_timeline_data)
            print("\n")

        # ========================================================================
        # /\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
        # ========================================================================
        elif raw_UserCommand == "exit":

            # Creates the Exit message to send to the server
            # -------------------------------------------
            exit_message = "exit"
            try:
                clientSock.send(exit_message.encode())
            except:
                raise IndexError('failed to send the server the exit message')

            recieved_raw_terminate_data = clientSock.recv(1024)
            recieved_terminate_data = recieved_raw_terminate_data.decode()

            if recieved_terminate_data == "Terminate":
                print("operation success:")
                sys.exit()
            else:
                raise IndexError('failed to send the server the exit message')
            # -------------------------------------------

        # ========================================================================
        # /\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
        # ========================================================================
        else:
            # raise IndexError('incorrect command entered')
            print("incorrect command entered \n")
        # ================================================================




except IndexError as e:
    print("Output: ERROR \n")
    print(e)