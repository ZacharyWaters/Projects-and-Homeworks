---------------------------------------------------------------------------------------------
			Team Member 1
Name, Email, Class Name, Professor's Name, Date, Assignment Title, Team member's responsibilities:

Zachary Waters
zwaters3@gatech.edu
CS3251 Computer Networks I
Ellen Zegura
April 13, 2019
Programming Assignment 2
Handled the initial implementation of the client code. Figured out the proper way to multithread the server program. Fixed the tweet method in the server code. Handled regex checking for inputs.

---------------------------------------------------------------------------------------------
			Team Member 2
Name, Email, Class Name, Professor's Name, Date, Assignment Title, Team member's responsibilities:

Conner Mathis
cmathis35@gatech.edu
CS3251 Computer Networks I
Ellen Zegura
April 13, 2019
Programming Assignment 2
Handled the initial implementation of the server code. Fixed the subscription method in the client code.

---------------------------------------------------------------------------------------------

Files Submitted:

ttweetcli.py
Description: The client, sends commands to the server

ttweetsrv.py
Description: the server, it receives the commands from the client and responds accordingly

---------------------------------------------------------------------------------------------
How to use our code:

Step 1:
Copy our files into the shuttle machines.

Step 2:
Run the server with command:
python ttweetsrv.py <port number>

don't surround the port with the "<>" characters
be mindful that some of the ports on the shuttle machine are in use, the server will only work if you choose a port that is not currently in use.

Step 3:
if the port is available the server will respond with the command:
[-] Socket Bound to host: <Address> and port: <Port Number>
where the address is the IP address of the server and
the port number is the port the socket is currently connected to.

Step 4:
now when starting the client code use the command:
python ttweetsrv.py <Server Address> <Server port number> <Username>
don't surround any of the inputs with the"<>" characters
make sure to separate your inputs with a single space
use the server address and port you got from step 3 in the corresponding input fields here
use a unique Username that only consists of alphabet characters (upper case + lower case) and numbers 

Step 5:
now when you start the client, if everything works properly:

On the server side you will see:
_____________________________________________________________________
[-] Connected to ('<Client's Address>', <Client's Port>)
A new user successfully signed in with username: <Username>
_____________________________________________________________________


and on the client side you will see the response:
_____________________________________________________________________
username legal, connection established, welcome: <Username>

Enter your command
_____________________________________________________________________
with a prompt allowing the client to type in a command


Step 6: 
you can now begin to enter your user commands and see the responses from the server


----------------------------------------------------------------------------------

Output Sample:

refer to Sample.txt

----------------------------------------------------------------------------------

Commands and Protocol Description:



how the commands work: user input is gathered client side and is then checked to see if it�s a valid command. If the command is invalid the client rejects the input, alerts the user, and asks for another command. If the command is valid the command is then reformatted and sent to the server to handle.

the format of the commands follows that of the pdf.

the commands, their descriptions, and their following "Back-end" formats are as below:

New User:
This command is used whenever a new client is created and is trying to initially sign into the server.
The Client Gets their username and sends the command:
"newUser  <UserName>"
where <UserName> is the client's initial username input. 
The server then receives this command and checks to see if there are any duplicate usernames, and then sends back either "Valid Username" or "Invalid Username" back to the client who responds accordingly.

Tweet:
The client parses out the message and hashtags and checks to make sure they are valid. then creates a message like so to send to the server.
tweet"message"#hashtag1#hashtag2#ect
where the message is surrounded with quotes, and the hashtags are separated by the "#" character.
the server then parses out the message and hashtags and stores the message to every user who would receive it if they used the timeline command.

Subscribe:
The client checks the command for errors, then checks a client-side array for the number of active subscriptions, and if it�s less than 3, the client sends the command:
subscribe #hashtag
to the server, who then stores the username and their subscription in an array

Unsubscribe:
The client checks the command for errors, then if its valid it checks the client side subscriptions array for a matching hashtag and removes it before sending the command:
unsubscribe #hashtag
to the server, who checks the subscription array on its end and removes the user.

Timeline:
The client checks the command for errors, then if its valid it sends the command:
timeline
to the server, who responds by sending all the stored tweets to the user, who then prints it out on their console.

Exit:
The client checks the command for errors, then if its valid it sends the command:
exit
Then the server removes them from all the arrays, then sends a command back to the client gracefully leave the server.









