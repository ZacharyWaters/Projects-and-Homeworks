from DataInterface import getDummyDataset2,getDummyDataset1,getConnect4Dataset, getCarDataset
from DecisionTree import makeTree, setEntropy,infoGain
from Testing import getAverageClassificaionRate,evaluateTree,printDemarcation,testDummySet1,testDummySet2,testConnect4,testCar

#testDummySet1()
#testDummySet2()
#testConnect4()
testCar()