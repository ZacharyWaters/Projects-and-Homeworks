# valueIterationAgents.py
# -----------------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
#
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


import mdp, util

from learningAgents import ValueEstimationAgent

class ValueIterationAgent(ValueEstimationAgent):
    """
        * Please read learningAgents.py before reading this.*

        A ValueIterationAgent takes a Markov decision process
        (see mdp.py) on initialization and runs value iteration
        for a given number of iterations using the supplied
        discount factor.
    """
    def __init__(self, mdp, discount = 0.9, iterations = 100):
        """
          Your value iteration agent should take an mdp on
          construction, run the indicated number of iterations
          and then act according to the resulting policy.

          Some useful mdp methods you will use:
              mdp.getStates()
              mdp.getPossibleActions(state)
              mdp.getTransitionStatesAndProbs(state, action)
              mdp.getReward(state)
              mdp.isTerminal(state)
        """
        self.mdp = mdp
        self.discount = discount
        self.iterations = iterations
        self.values = util.Counter() # A Counter is a dict with default 0

        # Write value iteration code here
        "*** YOUR CODE HERE ***"

        # Loops for the number of iterations
        for iterator in range(iterations):

            # At each iteration we copy all the values
            # over into a new array, so we don't do it "In-Place"
            newValues = (self.values).copy()

            # loops through all the states of the MDP
            for currentState in mdp.getStates():

                if mdp.isTerminal(currentState):
                    newValues[currentState] = 0

                else:
                    maxValue = None

                    # loops through all the actions at each state within the MDP
                    for actionIterator in mdp.getPossibleActions(currentState):

                        # This creates an array of all the possible nextStates, you could take from an action,
                        # and the probability of getting there, ie if you went "north", the odds of ending up in
                        # Y state, is X probability
                        transitions = mdp.getTransitionStatesAndProbs(currentState, actionIterator);

                        # This calculates the total value of a state by its ability to get to its neighbors'
                        # its reachable neighbors' rewards
                        total = 0

                        # this will loop through all the final transition states
                        # for each action, at each state in the MDP
                        for transitionIterator in transitions:


                            nextState = transitionIterator[0]
                            probability = transitionIterator[1]
                            actionTaken = actionIterator
                            reward = mdp.getReward(currentState, actionTaken, nextState)

                            value = self.values[nextState]
                            total = total + probability * ((value * discount) + reward)

                        maxValue = max(total, maxValue)
                    newValues[currentState] = maxValue

            self.values = newValues




    def getValue(self, state):
        """
          Return the value of the state (computed in __init__).
        """
        return self.values[state]


    def computeQValueFromValues(self, state, action):
        """
          Compute the Q-value of action in state from the
          value function stored in self.values.
        """
        "*** YOUR CODE HERE ***"
        # Goes through each of the potential_next States and calculates the total
        # qValue from all the states and returns the total qValue
        total_qValue = 0
        for successor in self.mdp.getTransitionStatesAndProbs(state, action):
            nextState = successor[0]
            probability = successor[1]
            reward_Value = self.mdp.getReward(state, action, nextState)
            nextState_Reward = self.values[nextState]
            total_qValue += probability * (reward_Value + nextState_Reward * self.discount)
        return total_qValue
        # Unreachable raiseNotDefined
        util.raiseNotDefined()

    def computeActionFromValues(self, state):
        """
          The policy is the best action in the given state
          according to the values currently stored in self.values.

          You may break ties any way you see fit.  Note that if
          there are no legal actions, which is the case at the
          terminal state, you should return None.
        """
        "*** YOUR CODE HERE ***"
        # Gets an array of all possible actions from the state
        possible_actions = self.mdp.getPossibleActions(state)

        # If there are no legal actions, we just return NONE
        if(len(possible_actions)==0):
            return None

        # Otherwise we set the default best value to the head of the action Array
        # and start iterating through it looking for the better values using the
        # computed Q score value to compare with
        first_Entry = possible_actions[0]
        first_QValue = self.computeQValueFromValues(state, first_Entry)
        bestAction = first_Entry
        bestValue = first_QValue

        for action in possible_actions:
            if self.computeQValueFromValues(state, action) > bestValue:
                bestAction = action
                bestValue = self.computeQValueFromValues(state, action)

        return bestAction
        # Unreachable raiseNotDefined
        util.raiseNotDefined()

    def getPolicy(self, state):
        return self.computeActionFromValues(state)

    def getAction(self, state):
        "Returns the policy at the state (no exploration)."
        return self.computeActionFromValues(state)

    def getQValue(self, state, action):
        return self.computeQValueFromValues(state, action)
