# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for 
# educational purposes provided that (1) you do not distribute or publish 
# solutions, (2) you retain this notice, and (3) you provide clear 
# attribution to UC Berkeley, including a link to 
# http://inst.eecs.berkeley.edu/~cs188/pacman/pacman.html
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero 
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and 
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called
by Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples,
        (successor, action, stepCost), where 'successor' is a
        successor to the current state, 'action' is the action
        required to get there, and 'stepCost' is the incremental
        cost of expanding to that successor
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.  The sequence must
        be composed of legal moves
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other
    maze, the sequence of moves will be incorrect, so only use this for tinyMaze
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s,s,w,s,w,w,s,w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first

    Your search algorithm needs to return a list of actions that reaches
    the goal.  Make sure to implement a graph search algorithm

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
    "*** YOUR CODE HERE ***"

    """ This creates the array which we will use for our final solution"""
    pathToStartNode = []

    """ This gets the starting state of our problem"""
    startNode = problem.getStartState()

    """ This checks to see if the start state is the Goal """
    if problem.isGoalState(startNode) == True:
        """ if this is true we simply return an empty solution route"""
        return pathToStartNode

    """This creates an array of arrays of paths for any all the potential solution node paths"""
    arrayOfPaths = {}
    arrayOfPaths[startNode] = pathToStartNode;

    """ This is the list of nodes we have seen but might not have visited yet"""
    statesToExplore = util.Stack()

    """ We add the start state's Successors to the statesToExplore Stack"""
    for startSuccessor in problem.getSuccessors(startNode):
        startSuccessorNode = startSuccessor[0]
        startdirection = startSuccessor[1]
        """ our states to explore consists of the successor node, previous node, and the direction"""
        statesToExplore.push((startSuccessorNode,startNode,startdirection))

    """ This makes a set of the visited nodes, and adds the start state to it"""
    visitedNodes = []
    visitedNodes.append(startNode)

    """ We now go through all the states to explore"""
    while statesToExplore.isEmpty() != True:

        """ This pops the current state off of the stack"""
        Currentstate = statesToExplore.pop()

        """ This gets the Variables of the Current State"""
        currentNode = Currentstate[0]
        previousNode = Currentstate[1]
        direction = Currentstate[2]

        """if the current node doesnt have a path to it currently we add its new path"""
        if(currentNode not in arrayOfPaths):
            pathToPreviousNode = arrayOfPaths[previousNode]
            directionList = [direction]
            pathToCurrentNode =  pathToPreviousNode + directionList
            arrayOfPaths[currentNode] = pathToCurrentNode

        """ if the current node is the goal we return its path"""
        if problem.isGoalState(currentNode) == True:
            return arrayOfPaths[currentNode]

        """ If the current node is not yet in visited, we add it to visited and get its successors"""
        if currentNode not in visitedNodes:
            visitedNodes.append(currentNode)
            for nextSuccessor in problem.getSuccessors(currentNode):
                if nextSuccessor not in visitedNodes:
                    nextSuccessorNode = nextSuccessor[0]
                    nextSuccessorDirection = nextSuccessor[1]
                    statesToExplore.push((nextSuccessorNode,currentNode,nextSuccessorDirection))

    """ If the solution is not found throw and error"""
    util.raiseNotDefined()



def breadthFirstSearch(problem):
    """
    Search the shallowest nodes in the search tree first.
    """
    "*** YOUR CODE HERE ***"

    """ This creates the array which we will use for our final solution"""
    pathToStartNode = []

    """ This gets the starting state of our problem"""
    startNode = problem.getStartState()

    """ This checks to see if the start state is the Goal """
    if problem.isGoalState(startNode) == True:
        """ if this is true we simply return an empty solution route"""
        return pathToStartNode

    """This creates an array of arrays of paths for any all the potential solution node paths"""
    arrayOfPaths = {}
    arrayOfPaths[startNode] = pathToStartNode;

    """ This is the list of nodes we have seen but might not have visited yet"""
    statesToExplore = util.Queue()

    """ We add the start state's Successors to the statesToExplore Stack"""
    for startSuccessor in problem.getSuccessors(startNode):
        startSuccessorNode = startSuccessor[0]
        startdirection = startSuccessor[1]
        """ our states to explore consists of the successor node, previous node, and the direction"""
        statesToExplore.push((startSuccessorNode,startNode,startdirection))

    """ This makes a set of the visited nodes, and adds the start state to it"""
    visitedNodes = []
    visitedNodes.append(startNode)

    """ We now go through all the states to explore"""
    while statesToExplore.isEmpty() != True:

        """ This pops the current state off of the stack"""
        Currentstate = statesToExplore.pop()

        """ This gets the Variables of the Current State"""
        currentNode = Currentstate[0]
        previousNode = Currentstate[1]
        direction = Currentstate[2]

        """if the current node doesnt have a path to it currently we add its new path"""
        if(currentNode not in arrayOfPaths):
            pathToPreviousNode = arrayOfPaths[previousNode]
            directionList = [direction]
            pathToCurrentNode =  pathToPreviousNode + directionList
            arrayOfPaths[currentNode] = pathToCurrentNode

        """ if the current node is the goal we return its path"""
        if problem.isGoalState(currentNode) == True:
            return arrayOfPaths[currentNode]

        """ If the current node is not yet in visited, we add it to visited and get its successors"""
        if currentNode not in visitedNodes:
            visitedNodes.append(currentNode)
            for nextSuccessor in problem.getSuccessors(currentNode):
                if nextSuccessor not in visitedNodes:
                    nextSuccessorNode = nextSuccessor[0]
                    nextSuccessorDirection = nextSuccessor[1]
                    statesToExplore.push((nextSuccessorNode,currentNode,nextSuccessorDirection))

    """ If the solution is not found throw and error"""
    util.raiseNotDefined()

def uniformCostSearch(problem):
    "Search the node of least total cost first. "
    "*** YOUR CODE HERE ***"

    """ This creates the array which we will use for our final solution"""
    pathToStartNode = []

    """ This gets the starting state of our problem"""
    startNode = problem.getStartState()

    """ This checks to see if the start state is the Goal """
    if problem.isGoalState(startNode) == True:
        """ if this is true we simply return an empty solution route"""
        return pathToStartNode

    """This creates an array of arrays of paths for any all the potential solution node paths"""
    arrayOfPaths = {}
    arrayOfPaths[startNode] = pathToStartNode;

    """ This creates an array of costs for all the nodes """
    arrayOfCosts = {}
    arrayOfCosts[startNode] = 0;

    """ This is the list of nodes we have seen but might not have visited yet"""
    statesToExplore = util.PriorityQueue()

    """ We add the start state's Successors to the statesToExplore Stack"""
    for startSuccessor in problem.getSuccessors(startNode):
        startSuccessorNode = startSuccessor[0]
        startdirection = startSuccessor[1]
        startCost = startSuccessor[2]
        arrayOfCosts[startSuccessorNode] = startCost
        """ our states to explore consists of the successor node, previous node, and the direction"""
        statesToExplore.push((startSuccessorNode,startNode,startdirection),startCost)

    """ This makes a set of the visited nodes, and adds the start state to it"""
    visitedNodes = []
    visitedNodes.append(startNode)

    """ We now go through all the states to explore"""
    while statesToExplore.isEmpty() != True:

        """ This pops the current state off of the stack"""
        Currentstate = statesToExplore.pop()

        """ This gets the Variables of the Current State"""
        currentNode = Currentstate[0]
        previousNode = Currentstate[1]
        direction = Currentstate[2]

        """if the current node doesnt have a path to it currently we add its new path"""
        if(currentNode not in arrayOfPaths):
            pathToPreviousNode = arrayOfPaths[previousNode]
            directionList = [direction]
            pathToCurrentNode =  pathToPreviousNode + directionList
            arrayOfPaths[currentNode] = pathToCurrentNode

        """ if the current node is the goal we return its path"""
        if problem.isGoalState(currentNode) == True:
            return arrayOfPaths[currentNode]

        """ If the current node is not yet in visited, we add it to visited and get its successors"""
        if currentNode not in visitedNodes:
            visitedNodes.append(currentNode)
            for nextSuccessor in problem.getSuccessors(currentNode):
                if nextSuccessor not in visitedNodes:
                    nextSuccessorNode = nextSuccessor[0]
                    nextSuccessorDirection = nextSuccessor[1]
                    nextSuccessorCost = nextSuccessor[2]
                    arrayOfCosts[nextSuccessorNode] = arrayOfCosts[currentNode] + nextSuccessorCost
                    statesToExplore.push((nextSuccessorNode,currentNode,nextSuccessorDirection), arrayOfCosts[nextSuccessorNode])

    """ If the solution is not found throw and error"""
    util.raiseNotDefined()


def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    "Search the node that has the lowest combined cost and heuristic first."
    "*** YOUR CODE HERE ***"

    """ This creates the array which we will use for our final solution"""
    pathToStartNode = []

    """ This gets the starting state of our problem"""
    startNode = problem.getStartState()

    """ This checks to see if the start state is the Goal """
    if problem.isGoalState(startNode) == True:
        """ if this is true we simply return an empty solution route"""
        return pathToStartNode

    """This creates an array of arrays of paths for any all the potential solution node paths"""
    arrayOfPaths = {}
    arrayOfPaths[startNode] = pathToStartNode;

    """ This creates an array of costs for all the nodes """
    arrayOfCosts = {}
    arrayOfCosts[startNode] = 0;

    """ This is the list of nodes we have seen but might not have visited yet"""
    statesToExplore = util.PriorityQueue()

    """ We add the start state's Successors to the statesToExplore Stack"""
    for startSuccessor in problem.getSuccessors(startNode):
        startSuccessorNode = startSuccessor[0]
        startdirection = startSuccessor[1]
        startCost = startSuccessor[2]
        arrayOfCosts[startSuccessorNode] = startCost
        startHeuristicCost = heuristic(startSuccessorNode, problem)
        """ our states to explore consists of the successor node, previous node, and the direction"""
        statesToExplore.push((startSuccessorNode,startNode,startdirection),startCost+startHeuristicCost)

    """ This makes a set of the visited nodes, and adds the start state to it"""
    visitedNodes = []
    visitedNodes.append(startNode)

    """ We now go through all the states to explore"""
    while statesToExplore.isEmpty() != True:

        """ This pops the current state off of the stack"""
        Currentstate = statesToExplore.pop()

        """ This gets the Variables of the Current State"""
        currentNode = Currentstate[0]
        previousNode = Currentstate[1]
        direction = Currentstate[2]

        """if the current node doesnt have a path to it currently we add its new path"""
        if(currentNode not in arrayOfPaths):
            pathToPreviousNode = arrayOfPaths[previousNode]
            directionList = [direction]
            pathToCurrentNode =  pathToPreviousNode + directionList
            arrayOfPaths[currentNode] = pathToCurrentNode

        """ if the current node is the goal we return its path"""
        if problem.isGoalState(currentNode) == True:
            return arrayOfPaths[currentNode]

        """ If the current node is not yet in visited, we add it to visited and get its successors"""
        if currentNode not in visitedNodes:
            visitedNodes.append(currentNode)
            for nextSuccessor in problem.getSuccessors(currentNode):
                if nextSuccessor not in visitedNodes:
                    nextSuccessorNode = nextSuccessor[0]
                    nextSuccessorDirection = nextSuccessor[1]
                    nextSuccessorCost = nextSuccessor[2]
                    arrayOfCosts[nextSuccessorNode] = arrayOfCosts[currentNode] + nextSuccessorCost
                    nextHeuristicCost = heuristic(nextSuccessorNode, problem)
                    totalCost = arrayOfCosts[nextSuccessorNode]+nextHeuristicCost

                    statesToExplore.push((nextSuccessorNode,currentNode,nextSuccessorDirection), totalCost)

    """ If the solution is not found throw and error"""
    util.raiseNotDefined()


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch