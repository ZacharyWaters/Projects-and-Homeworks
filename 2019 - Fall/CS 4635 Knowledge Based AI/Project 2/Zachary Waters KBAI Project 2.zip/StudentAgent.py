"""
Project 2

ADD YOUR CODE HERE

Please read project directions before importing anything
"""


class StudentAgent:

    def __init__(self, verbose):
        self._verbose = verbose
        # TODO: Add your init code here
        return

    # takes in list of words, returns question_object and data_requested
    def input_output(self, word_list):
        #print(word_list) # for debugging only

        # TODO: Add your code here

        def getNextXwordsandConjoin(list, startIndex, nextX):
            returnWord = ""
            if(nextX <= 0):
                return list[startIndex]
            else:
                for i in range(nextX):
                    if(i == 0):
                        returnWord = returnWord + list[startIndex + i]
                    else:
                        returnWord = returnWord +" "+ list[startIndex + i]
            return returnWord

        def doesListContain(list, word):
            returnBoolean = False
            length = len(list)
            counter = 0
            while counter < length and returnBoolean == False:
                wordAtIndex = list[counter]
                if(wordAtIndex == word):
                    returnBoolean = True
                counter = counter + 1
            return returnBoolean

        def isExample(question, array_Of_Examples, array_of_subCompares):

            # length of the question being asked
            question_length = len(question)

            # Iterator and length of example array to loop across
            exampleIterator = 0
            examples_End = len(array_Of_Examples)

            # This variable represents if a match was found and also stops the examplesLoop
            matchFound = False

            # ==========================================================================================================
            # INSIDE THE OUTER WHILE LOOP
            while (exampleIterator < examples_End) and (matchFound == False):

                # Getting the Example from the example list
                testExample = array_Of_Examples[exampleIterator]

                # Extracting the length of the Example
                test_Example_Min_Length = testExample[1]
                test_Example_Max_Length = testExample[2]

                # This will be a list that holds all the values gathered from <>,[] operators
                IndexValuesArray = []

                # this flag will be used to mark any activities I might add that come before the comparison
                initialFailFlag = False

                # Comparing the length of the Example for quick fail check
                if((question_length < test_Example_Min_Length) or (question_length > test_Example_Max_Length)):
                    initialFailFlag = True

                # Checking initialFailFlag, then starting comparison loop
                if(initialFailFlag != True):
                    # this is the example we are comparing to
                    example = testExample[0]
                    extraContext = testExample[5]

                    # this is the iterator and stopper for this comparison
                    compareExampleIterator = 0
                    compareQuestionIterator = 0
                    example_Length = len(example)

                    # compare-brake value, this stops the compare loop if set to true
                    didnt_Match_Brakes = False;

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    # INSIDE INNER WHILE LOOP
                    while (compareExampleIterator < example_Length) and \
                            (compareQuestionIterator < question_length) and \
                            (didnt_Match_Brakes != True):

                        # Extracts a single word from that example list
                        Eword = example[compareExampleIterator]
                        #print(Eword)

                        # flag to determine if the word is a <>, []
                        markerFlag = False

                        # Extracts the first character from the word
                        firstCharacter = Eword[0]

                        # Checks if the word is a <> character
                        if(firstCharacter == '<') or (firstCharacter == '['):

                            # Extracted String-number value
                            extractStringNumber = ""

                            # Sets the markerFlag to true
                            markerFlag = True

                            # Gets the number length that depends on the < or [ symbols
                            # And extracts the number inside <> or []
                            if(firstCharacter == '<'):
                                extractStringNumber = Eword[1]

                            elif (firstCharacter == '['):
                                extractStringNumber = Eword[1: 3]


                            # turn the String-number into Int-Number
                            extractIntNumber = int(extractStringNumber)

                            # get the corresponding abstract sub-compare array
                            subcompare_Abstract_list = array_of_subCompares[extractIntNumber]

                            # iterate across the Abstract List
                            abstractIterator = 0
                            abstractEnd = len(subcompare_Abstract_list)
                            abstractMatchFound = False
                            # ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                            # INSIDE ABSTRACT WHILE LOOP
                            while(abstractIterator < abstractEnd) and (abstractMatchFound == False):

                                # Gets the abstract tuple value at the index
                                # child Abstract Tuples are in form (length_X, list_of_sub-compares_of_length_X)
                                childAbstractTuple = subcompare_Abstract_list[abstractIterator]

                                # Gets the length of the sub compares in the list
                                sub_compare_Length = childAbstractTuple[0]

                                # This is the stopper for this inner while loop of the abstract class
                                innermostMatchFound = False

                                # check if the length of the value + index of the question will work
                                if(sub_compare_Length + compareQuestionIterator <= question_length):

                                    # gets the next X strings and conjoin them together to form a
                                    # single string for comparison
                                    conjoinString = getNextXwordsandConjoin(question, compareQuestionIterator, sub_compare_Length)

                                    # this is the compare list that you will use to compare with the conjoin string
                                    sub_inner_compareList = childAbstractTuple[1]
                                    sub_inner_compareList_Length = len(sub_inner_compareList)
                                    sub_inner_iterator = 0
                                    # loop through the concrete list of the elements comparing our conjoined to it
                                    # &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
                                    # INSIDE INNERMOST ABSTRACT WHILE LOOP
                                    while(sub_inner_iterator < sub_inner_compareList_Length) \
                                            and (innermostMatchFound == False):

                                        # Gets the stored tuple of the word that we will be comparing
                                        # (assignment 0, "FAIL"),(assignment 1, "ASSIGNMENT1")
                                        # Types are NULL, FAIL, OBJECTNAME, TYPENAME
                                        storage_tuple = sub_inner_compareList[sub_inner_iterator]

                                        # Gets tha actual word we will be using in to compare
                                        word_Stored_In_Array = storage_tuple[0]

                                        if conjoinString == word_Stored_In_Array:
                                            innermostMatchFound = True

                                            # This are the values of the type that might be contained
                                            innerValue = storage_tuple[1]

                                            IndexValuesArray.append(innerValue)

                                        # Increment the innermost abstract Iterator
                                        sub_inner_iterator = sub_inner_iterator + 1

                                    # &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
                                    # OUTSIDE INNERMOST ABSTRACT WHILE LOOP

                                if(innermostMatchFound == True):
                                    abstractMatchFound = True
                                    compareQuestionIterator = compareQuestionIterator + sub_compare_Length - 1;

                                    # Increment the abstract Iterator
                                abstractIterator = abstractIterator + 1
                            # ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                            # OUTSIDE ABSTRACT WHILE LOOP

                            if (abstractMatchFound != True):
                                didnt_Match_Brakes = True

                        # ______________________________________________________________________________________________
                        # Outside the if Statement for <>,[] case

                        # Compares the word with the corresponding word value of the question
                        else:
                            Qword = question[compareQuestionIterator]
                            #print(Qword)
                            if(Qword != Eword):
                                didnt_Match_Brakes = True

                        # Increment the Iterators
                        compareExampleIterator = compareExampleIterator + 1
                        compareQuestionIterator = compareQuestionIterator + 1
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    # OUTSIDE INNER WHILE LOOP

                    # this checks that if after looping through the example if it didn't break
                    if(didnt_Match_Brakes == False):

                        # sets the matchFound variable to True
                        matchFound = True

                # Increment the Iterator
                exampleIterator = exampleIterator + 1

            # ==========================================================================================================
            # OUTSIDE THE OUTER WHILE LOOP

            subject = "Fail"
            request = "Fail"

            # Checking if matchFound
            if (matchFound == True):

                # gets the objectPointer Value
                objectPointer = testExample[3]

                # gets the typePointer Value
                typePointer = testExample[4]

                # getting the object pointer mode character
                objectPointerMode = objectPointer[0]

                # IF in objectPointerMode in HARDCODED mode
                if(objectPointerMode == '+'):
                    subject = objectPointer[1:]

                # ELSE if objectPointerMode in INDEX mode
                else:
                    subjectStringIndex = objectPointer[1:]
                    subjectIntIndex = int(subjectStringIndex)
                    subject = IndexValuesArray[subjectIntIndex]



                # getting the type pointer mode character
                typePointerMode = typePointer[0]

                # IF in typePointerMode in HARDCODED mode
                if(typePointerMode == '+'):
                    request = typePointer[1:]

                # ELSE if typePointerMode in INDEX mode
                else:
                    requestStringIndex = typePointer[1:]
                    requestIntIndex = int(requestStringIndex)
                    request = IndexValuesArray[requestIntIndex]



                #print("match was found: " + subject + ", " + request + ", " + extraContext)

            # Return Tuple of subject, request
            return (matchFound, subject, request, extraContext)

        def convertToIntent(resultsTuple, question):
            returnIntent = 0
            wasFound = resultsTuple[0]
            subject = resultsTuple[1]
            request = resultsTuple[2]
            extra = resultsTuple[3]
            if(wasFound == True):
                if(subject == 'ASSIGNMENT1' and request == 'RELEASEDATE' and extra == '@'):
                    returnIntent = 1
                elif(subject == 'PROJECT1' and request == 'RELEASEDATE' and extra == '@'):
                    returnIntent = 2
                elif(subject == 'ASSIGNMENT2' and request == 'RELEASEDATE' and extra == '@'):
                    returnIntent = 3
                elif (subject == 'MIDTERM' and request == 'RELEASEDATE' and extra == '@'):
                    returnIntent = 4
                elif (subject == 'PROJECT2' and request == 'RELEASEDATE' and extra == '@'):
                    returnIntent = 5
                elif(subject == 'ASSIGNMENT3' and request == 'RELEASEDATE' and extra == '@'):
                    returnIntent = 6
                elif (subject == 'PROJECT3' and request == 'RELEASEDATE' and extra == '@'):
                    returnIntent = 7
                elif (subject == 'FINAL' and request == 'RELEASEDATE' and extra == '@'):
                    returnIntent = 8
                elif(subject == 'ASSIGNMENT1' and request == 'DUEDATE' and extra == '@'):
                    returnIntent = 9
                elif(subject == 'PROJECT1' and request == 'DUEDATE' and extra == '@'):
                    returnIntent = 10
                elif(subject == 'ASSIGNMENT2' and request == 'DUEDATE' and extra == '@'):
                    returnIntent = 11
                elif (subject == 'MIDTERM' and request == 'DUEDATE' and extra == '@'):
                    returnIntent = 12
                elif (subject == 'PROJECT2' and request == 'DUEDATE' and extra == '@'):
                    returnIntent = 13
                elif(subject == 'ASSIGNMENT3' and request == 'DUEDATE' and extra == '@'):
                    returnIntent = 14
                elif (subject == 'PROJECT3' and request == 'DUEDATE' and extra == '@'):
                    returnIntent = 15
                elif (subject == 'FINAL' and request == 'DUEDATE' and extra == '@'):
                    returnIntent = 16
                elif(subject == 'ASSIGNMENT1' and request == 'DURATION' and extra == '@'):
                    returnIntent = 17
                elif(subject == 'PROJECT1' and request == 'DURATION' and extra == '@'):
                    returnIntent = 18
                elif(subject == 'ASSIGNMENT2' and request == 'DURATION' and extra == '@'):
                    returnIntent = 19
                elif (subject == 'MIDTERM' and request == 'DURATION' and extra == '@'):
                    returnIntent = 20
                elif (subject == 'PROJECT2' and request == 'DURATION' and extra == '@'):
                    returnIntent = 21
                elif(subject == 'ASSIGNMENT3' and request == 'DURATION' and extra == '@'):
                    returnIntent = 22
                elif (subject == 'PROJECT3' and request == 'DURATION' and extra == '@'):
                    returnIntent = 23
                elif (subject == 'FINAL' and request == 'DURATION' and extra == '@'):
                    returnIntent = 24
                elif(subject == 'ASSIGNMENT1' and request == 'WEIGHT' and extra == '@'):
                    returnIntent = 25
                elif(subject == 'PROJECT1' and request == 'WEIGHT' and extra == '@'):
                    returnIntent = 26
                elif(subject == 'ASSIGNMENT2' and request == 'WEIGHT' and extra == '@'):
                    returnIntent = 27
                elif (subject == 'MIDTERM' and request == 'WEIGHT' and extra == '@'):
                    returnIntent = 28
                elif (subject == 'PROJECT2' and request == 'WEIGHT' and extra == '@'):
                    returnIntent = 29
                elif(subject == 'ASSIGNMENT3' and request == 'WEIGHT' and extra == '@'):
                    returnIntent = 30
                elif (subject == 'PROJECT3' and request == 'WEIGHT' and extra == '@'):
                    returnIntent = 31
                elif (subject == 'FINAL' and request == 'WEIGHT' and extra == '@'):
                    returnIntent = 32
                elif(subject == 'ASSIGNMENT1' and request == 'PROCESS' and extra == '@'):
                    returnIntent = 33
                elif(subject == 'PROJECT1' and request == 'PROCESS' and extra == '@'):
                    returnIntent = 34
                elif(subject == 'ASSIGNMENT2' and request == 'PROCESS' and extra == '@'):
                    returnIntent = 35
                elif (subject == 'MIDTERM' and request == 'PROCESS' and extra == '@'):
                    returnIntent = 36
                elif (subject == 'PROJECT2' and request == 'PROCESS' and extra == '@'):
                    returnIntent = 37
                elif(subject == 'ASSIGNMENT3' and request == 'PROCESS' and extra == '@'):
                    returnIntent = 38
                elif (subject == 'PROJECT3' and request == 'PROCESS' and extra == '@'):
                    returnIntent = 39
                elif (subject == 'FINAL' and request == 'PROCESS' and extra == '@'):
                    returnIntent = 40
                elif (subject == 'ANNOUNCEMENT' and request == 'GENERAL' and extra == '@'):
                    returnIntent = 41
                elif (subject == 'GOALS' and request == 'GENERAL' and extra == '@'):
                    returnIntent = 42
                elif (subject == 'PROJECT/WEEK?' and request == 'WEEK3' and extra == 'START'):
                    returnIntent = 2
                elif (subject == 'PROJECT/WEEK?' and request == 'WEEK8' and extra == 'START'):
                    returnIntent = 5
                elif (subject == 'PROJECT/WEEK?' and request == 'WEEK13' and extra == 'START'):
                    returnIntent = 7
                elif (subject == 'ASSIGNMENT/WEEK?' and request == 'WEEK2' and extra == 'START'):
                    returnIntent = 1
                elif (subject == 'ASSIGNMENT/WEEK?' and request == 'WEEK6' and extra == 'START'):
                    returnIntent = 3
                elif (subject == 'ASSIGNMENT/WEEK?' and request == 'WEEK11' and extra == 'START'):
                    returnIntent = 6

                # PROJECT WORK CASES
                elif (subject == 'PROJECT/WEEK?' and request == 'WEEK3' and extra == 'WORK'):
                    returnIntent = 18
                elif (subject == 'PROJECT/WEEK?' and request == 'WEEK4' and extra == 'WORK'):
                    returnIntent = 18
                elif (subject == 'PROJECT/WEEK?' and request == 'WEEK5' and extra == 'WORK'):
                    returnIntent = 18
                elif (subject == 'PROJECT/WEEK?' and request == 'WEEK6' and extra == 'WORK'):
                    returnIntent = 18
                elif (subject == 'PROJECT/WEEK?' and request == 'WEEK8' and extra == 'WORK'):
                    returnIntent = 21
                elif (subject == 'PROJECT/WEEK?' and request == 'WEEK9' and extra == 'WORK'):
                    returnIntent = 21
                elif (subject == 'PROJECT/WEEK?' and request == 'WEEK10' and extra == 'WORK'):
                    returnIntent = 21
                elif (subject == 'PROJECT/WEEK?' and request == 'WEEK11' and extra == 'WORK'):
                    returnIntent = 21
                elif (subject == 'PROJECT/WEEK?' and request == 'WEEK13' and extra == 'WORK'):
                    returnIntent = 23
                elif (subject == 'PROJECT/WEEK?' and request == 'WEEK14' and extra == 'WORK'):
                    returnIntent = 23
                elif (subject == 'PROJECT/WEEK?' and request == 'WEEK15' and extra == 'WORK'):
                    returnIntent = 23
                elif (subject == 'PROJECT/WEEK?' and request == 'WEEK16' and extra == 'WORK'):
                    returnIntent = 23

                # ASSIGNMENT WORK CASES
                elif (subject == 'ASSIGNMENT/WEEK?' and request == 'WEEK2' and extra == 'WORK'):
                    returnIntent = 11
                elif (subject == 'ASSIGNMENT/WEEK?' and request == 'WEEK3' and extra == 'WORK'):
                    returnIntent = 11
                elif (subject == 'ASSIGNMENT/WEEK?' and request == 'WEEK6' and extra == 'WORK'):
                    returnIntent = 19
                elif (subject == 'ASSIGNMENT/WEEK?' and request == 'WEEK7' and extra == 'WORK'):
                    returnIntent = 19
                elif (subject == 'ASSIGNMENT/WEEK?' and request == 'WEEK11' and extra == 'WORK'):
                    returnIntent = 22
                elif (subject == 'ASSIGNMENT/WEEK?' and request == 'WEEK12' and extra == 'WORK'):
                    returnIntent = 22

                # ASSIGNMENT SUBMIT CASES
                elif (subject == 'ASSIGNMENT/WEEK?' and request == 'WEEK3' and extra == 'SUBMIT'):
                    returnIntent = 9
                elif (subject == 'ASSIGNMENT/WEEK?' and request == 'WEEK7' and extra == 'SUBMIT'):
                    returnIntent = 11
                elif (subject == 'ASSIGNMENT/WEEK?' and request == 'WEEK12' and extra == 'SUBMIT'):
                    returnIntent = 14

                # PROJECT SUBMIT CASES
                elif (subject == 'PROJECT/WEEK?' and request == 'WEEK6' and extra == 'SUBMIT'):
                    returnIntent = 10
                elif (subject == 'PROJECT/WEEK?' and request == 'WEEK11' and extra == 'SUBMIT'):
                    returnIntent = 13
                elif (subject == 'PROJECT/WEEK?' and request == 'WEEK16' and extra == 'SUBMIT'):
                    returnIntent = 15

                # ANY START CASES
                elif (subject == 'ANY/WEEK?' and request == 'WEEK2' and extra == 'START'):
                    # ASSIGNMENT1
                    returnIntent = 1
                elif (subject == 'ANY/WEEK?' and request == 'WEEK3' and extra == 'START'):
                    # PROJECT 1
                    returnIntent = 2
                elif (subject == 'ANY/WEEK?' and request == 'WEEK6' and extra == 'START'):
                    # ASSIGNMENT2
                    returnIntent = 3
                elif (subject == 'ANY/WEEK?' and request == 'WEEK7' and extra == 'START'):
                    # MIDTERM
                    returnIntent = 4
                elif (subject == 'ANY/WEEK?' and request == 'WEEK8' and extra == 'START'):
                    # PROJECT 2
                    returnIntent = 5
                elif (subject == 'ANY/WEEK?' and request == 'WEEK11' and extra == 'START'):
                    # ASSIGNMENT3
                    returnIntent = 6
                elif (subject == 'ANY/WEEK?' and request == 'WEEK13' and extra == 'START'):
                    # PROJECT 3
                    returnIntent = 7
                elif (subject == 'ANY/WEEK?' and request == 'WEEK16' and extra == 'START'):
                    # FINAL
                    returnIntent = 8

                # ANY WORK CASES
                elif (subject == 'ANY/WEEK?' and request == 'WEEK2' and extra == 'WORK'):
                    # ASSIGNMENT1
                    returnIntent = 17
                elif (subject == 'ANY/WEEK?' and request == 'WEEK4' and extra == 'WORK'):
                    # PROJECT 1
                    returnIntent = 18
                elif (subject == 'ANY/WEEK?' and request == 'WEEK5' and extra == 'WORK'):
                    # PROJECT 1
                    returnIntent = 18
                elif (subject == 'ANY/WEEK?' and request == 'WEEK9' and extra == 'WORK'):
                    # PROJECT 2
                    returnIntent = 21
                elif (subject == 'ANY/WEEK?' and request == 'WEEK10' and extra == 'WORK'):
                    # PROJECT 2
                    returnIntent = 21
                elif (subject == 'ANY/WEEK?' and request == 'WEEK12' and extra == 'WORK'):
                    # ASSIGNMENT3
                    returnIntent = 22
                elif (subject == 'ANY/WEEK?' and request == 'WEEK13' and extra == 'WORK'):
                    # PROJECT 3
                    returnIntent = 23
                elif (subject == 'ANY/WEEK?' and request == 'WEEK14' and extra == 'WORK'):
                    # PROJECT 3
                    returnIntent = 23
                elif (subject == 'ANY/WEEK?' and request == 'WEEK15' and extra == 'WORK'):
                    # PROJECT 3
                    returnIntent = 23


                # ANY SUBMIT CASES
                elif (subject == 'ANY/WEEK?' and request == 'WEEK3' and extra == 'SUBMIT'):
                    # ASSIGNMENT1
                    returnIntent = 9
                elif (subject == 'ANY/WEEK?' and request == 'WEEK6' and extra == 'SUBMIT'):
                    # PROJECT 1
                    returnIntent = 10
                elif (subject == 'ANY/WEEK?' and request == 'WEEK11' and extra == 'SUBMIT'):
                    # PROJECT 2
                    returnIntent = 13
                elif (subject == 'ANY/WEEK?' and request == 'WEEK12' and extra == 'SUBMIT'):
                    # ASSIGNMENT3
                    returnIntent = 22

                # CODE CASE
                elif (subject == 'PROJECT1' and request == 'PROCESS' and extra == 'CODE'):
                    # ASSIGNMENT1
                    returnIntent = 34
                elif (subject == 'PROJECT2' and request == 'PROCESS' and extra == 'CODE'):
                    # PROJECT 1
                    returnIntent = 37
                elif (subject == 'PROJECT3' and request == 'PROCESS' and extra == 'CODE'):
                    # PROJECT 2
                    returnIntent = 39
                # ZIP CASE
                # PDF CASE
                # CANVAS CASE

            if(doesListContain(question, 'announcements')):
                returnIntent = 41
            if (doesListContain(question, 'goals')):
                returnIntent = 42

            # TimeBased Stuff
            return returnIntent

        # This will contain the array of all question patterns
        masterExamplesArray = []

        # This will contain all the smaller building blocks that make up sections of the patterns
        subCompares = []


        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        # ARRAY OF <0> WORDS
        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        zeroArrayLength1 = [('midterm', "MIDTERM"), ('final', "FINAL"),
                            ('assignment', "ASSIGNMENT/WEEK?"), ('project', "PROJECT/WEEK?")]
        zeroArrayLength2 = [('the assignment', "ASSIGNMENT/WEEK?"),('the project', "PROJECT/WEEK?"),
                            ('assignment zero', "FAIL"), ('assignment one', "ASSIGNMENT1"),
                            ('assignment two', "ASSIGNMENT2"), ('assignment three', "ASSIGNMENT3"),
                            ('assignment four', "FAIL"), ('assignment five', "FAIL"),
                            ('assignment six', "FAIL"), ('assignment seven', "FAIL"),
                            ('assignment eight', "FAIL"), ('assignment nine', "FAIL"),
                            ('assignment ten', "FAIL"), ('assignment eleven', "FAIL"),
                            ('assignment twelve', "FAIL"), ('assignment thirteen', "FAIL"),
                            ('assignment fourteen', "FAIL"), ('assignment fifteen', "FAIL"),
                            ('assignment sixteen', "FAIL"), ('assignment seventeen', "FAIL"),
                            ('assignment eighteen', "FAIL"), ('assignment nineteen', "FAIL"),
                            ('assignment twenty', "FAIL"), ('assignment twenty-one', "FAIL"),
                            ('assignment twenty-two', "FAIL"), ('assignment twenty-three', "FAIL"),
                            ('assignment twenty-four', "FAIL"), ('assignment twenty-five', "FAIL"),
                            ('assignment twenty-six', "FAIL"), ('assignment twenty-seven', "FAIL"),
                            ('assignment twenty-eight', "FAIL"), ('assignment twenty-nine', "FAIL"),
                            ('assignment thirty', "FAIL"), ('assignment thirty-one', "FAIL"),
                            ('assignment thirty-two', "FAIL"), ('assignment thirty-three', "FAIL"),
                            ('assignment thirty-four', "FAIL"), ('assignment thirty-five', "FAIL"),
                            ('assignment thirty-six', "FAIL"), ('assignment thirty-seven', "FAIL"),
                            ('assignment thirty-eight', "FAIL"), ('assignment thirty-nine', "FAIL"),
                            ('assignment forty', "FAIL"), ('assignment forty-one', "FAIL"),
                            ('assignment forty-two', "FAIL"), ('assignment 0', "FAIL"),
                            ('assignment 1', "ASSIGNMENT1"), ('assignment 2', "ASSIGNMENT2"),
                            ('assignment 3', "ASSIGNMENT3"), ('assignment 4', "FAIL"),
                            ('assignment 5', "FAIL"), ('assignment 6', "FAIL"), ('assignment 7', "FAIL"),
                            ('assignment 8', "FAIL"), ('assignment 9', "FAIL"), ('assignment 10', "FAIL"),
                            ('assignment 11', "FAIL"), ('assignment 12', "FAIL"), ('assignment 13', "FAIL"),
                            ('assignment 14', "FAIL"), ('assignment 15', "FAIL"), ('assignment 16', "FAIL"),
                            ('assignment 17', "FAIL"), ('assignment 18', "FAIL"), ('assignment 19', "FAIL"),
                            ('assignment 20', "FAIL"), ('assignment 21', "FAIL"), ('assignment 22', "FAIL"),
                            ('assignment 23', "FAIL"), ('assignment 24', "FAIL"), ('assignment 25', "FAIL"),
                            ('assignment 26', "FAIL"), ('assignment 27', "FAIL"), ('assignment 28', "FAIL"),
                            ('assignment 29', "FAIL"), ('assignment 30', "FAIL"), ('assignment 31', "FAIL"),
                            ('assignment 32', "FAIL"), ('assignment 33', "FAIL"), ('assignment 34', "FAIL"),
                            ('assignment 35', "FAIL"), ('assignment 36', "FAIL"), ('assignment 37', "FAIL"),
                            ('assignment 38', "FAIL"), ('assignment 39', "FAIL"), ('assignment 40', "FAIL"),
                            ('assignment 41', "FAIL"), ('assignment 42', "FAIL"),
                            ('project zero', "FAIL"), ('project one', "PROJECT1"),
                            ('project two', "PROJECT2"), ('project three', "PROJECT3"),
                            ('project four', "FAIL"), ('project five', "FAIL"), ('project six', "FAIL"),
                            ('project seven', "FAIL"), ('project eight', "FAIL"),
                            ('project nine', "FAIL"), ('project ten', "FAIL"), ('project eleven', "FAIL"),
                            ('project twelve', "FAIL"), ('project thirteen', "FAIL"),
                            ('project fourteen', "FAIL"), ('project fifteen', "FAIL"),
                            ('project sixteen', "FAIL"), ('project seventeen', "FAIL"),
                            ('project eighteen', "FAIL"), ('project nineteen', "FAIL"),
                            ('project twenty', "FAIL"), ('project twenty-one', "FAIL"),
                            ('project twenty-two', "FAIL"), ('project twenty-three', "FAIL"),
                            ('project twenty-four', "FAIL"), ('project twenty-five', "FAIL"),
                            ('project twenty-six', "FAIL"), ('project twenty-seven', "FAIL"),
                            ('project twenty-eight', "FAIL"), ('project twenty-nine', "FAIL"),
                            ('project thirty', "FAIL"), ('project thirty-one', "FAIL"),
                            ('project thirty-two', "FAIL"), ('project thirty-three', "FAIL"),
                            ('project thirty-four', "FAIL"), ('project thirty-five', "FAIL"),
                            ('project thirty-six', "FAIL"), ('project thirty-seven', "FAIL"),
                            ('project thirty-eight', "FAIL"), ('project thirty-nine', "FAIL"),
                            ('project forty', "FAIL"), ('project forty-one', "FAIL"),
                            ('project forty-two', "FAIL"), ('project 0', "FAIL"), ('project 1', "PROJECT1"),
                            ('project 2', "PROJECT2"), ('project 3', "PROJECT3"), ('project 4', "FAIL"),
                            ('project 5', "FAIL"), ('project 6', "FAIL"), ('project 7', "FAIL"),
                            ('project 8', "FAIL"), ('project 9', "FAIL"), ('project 10', "FAIL"),
                            ('project 11', "FAIL"), ('project 12', "FAIL"), ('project 13', "FAIL"),
                            ('project 14', "FAIL"), ('project 15', "FAIL"), ('project 16', "FAIL"),
                            ('project 17', "FAIL"), ('project 18', "FAIL"), ('project 19', "FAIL"),
                            ('project 20', "FAIL"), ('project 21', "FAIL"), ('project 22', "FAIL"),
                            ('project 23', "FAIL"), ('project 24', "FAIL"), ('project 25', "FAIL"),
                            ('project 26', "FAIL"), ('project 27', "FAIL"), ('project 28', "FAIL"),
                            ('project 29', "FAIL"), ('project 30', "FAIL"), ('project 31', "FAIL"),
                            ('project 32', "FAIL"), ('project 33', "FAIL"), ('project 34', "FAIL"),
                            ('project 35', "FAIL"), ('project 36', "FAIL"), ('project 37', "FAIL"),
                            ('project 38', "FAIL"), ('project 39', "FAIL"), ('project 40', "FAIL"),
                            ('project 41', "FAIL"), ('project 42', "FAIL"), ('the midterm', "MIDTERM"),
                            ('the final', "FINAL"), ('final assignment', "ASSIGNMENT3"),
                            ('final project', "PROJECT3"),
                            ('midterm 2', "FAIL"),
                            ('midterm 3', "FAIL"), ('midterm 4', "FAIL"),
                            ('midterm 5', "FAIL"), ('midterm 6', "FAIL"), ('midterm 7', "FAIL"),
                            ('midterm 8', "FAIL"), ('midterm 9', "FAIL"), ('midterm 10', "FAIL"),
                            ('midterm 11', "FAIL"), ('midterm 12', "FAIL"), ('midterm 13', "FAIL"),
                            ('midterm 14', "FAIL"), ('midterm 15', "FAIL"), ('midterm 16', "FAIL"),
                            ('midterm 17', "FAIL"), ('midterm 18', "FAIL"), ('midterm 19', "FAIL"),
                            ('midterm 20', "FAIL"), ('midterm 21', "FAIL"), ('midterm 22', "FAIL"),
                            ('midterm 23', "FAIL"), ('midterm 24', "FAIL"), ('midterm 25', "FAIL"),
                            ('midterm 26', "FAIL"), ('midterm 27', "FAIL"), ('midterm 28', "FAIL"),
                            ('midterm 29', "FAIL"), ('midterm 30', "FAIL"), ('midterm 31', "FAIL"),
                            ('midterm 32', "FAIL"), ('midterm 33', "FAIL"), ('midterm 34', "FAIL"),
                            ('midterm 35', "FAIL"), ('midterm 36', "FAIL"), ('midterm 37', "FAIL"),
                            ('midterm 38', "FAIL"), ('midterm 39', "FAIL"), ('midterm 40', "FAIL"),
                            ('midterm 41', "FAIL"), ('midterm 42', "FAIL"),
                            ('second midterm', "FAIL"), ('third midterm', "FAIL"),
                            ('fourth midterm', "FAIL"), ('fifth midterm', "FAIL"), ('sixth midterm', "FAIL"),
                            ('seventh midterm', "FAIL"), ('eighth midterm', "FAIL"), ('ninth midterm', "FAIL"),
                            ('tenth midterm', "FAIL"), ('the eleventh midterm', "FAIL"), ('the twelfth midterm', "FAIL"),
                            ('thirteenth midterm', "FAIL"), ('fourteenth midterm', "FAIL"),
                            ('fifteenth midterm', "FAIL"), ('sixteenth midterm', "FAIL"),
                            ('seventeenth midterm', "FAIL"), ('eighteenth midterm', "FAIL"),
                            ('nineteenth midterm', "FAIL"), ('twentieth midterm', "FAIL"),
                            ('twenty-first midterm', "FAIL"), ('twenty-second midterm', "FAIL"),
                            ('twenty-third midterm', "FAIL"), ('twenty-fourth midterm', "FAIL"),
                            ('twenty-fifth midterm', "FAIL"), ('twenty-sixth midterm', "FAIL"),
                            ('twenty-seventh midterm', "FAIL"), ('twenty-eighth midterm', "FAIL"),
                            ('twenty-ninth midterm', "FAIL"), ('thirtieth midterm', "FAIL"),
                            ('thirty-first midterm', "FAIL"), ('thirty-second midterm', "FAIL"),
                            ('thirty-third midterm', "FAIL"), ('thirty-fourth midterm', "FAIL"),
                            ('thirty-fifth midterm', "FAIL"), ('thirty-sixth midterm', "FAIL"),
                            ('thirty-seventh midterm', "FAIL"), ('thirty-eighth midterm', "FAIL"),
                            ('thirty-ninth midterm', "FAIL"), ('fortieth midterm', "FAIL"),
                            ('forty-first midterm', "FAIL"), ('forty-second midterm', "FAIL"),
                            ('final 2', "FAIL"),
                            ('final 3', "FAIL"), ('final 4', "FAIL"),
                            ('final 5', "FAIL"), ('final 6', "FAIL"), ('final 7', "FAIL"),
                            ('final 8', "FAIL"), ('final 9', "FAIL"), ('final 10', "FAIL"),
                            ('final 11', "FAIL"), ('final 12', "FAIL"), ('final 13', "FAIL"),
                            ('final 14', "FAIL"), ('final 15', "FAIL"), ('final 16', "FAIL"),
                            ('final 17', "FAIL"), ('final 18', "FAIL"), ('final 19', "FAIL"),
                            ('final 20', "FAIL"), ('final 21', "FAIL"), ('final 22', "FAIL"),
                            ('final 23', "FAIL"), ('final 24', "FAIL"), ('final 25', "FAIL"),
                            ('final 26', "FAIL"), ('final 27', "FAIL"), ('final 28', "FAIL"),
                            ('final 29', "FAIL"), ('final 30', "FAIL"), ('final 31', "FAIL"),
                            ('final 32', "FAIL"), ('final 33', "FAIL"), ('final 34', "FAIL"),
                            ('final 35', "FAIL"), ('final 36', "FAIL"), ('final 37', "FAIL"),
                            ('final 38', "FAIL"), ('final 39', "FAIL"), ('final 40', "FAIL"),
                            ('final 41', "FAIL"), ('final 42', "FAIL"),
                            ('second final', "FAIL"), ('third midterm', "FAIL"),
                            ('fourth final', "FAIL"), ('fifth midterm', "FAIL"), ('sixth midterm', "FAIL"),
                            ('seventh final', "FAIL"), ('eighth midterm', "FAIL"), ('ninth midterm', "FAIL"),
                            ('tenth final', "FAIL"), ('the eleventh midterm', "FAIL"),
                            ('the twelfth final', "FAIL"),
                            ('thirteenth final', "FAIL"), ('fourteenth final', "FAIL"),
                            ('fifteenth final', "FAIL"), ('sixteenth final', "FAIL"),
                            ('seventeenth final', "FAIL"), ('eighteenth final', "FAIL"),
                            ('nineteenth final', "FAIL"), ('twentieth final', "FAIL"),
                            ('twenty-first final', "FAIL"), ('twenty-second final', "FAIL"),
                            ('twenty-third final', "FAIL"), ('twenty-fourth final', "FAIL"),
                            ('twenty-fifth final', "FAIL"), ('twenty-sixth final', "FAIL"),
                            ('twenty-seventh final', "FAIL"), ('twenty-eighth final', "FAIL"),
                            ('twenty-ninth final', "FAIL"), ('thirtieth final', "FAIL"),
                            ('thirty-first final', "FAIL"), ('thirty-second final', "FAIL"),
                            ('thirty-third final', "FAIL"), ('thirty-fourth final', "FAIL"),
                            ('thirty-fifth final', "FAIL"), ('thirty-sixth final', "FAIL"),
                            ('thirty-seventh final', "FAIL"), ('thirty-eighth final', "FAIL"),
                            ('thirty-ninth final', "FAIL"), ('fortieth final', "FAIL"),
                            ('forty-first final', "FAIL"), ('forty-second final', "FAIL")
                            ]
        zeroArrayLength3 = [('the first assignment', "ASSIGNMENT1"), ('the second assignment', "ASSIGNMENT2"),
                            ('the third assignment', "ASSIGNMENT3"), ('the fourth assignment', "FAIL"),

                            ('week 2 assignment', "ASSIGNMENT1"), ('week 6 assignment', "ASSIGNMENT2"),
                            ('week 11 assignment', "ASSIGNMENT3"), ('week 3 project', "PROJECT1"),
                            ('week 8 project', "PROJECT2"), ('week 13 project', "PROJECT3"),
                            ('week two assignment', "ASSIGNMENT1"), ('week six assignment', "ASSIGNMENT2"),
                            ('week eleven assignment', "ASSIGNMENT3"), ('week three project', "PROJECT1"),
                            ('week eight project', "PROJECT2"), ('week thirteen project', "PROJECT3"),

                            ('week 0 assignment', "FAIL"), ('week 1 assignment', "FAIL"),
                            ('week 3 assignment', "FAIL"), ('week 4 assignment', "FAIL"),
                            ('week 5 assignment', "FAIL"), ('week 7 assignment', "FAIL"),
                            ('week 8 assignment', "FAIL"), ('week 9 assignment', "FAIL"),
                            ('week 10 assignment', "FAIL"), ('week 12 assignment', "FAIL"),
                            ('week 13 assignment', "FAIL"), ('week 14 assignment', "FAIL"),
                            ('week 15 assignment', "FAIL"), ('week 16 assignment', "FAIL"),
                            ('week 17 assignment', "FAIL"), ('week 18 assignment', "FAIL"),
                            ('week 19 assignment', "FAIL"), ('week 20 assignment', "FAIL"),
                            ('week 21 assignment', "FAIL"), ('week 22 assignment', "FAIL"),
                            ('week 23 assignment', "FAIL"), ('week 24 assignment', "FAIL"),
                            ('week 25 assignment', "FAIL"), ('week 26 assignment', "FAIL"),
                            ('week 27 assignment', "FAIL"), ('week 28 assignment', "FAIL"),
                            ('week 29 assignment', "FAIL"), ('week 30 assignment', "FAIL"),
                            ('week 31 assignment', "FAIL"), ('week 32 assignment', "FAIL"),
                            ('week 33 assignment', "FAIL"), ('week 34 assignment', "FAIL"),
                            ('week 35 assignment', "FAIL"), ('week 36 assignment', "FAIL"),
                            ('week 37 assignment', "FAIL"), ('week 38 assignment', "FAIL"),
                            ('week 39 assignment', "FAIL"), ('week 40 assignment', "FAIL"),
                            ('week 41 assignment', "FAIL"), ('week 42 assignment', "FAIL"),

                            ('week zero assignment', "FAIL"), ('week one assignment', "FAIL"),
                            ('week three assignment', "FAIL"), ('week four assignment', "FAIL"),
                            ('week five assignment', "FAIL"), ('week seven assignment', "FAIL"),
                            ('week eight assignment', "FAIL"), ('week nine assignment', "FAIL"),
                            ('week ten assignment', "FAIL"), ('week twelve assignment', "FAIL"),
                            ('week thirteenth assignment', "FAIL"), ('week fourteenth assignment', "FAIL"),
                            ('week fifteenth assignment', "FAIL"), ('week sixteenth assignment', "FAIL"),
                            ('week seventeenth assignment', "FAIL"), ('week eighteenth assignment', "FAIL"),
                            ('week nineteenth assignment', "FAIL"), ('week twentieth assignment', "FAIL"),
                            ('week twenty-first assignment', "FAIL"), ('week twenty-second assignment', "FAIL"),
                            ('week twenty-third assignment', "FAIL"), ('week twenty-fourth assignment', "FAIL"),
                            ('week twenty-fifth assignment', "FAIL"), ('week twenty-sixth assignment', "FAIL"),
                            ('week twenty-seventh assignment', "FAIL"), ('week twenty-eighth assignment', "FAIL"),
                            ('week twenty-ninth assignment', "FAIL"), ('week thirtieth assignment', "FAIL"),
                            ('week thirty-first assignment', "FAIL"), ('week thirty-second assignment', "FAIL"),
                            ('week thirty-third assignment', "FAIL"), ('week thirty-fourth assignment', "FAIL"),
                            ('week thirty-fifth assignment', "FAIL"), ('week thirty-sixth assignment', "FAIL"),
                            ('week thirty-seventh assignment', "FAIL"), ('week thirty-eighth assignment', "FAIL"),
                            ('week thirty-ninth assignment', "FAIL"), ('week fortieth assignment', "FAIL"),
                            ('week forty-first assignment', "FAIL"), ('week forty-second assignment', "FAIL"),

                            ('week 0 project', "FAIL"), ('week 1 project', "FAIL"),
                            ('week 2 project', "FAIL"), ('week 4 project', "FAIL"),
                            ('week 5 project', "FAIL"), ('week 6 project', "FAIL"),
                            ('week 7 project', "FAIL"), ('week 9 project', "FAIL"),
                            ('week 10 project', "FAIL"), ('week 11 project', "FAIL"),
                            ('week 12 project', "FAIL"), ('week 14 project', "FAIL"),
                            ('week 15 project', "FAIL"), ('week 16 project', "FAIL"),
                            ('week 17 project', "FAIL"), ('week 18 project', "FAIL"),
                            ('week 19 project', "FAIL"), ('week 20 project', "FAIL"),
                            ('week 21 project', "FAIL"), ('week 22 project', "FAIL"),
                            ('week 23 project', "FAIL"), ('week 24 project', "FAIL"),
                            ('week 25 project', "FAIL"), ('week 26 project', "FAIL"),
                            ('week 27 project', "FAIL"), ('week 28 project', "FAIL"),
                            ('week 29 project', "FAIL"), ('week 30 project', "FAIL"),
                            ('week 31 project', "FAIL"), ('week 32 project', "FAIL"),
                            ('week 33 project', "FAIL"), ('week 34 project', "FAIL"),
                            ('week 35 project', "FAIL"), ('week 36 project', "FAIL"),
                            ('week 37 project', "FAIL"), ('week 38 project', "FAIL"),
                            ('week 39 project', "FAIL"), ('week 40 project', "FAIL"),
                            ('week 41 project', "FAIL"), ('week 42 project', "FAIL"),

                            ('week zero project', "FAIL"), ('week one project', "FAIL"),
                            ('week three project', "FAIL"), ('week four project', "FAIL"),
                            ('week five project', "FAIL"), ('week seven project', "FAIL"),
                            ('week eight project', "FAIL"), ('week nine project', "FAIL"),
                            ('week ten project', "FAIL"), ('week twelve project', "FAIL"),
                            ('week thirteenth project', "FAIL"), ('week fourteenth project', "FAIL"),
                            ('week fifteenth project', "FAIL"), ('week sixteenth project', "FAIL"),
                            ('week seventeenth project', "FAIL"), ('week eighteenth project', "FAIL"),
                            ('week nineteenth project', "FAIL"), ('week twentieth project', "FAIL"),
                            ('week twenty-first project', "FAIL"), ('week twenty-second project', "FAIL"),
                            ('week twenty-third project', "FAIL"), ('week twenty-fourth project', "FAIL"),
                            ('week twenty-fifth project', "FAIL"), ('week twenty-sixth project', "FAIL"),
                            ('week twenty-seventh project', "FAIL"), ('week twenty-eighth project', "FAIL"),
                            ('week twenty-ninth project', "FAIL"), ('week thirtieth project', "FAIL"),
                            ('week thirty-first project', "FAIL"), ('week thirty-second project', "FAIL"),
                            ('week thirty-third project', "FAIL"), ('week thirty-fourth project', "FAIL"),
                            ('week thirty-fifth project', "FAIL"), ('week thirty-sixth project', "FAIL"),
                            ('week thirty-seventh project', "FAIL"), ('week thirty-eighth project', "FAIL"),
                            ('week thirty-ninth project', "FAIL"), ('week fortieth project', "FAIL"),
                            ('week forty-first project', "FAIL"), ('week forty-second project', "FAIL"),

                            ('week two assignment', "ASSIGNMENT1"), ('week six assignment', "ASSIGNMENT2"),
                            ('week eleven assignment', "ASSIGNMENT3"), ('week three project', "PROJECT1"),
                            ('week eight project', "PROJECT2"), ('week thirteen project', "PROJECT3"),


                            ('the fifth assignment', "FAIL"), ('the sixth assignment', "FAIL"),
                            ('the seventh assignment', "FAIL"), ('the eighth assignment', "FAIL"),
                            ('the ninth assignment', "FAIL"), ('the tenth assignment', "FAIL"),
                            ('the eleventh assignment', "FAIL"), ('the twelfth assignment', "FAIL"),
                            ('the thirteenth assignment', "FAIL"), ('the fourteenth assignment', "FAIL"),
                            ('the fifteenth assignment', "FAIL"), ('the sixteenth assignment', "FAIL"),
                            ('the seventeenth assignment', "FAIL"), ('the eighteenth assignment', "FAIL"),
                            ('the nineteenth assignment', "FAIL"), ('the twentieth assignment', "FAIL"),
                            ('the twenty-first assignment', "FAIL"), ('the twenty-second assignment', "FAIL"),
                            ('the twenty-third assignment', "FAIL"), ('the twenty-fourth assignment', "FAIL"),
                            ('the twenty-fifth assignment', "FAIL"), ('the twenty-sixth assignment', "FAIL"),
                            ('the twenty-seventh assignment', "FAIL"), ('the twenty-eighth assignment', "FAIL"),
                            ('the twenty-ninth assignment', "FAIL"), ('the thirtieth assignment', "FAIL"),
                            ('the thirty-first assignment', "FAIL"), ('the thirty-second assignment', "FAIL"),
                            ('the thirty-third assignment', "FAIL"), ('the thirty-fourth assignment', "FAIL"),
                            ('the thirty-fifth assignment', "FAIL"), ('the thirty-sixth assignment', "FAIL"),
                            ('the thirty-seventh assignment', "FAIL"), ('the thirty-eighth assignment', "FAIL"),
                            ('the thirty-ninth assignment', "FAIL"), ('the fortieth assignment', "FAIL"),
                            ('the forty-first assignment', "FAIL"), ('the forty-second assignment', "FAIL"),


                            ('the first project', "PROJECT1"), ('the second project', "PROJECT2"),
                            ('the third project', "PROJECT3"), ('the fourth project', "FAIL"),
                            ('the fifth project', "FAIL"), ('the sixth project', "FAIL"),
                            ('the seventh project', "FAIL"), ('the eighth project', "FAIL"),
                            ('the ninth project', "FAIL"), ('the tenth project', "FAIL"),
                            ('the eleventh project', "FAIL"), ('the twelfth project', "FAIL"),
                            ('the thirteenth project', "FAIL"), ('the fourteenth project', "FAIL"),
                            ('the fifteenth project', "FAIL"), ('the sixteenth project', "FAIL"),
                            ('the seventeenth project', "FAIL"), ('the eighteenth project', "FAIL"),
                            ('the nineteenth project', "FAIL"), ('the twentieth project', "FAIL"),
                            ('the twenty-first project', "FAIL"), ('the twenty-second project', "FAIL"),
                            ('the twenty-third project', "FAIL"), ('the twenty-fourth project', "FAIL"),
                            ('the twenty-fifth project', "FAIL"), ('the twenty-sixth project', "FAIL"),
                            ('the twenty-seventh project', "FAIL"), ('the twenty-eighth project', "FAIL"),
                            ('the twenty-ninth project', "FAIL"), ('the thirtieth project', "FAIL"),
                            ('the thirty-first project', "FAIL"), ('the thirty-second project', "FAIL"),
                            ('the thirty-third project', "FAIL"), ('the thirty-fourth project', "FAIL"),
                            ('the thirty-fifth project', "FAIL"), ('the thirty-sixth project', "FAIL"),
                            ('the thirty-seventh project', "FAIL"), ('the thirty-eighth project', "FAIL"),
                            ('the thirty-ninth project', "FAIL"), ('the fortieth project', "FAIL"),
                            ('the forty-first project', "FAIL"), ('the forty-second project', "FAIL"),
                            ('the final assignment', "ASSIGNMENT3"), ('the final project', "PROJECT3")
                            ]
        zeroArrayLength4 = [('the week 1 assignment', "FAIL"), ('the week 2 assignment', "ASSIGNMENT1"),
                            ('the week 3 assignment', "FAIL"), ('the week 4 assignment', "FAIL"),
                            ('the week 5 assignment', "FAIL"), ('the week 6 assignment', "ASSIGNMENT2"),
                            ('the week 7 assignment', "FAIL"), ('the week 8 assignment', "FAIL"),
                            ('the week 9 assignment', "FAIL"), ('the week 10 assignment', "FAIL"),
                            ('the week 11 assignment', "ASSIGNMENT3"), ('the week 12 assignment', "FAIL"),
                            ('the week 13 assignment', "FAIL"), ('the week 14 assignment', "FAIL"),
                            ('the week 15 assignment', "FAIL"), ('the week 16 assignment', "FAIL"),

                            ('the week one assignment', "FAIL"), ('the week two assignment', "ASSIGNMENT1"),
                            ('the week three assignment', "FAIL"), ('the week four assignment', "FAIL"),
                            ('the week five assignment', "FAIL"), ('the week six assignment', "ASSIGNMENT2"),
                            ('the week seven assignment', "FAIL"), ('the week eight assignment', "FAIL"),
                            ('the week nine assignment', "FAIL"), ('the week ten assignment', "FAIL"),
                            ('the week eleven assignment', "ASSIGNMENT3"), ('the week twelve assignment', "FAIL"),
                            ('the week thirteen assignment', "FAIL"), ('the week fourteen assignment', "FAIL"),
                            ('the week fifteen assignment', "FAIL"), ('the week sixteen assignment', "FAIL"),

                            ('the week 1 project', "FAIL"), ('the week 2 project', "FAIL"),
                            ('the week 3 project', "PROJECT1"), ('the week 4 project', "FAIL"),
                            ('the week 5 project', "FAIL"), ('the week 6 project', "FAIL"),
                            ('the week 7 project', "FAIL"), ('the week 8 project', "PROJECT2"),
                            ('the week 9 project', "FAIL"), ('the week 10 project', "FAIL"),
                            ('the week 11 project', "FAIL"), ('the week 12 project', "FAIL"),
                            ('the week 13 project', "PROJECT3"), ('the week 14 project', "FAIL"),
                            ('the week 15 project', "FAIL"), ('the week 16 project', "FAIL"),

                            ('the week one project', "FAIL"), ('the week two project', "FAIL"),
                            ('the week three project', "PROJECT1"), ('the week four project', "FAIL"),
                            ('the week five project', "FAIL"), ('the week six project', "FAIL"),
                            ('the week seven project', "FAIL"), ('the week eight project', "PROJECT2"),
                            ('the week nine project', "FAIL"), ('the week ten project', "FAIL"),
                            ('the week eleven project', "FAIL"), ('the week twelve project', "FAIL"),
                            ('the week thirteen project', "PROJECT3"), ('the week fourteen project', "FAIL"),
                            ('the week fifteen project', "FAIL"), ('the week sixteen project', "FAIL"),

                            ('assignment from week 1', "FAIL"), ('assignment from week 2', "ASSIGNMENT1"),
                            ('assignment from week 3', "FAIL"), ('assignment from week 4', "FAIL"),
                            ('assignment from week 5', "FAIL"), ('assignment from week 6', "ASSIGNMENT2"),
                            ('assignment from week 7', "FAIL"), ('assignment from week 8', "FAIL"),
                            ('assignment from week 9', "FAIL"), ('assignment from week 10', "FAIL"),
                            ('assignment from week 11', "ASSIGNMENT3"), ('assignment from week 12', "FAIL"),
                            ('assignment from week 13', "FAIL"), ('assignment from week 14', "FAIL"),
                            ('assignment from week 15', "FAIL"), ('assignment from week 16', "FAIL"),

                            ('assignment from week one', "FAIL"), ('assignment from week two', "ASSIGNMENT1"),
                            ('assignment from week three', "FAIL"), ('assignment from week four', "FAIL"),
                            ('assignment from week five', "FAIL"), ('assignment from week six', "ASSIGNMENT2"),
                            ('assignment from week seven', "FAIL"), ('assignment from week eight', "FAIL"),
                            ('assignment from week nine', "FAIL"), ('assignment from week ten', "FAIL"),
                            ('assignment from week eleven', "ASSIGNMENT3"), ('assignment from week twelve', "FAIL"),
                            ('assignment from week thirteen', "FAIL"), ('assignment from week fourteen', "FAIL"),
                            ('assignment from week fifteen', "FAIL"), ('assignment from week sixteen', "FAIL"),

                            ('project from week 1', "FAIL"), ('project from week 2', "FAIL"),
                            ('project from week 3', "PROJECT1"), ('project from week 4', "FAIL"),
                            ('project from week 5', "FAIL"), ('project from week 6', "FAIL"),
                            ('project from week 7', "FAIL"), ('project from week 8', "PROJECT2"),
                            ('project from week 9', "FAIL"), ('project from week 10', "FAIL"),
                            ('project from week 11', "FAIL"), ('project from week 12', "FAIL"),
                            ('project from week 13', "PROJECT3"), ('project from week 14', "FAIL"),
                            ('project from week 15', "FAIL"), ('project from week 16', "FAIL"),

                            ('project from week one', "FAIL"), ('project from week two', "FAIL"),
                            ('project from week three', "PROJECT1"), ('project from week four', "FAIL"),
                            ('project from week five', "FAIL"), ('project from week six', "FAIL"),
                            ('project from week seven', "FAIL"), ('project from week eight', "PROJECT2"),
                            ('project from week nine', "FAIL"), ('project from week ten', "FAIL"),
                            ('project from week eleven', "FAIL"), ('project from week twelve', "FAIL"),
                            ('project from week thirteen', "PROJECT3"), ('project from week fourteen', "FAIL"),
                            ('project from week fifteen', "FAIL"), ('project from week sixteen', "FAIL"),

                            ('assignment due week 1', "FAIL"), ('assignment due week 2', "FAIL"),
                            ('assignment due week 3', "ASSIGNMENT1"), ('assignment due week 4', "FAIL"),
                            ('assignment due week 5', "FAIL"), ('assignment due week 6', "FAIL"),
                            ('assignment due week 7', "ASSIGNMENT2"), ('assignment due week 8', "FAIL"),
                            ('assignment due week 9', "FAIL"), ('assignment due week 10', "FAIL"),
                            ('assignment due week 11', "FAIL"), ('assignment due week 12', "ASSIGNMENT3"),
                            ('assignment due week 13', "FAIL"), ('assignment due week 14', "FAIL"),
                            ('assignment due week 15', "FAIL"), ('assignment due week 16', "FAIL"),

                            ('assignment due week one', "FAIL"), ('assignment due week two', "FAIL"),
                            ('assignment due week three', "ASSIGNMENT1"), ('assignment due week four', "FAIL"),
                            ('assignment due week five', "FAIL"), ('assignment due week six', "FAIL"),
                            ('assignment due week seven', "ASSIGNMENT2"), ('assignment due week eight', "FAIL"),
                            ('assignment due week nine', "FAIL"), ('assignment due week ten', "FAIL"),
                            ('assignment due week eleven', "FAIL"), ('assignment due week twelve', "ASSIGNMENT3"),
                            ('assignment due week thirteen', "FAIL"), ('assignment due week fourteen', "FAIL"),
                            ('assignment due week fifteen', "FAIL"), ('assignment due week sixteen', "FAIL"),

                            ('project due week 1', "FAIL"), ('project due week 2', "FAIL"),
                            ('project due week 3', "FAIL"), ('project due week 4', "FAIL"),
                            ('project due week 5', "FAIL"), ('project due week 6', "PROJECT1"),
                            ('project due week 7', "FAIL"), ('project due week 8', "FAIL"),
                            ('project due week 9', "FAIL"), ('project due week 10', "FAIL"),
                            ('project due week 11', "PROJECT2"), ('project due week 12', "FAIL"),
                            ('project due week 13', "FAIL"), ('project due week 14', "FAIL"),
                            ('project due week 15', "FAIL"), ('project due week 16', "PROJECT3"),

                            ('project due week one', "FAIL"), ('project due week two', "FAIL"),
                            ('project due week three', "FAIL"), ('project due week four', "FAIL"),
                            ('project due week five', "FAIL"), ('project due week six', "PROJECT1"),
                            ('project due week seven', "FAIL"), ('project due week eight', "FAIL"),
                            ('project due week nine', "FAIL"), ('project due week ten', "FAIL"),
                            ('project due week eleven', "PROJECT2"), ('project due week twelve', "FAIL"),
                            ('project due week thirteen', "FAIL"), ('project due week fourteen', "FAIL"),
                            ('project due week fifteen', "FAIL"), ('project due week sixteen', "PROJECT3")

                            ]
        zeroArrayLength5 = [('assignment due on week 1', "FAIL"), ('assignment due on week 2', "FAIL"),
                            ('assignment due on week 3', "ASSIGNMENT1"), ('assignment due on week 4', "FAIL"),
                            ('assignment due on week 5', "FAIL"), ('assignment due on week 6', "FAIL"),
                            ('assignment due on week 7', "ASSIGNMENT2"), ('assignment due on week 8', "FAIL"),
                            ('assignment due on week 9', "FAIL"), ('assignment due on week 10', "FAIL"),
                            ('assignment due on week 11', "FAIL"), ('assignment due on week 12', "ASSIGNMENT3"),
                            ('assignment due on week 13', "FAIL"), ('assignment due on week 14', "FAIL"),
                            ('assignment due on week 15', "FAIL"), ('assignment due on week 16', "FAIL"),

                            ('assignment due on week one', "FAIL"), ('assignment due on week two', "FAIL"),
                            ('assignment due on week three', "ASSIGNMENT1"), ('assignment due on week four', "FAIL"),
                            ('assignment due on week five', "FAIL"), ('assignment due on week six', "FAIL"),
                            ('assignment due on week seven', "ASSIGNMENT2"), ('assignment due on week eight', "FAIL"),
                            ('assignment due on week nine', "FAIL"), ('assignment due on week ten', "FAIL"),
                            ('assignment due on week eleven', "FAIL"), ('assignment due on week twelve', "ASSIGNMENT3"),
                            ('assignment due on week thirteen', "FAIL"), ('assignment due on week fourteen', "FAIL"),
                            ('assignment due on week fifteen', "FAIL"), ('assignment due on week sixteen', "FAIL"),

                            ('project due on week 1', "FAIL"), ('project due on week 2', "FAIL"),
                            ('project due on week 3', "FAIL"), ('project due on week 4', "FAIL"),
                            ('project due on week 5', "FAIL"), ('project due on week 6', "PROJECT1"),
                            ('project due on week 7', "FAIL"), ('project due on week 8', "FAIL"),
                            ('project due on week 9', "FAIL"), ('project due on week 10', "FAIL"),
                            ('project due on week 11', "PROJECT2"), ('project due on week 12', "FAIL"),
                            ('project due on week 13', "FAIL"), ('project due on week 14', "FAIL"),
                            ('project due on week 15', "FAIL"), ('project due on week 16', "PROJECT3"),

                            ('project due on week one', "FAIL"), ('project due on week two', "FAIL"),
                            ('project due on week three', "FAIL"), ('project due on week four', "FAIL"),
                            ('project due on week five', "FAIL"), ('project due on week six', "PROJECT1"),
                            ('project due on week seven', "FAIL"), ('project due on week eight', "FAIL"),
                            ('project due on week nine', "FAIL"), ('project due on week ten', "FAIL"),
                            ('project due on week eleven', "PROJECT2"), ('project due on week twelve', "FAIL"),
                            ('project due on week thirteen', "FAIL"), ('project due on week fourteen', "FAIL"),
                            ('project due on week fifteen', "FAIL"), ('project due on week sixteen', "PROJECT3")]
        zeroMasterArray = [(5, zeroArrayLength5), (4, zeroArrayLength4), (3, zeroArrayLength3),(2, zeroArrayLength2), (1, zeroArrayLength1)]
        subCompares.append(zeroMasterArray)

        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        # ARRAY OF <1> WORDS
        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        oneArrayLength1 = [('released', 'RELEASEDATE'), ('available', 'RELEASEDATE'), ('due','DUEDATE')]
        oneMasterArray = [(1,oneArrayLength1)]
        subCompares.append(oneMasterArray)

        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        # ARRAY OF <2> WORDS
        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        twoArrayLength1 = [('i', 'NULL'), ('we', 'NULL'), ('you', 'NULL'), ('my', 'NULL'), ('one', 'NULL')]
        twoMasterArray = [(1,twoArrayLength1)]
        subCompares.append(twoMasterArray)

        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        # ARRAY OF <3> WORDS
        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        threeArrayLength1 = [('begin', 'NULL'), ('start', 'NULL'), ('write', 'NULL'),  ('get', 'NULL'),
                             ('open', 'NULL'), ('answer', 'NULL'),
                             ('getting', 'NULL'), ('starts', 'NULL')]
        threeMasterArray = [(1,threeArrayLength1)]
        subCompares.append(threeMasterArray)

        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        # ARRAY OF <4> WORDS
        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        fourArrayLength1 = [('time', 'NULL'), ('date', 'NULL'), ('day', 'NULL'), ('week', 'NULL'),('weeks', 'NULL'),
                            ('times', 'NULL'), ('dates', 'NULL'), ('days', 'NULL')]
        foureMasterArray = [(1,fourArrayLength1)]
        subCompares.append(foureMasterArray)

        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        # ARRAY OF <5> WORDS
        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        fiveArrayLength1 = [('does', 'NULL'), ('will', 'NULL'), ('can', 'NULL')]
        fiveMasterArray = [(1,fiveArrayLength1)]
        subCompares.append(fiveMasterArray)

        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        # ARRAY OF <6> WORDS
        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        sixArrayLength1 = [('can', 'NULL'), ('must', 'NULL'), ('should', 'NULL'), ('need', 'NULL'), ('do', 'NULL')]
        sixMasterArray = [(1, sixArrayLength1)]
        subCompares.append(sixMasterArray)

        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        # ARRAY OF <7> WORDS
        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        sevenArrayLength1 = [('is', 'NULL'), ('will', 'NULL'), ('are', 'NULL'), ('be', 'NULL'), ('can', 'NULL'),
                             ('must', 'NULL'), ('does', 'NULL')]
        sevenArrayLength2 = [('will be', 'NULL'), ('to be', 'NULL'), ('can be', 'NULL'), ('must be', 'NULL')]
        sevenMasterArray = [(2, sevenArrayLength2), (1, sevenArrayLength1)]
        subCompares.append(sevenMasterArray)

        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        # ARRAY OF <8> WORDS
        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        eightArrayLength1 = [('for', 'NULL'), ('of', 'NULL'),('on', 'NULL'), ('in', 'NULL'), ('during', 'NULL')]
        eightMasterArray = [(1, eightArrayLength1)]
        subCompares.append(eightMasterArray)

        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        # ARRAY OF <9> WORDS
        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        _9ArrayLength1 = [('release', 'RELEASEDATE'),('available', 'RELEASEDATE'),('open', 'RELEASEDATE'), ('due', 'DUEDATE')]
        _9MasterArray = [(1, _9ArrayLength1)]
        subCompares.append(_9MasterArray)

        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        # ARRAY OF <10> WORDS
        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        _10ArrayLength1 = [('what', 'NULL'), ('when', 'NULL')]
        _10MasterArray = [(1, _10ArrayLength1)]
        subCompares.append(_10MasterArray)

        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        # ARRAY OF [11] WORDS
        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        _11ArrayLength1 = [('released', 'NULL'), ('available', 'NULL'), ('distributed', 'NULL'),('open', 'RELEASEDATE')]
        _11MasterArray = [(1, _11ArrayLength1)]
        subCompares.append(_11MasterArray)

        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        # ARRAY OF [12] WORDS
        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        _12ArrayLength1 = [('submitted', 'NULL')]
        _12ArrayLength2 = [('turned in', 'NULL')]
        _12MasterArray = [(2, _12ArrayLength2), (1, _12ArrayLength1)]
        subCompares.append(_12MasterArray)

        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        # ARRAY OF [13] WORDS
        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        _13ArrayLength1 = [('submit', 'NULL'), ('submitting', 'NULL'), ('complete', 'NULL'), ('completed', 'NULL'),
                           ('finish', 'NULL'), ('do', 'NULL'), ('code', 'NULL'), ('write', 'NULL'), ('submitting', 'NULL'),
                           ('submitted', 'NULL')]
        _13ArrayLength2 = [('turn in', 'NULL'), ('turned in', 'NULL')]
        _13MasterArray = [(2, _13ArrayLength2), (1,_13ArrayLength1)]
        subCompares.append(_13MasterArray)

        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        # ARRAY OF [14] WORDS
        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        _14ArrayLength1 = [('have', 'NULL'), ('get', 'NULL')]
        _14MasterArray = [(1,_14ArrayLength1)]
        subCompares.append(_14MasterArray)

        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        # ARRAY OF [15] WORDS
        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        _15ArrayLength1 = [('completed', 'NULL')]
        _15ArrayLength2 = [('completed by ', 'NULL')]
        _15MasterArray = [(2, _15ArrayLength2), (1, _15ArrayLength1)]
        subCompares.append(_15MasterArray)

        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        # ARRAY OF [16] WORDS
        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        _16ArrayLength1 = [('close', 'NULL'), ('end', 'NULL')]
        _16MasterArray = [(1, _16ArrayLength1)]
        subCompares.append(_16MasterArray)

        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        # ARRAY OF [17] WORDS
        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        _17ArrayLength1 = [('many', 'NULL'), ('much', 'NULL')]
        _17MasterArray = [(1, _17ArrayLength1)]
        subCompares.append(_17MasterArray)

        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        # ARRAY OF [18] WORDS
        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        _18ArrayLength1 = [('that', 'NULL'), ('the', 'NULL'),('there', 'NULL'), ('this', 'NULL'),('those', 'NULL')]
        _18MasterArray = [(1, _18ArrayLength1)]
        subCompares.append(_18MasterArray)

        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        # ARRAY OF [19] WORDS
        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        _19ArrayLength1 = [('percentage', 'NULL'), ('weight', 'NULL'), ('grade', 'NULL'), ('worth', 'NULL')]
        _19MasterArray = [(1, _19ArrayLength1)]
        subCompares.append(_19MasterArray)

        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        # ARRAY OF [20] WORDS
        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        _20ArrayLength1 = [('announcements', 'NULL')]
        _20ArrayLength2 = [('class announcements', 'NULL'), ('piazza announcements', 'NULL'),
                           ('weekly announcements', 'NULL'), ('daily announcements', 'NULL'),
                           ('general announcements', 'NULL'), ('canvas announcements', 'NULL')]
        _20MasterArray = [(2, _20ArrayLength2), (1, _20ArrayLength1)]
        subCompares.append(_20MasterArray)

        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        # ARRAY OF [21] WORDS
        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        _21ArrayLength1 = [('goals', 'NULL')]
        _21ArrayLength2 = [('learning goals', 'NULL')]
        _21ArrayLength3 = [('primary learning goals', 'NULL')]
        _21MasterArray = [(3, _21ArrayLength3),(2, _21ArrayLength2), (1, _21ArrayLength1)]
        subCompares.append(_21MasterArray)

        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        # ARRAY OF [22] WORDS
        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        _22ArrayLength2 = [('week zero', "FAIL"), ('week one', "WEEK1"),
                            ('week two', "WEEK2"), ('week three', "WEEK3"),
                            ('week four', "WEEK4"), ('week five', "WEEK5"),
                            ('week six', "WEEK6"), ('week seven', "WEEK7"),
                            ('week eight', "WEEK8"), ('week nine', "WEEK9"),
                            ('week ten', "WEEK10"), ('week eleven', "WEEK11"),
                            ('week twelve', "WEEK12"), ('week thirteen', "WEEK13"),
                            ('week fourteen', "WEEK14"), ('week fifteen', "WEEK15"),
                            ('week sixteen', "WEEK16"), ('week seventeen', "FAIL"),
                            ('week eighteen', "FAIL"), ('week nineteen', "FAIL"),
                            ('week twenty', "FAIL"), ('week twenty-one', "FAIL"),
                            ('week twenty-two', "FAIL"), ('week twenty-three', "FAIL"),
                            ('week twenty-four', "FAIL"), ('week twenty-five', "FAIL"),
                            ('week twenty-six', "FAIL"), ('week twenty-seven', "FAIL"),
                            ('week twenty-eight', "FAIL"), ('week twenty-nine', "FAIL"),
                            ('week thirty', "FAIL"), ('week thirty-one', "FAIL"),
                            ('week thirty-two', "FAIL"), ('week thirty-three', "FAIL"),
                            ('week thirty-four', "FAIL"), ('week thirty-five', "FAIL"),
                            ('week thirty-six', "FAIL"), ('week thirty-seven', "FAIL"),
                            ('week thirty-eight', "FAIL"), ('week thirty-nine', "FAIL"),
                            ('week forty', "FAIL"), ('week forty-one', "FAIL"),
                            ('week forty-two', "FAIL"), ('week 0', "FAIL"),
                            ('week 1', "WEEK1"), ('week 2', "WEEK2"),
                            ('week 3', "WEEK3"), ('week 4', "WEEK4"),
                            ('week 5', "WEEK5"), ('week 6', "WEEK6"), ('week 7', "WEEK7"),
                            ('week 8', "WEEK8"), ('week 9', "WEEK9"), ('week 10', "WEEK10"),
                            ('week 11', "WEEK11"), ('week 12', "WEEK12"), ('week 13', "WEEK13"),
                            ('week 14', "WEEK14"), ('week 15', "WEEK15"), ('week 16', "WEEK16"),
                            ('week 17', "FAIL"), ('week 18', "FAIL"), ('week 19', "FAIL"),
                            ('week 20', "FAIL"), ('week 21', "FAIL"), ('week 22', "FAIL"),
                            ('week 23', "FAIL"), ('week 24', "FAIL"), ('week 25', "FAIL"),
                            ('week 26', "FAIL"), ('week 27', "FAIL"), ('week 28', "FAIL"),
                            ('week 29', "FAIL"), ('week 30', "FAIL"), ('week 31', "FAIL"),
                            ('week 32', "FAIL"), ('week 33', "FAIL"), ('week 34', "FAIL"),
                            ('week 35', "FAIL"), ('week 36', "FAIL"), ('week 37', "FAIL"),
                            ('week 38', "FAIL"), ('week 39', "FAIL"), ('week 40', "FAIL"),
                            ('week 41', "FAIL"), ('week 42', "FAIL"), ('final week', "WEEK16")]
        _22ArrayLength3 = [('the first week', "ASSIGNMENT1"), ('the second week', "ASSIGNMENT2"),
                            ('the third week', "ASSIGNMENT3"), ('the fourth week', "FAIL"),
                            ('the fifth week', "FAIL"), ('the sixth week', "FAIL"),
                            ('the seventh week', "FAIL"), ('the eighth week', "FAIL"),
                            ('the ninth week', "FAIL"), ('the tenth week', "FAIL"),
                            ('the eleventh week', "FAIL"), ('the twelfth week', "FAIL"),
                            ('the thirteenth week', "FAIL"), ('the fourteenth week', "FAIL"),
                            ('the fifteenth week', "FAIL"), ('the sixteenth week', "FAIL"),
                            ('the seventeenth week', "FAIL"), ('the eighteenth week', "FAIL"),
                            ('the nineteenth week', "FAIL"), ('the twentieth week', "FAIL"),
                            ('the twenty-first week', "FAIL"), ('the twenty-second week', "FAIL"),
                            ('the twenty-third week', "FAIL"), ('the twenty-fourth week', "FAIL"),
                            ('the twenty-fifth week', "FAIL"), ('the twenty-sixth week', "FAIL"),
                            ('the twenty-seventh week', "FAIL"), ('the twenty-eighth week', "FAIL"),
                            ('the twenty-ninth week', "FAIL"), ('the thirtieth week', "FAIL"),
                            ('the thirty-first week', "FAIL"), ('the thirty-second week', "FAIL"),
                            ('the thirty-third week', "FAIL"), ('the thirty-fourth week', "FAIL"),
                            ('the thirty-fifth week', "FAIL"), ('the thirty-sixth week', "FAIL"),
                            ('the thirty-seventh week', "FAIL"), ('the thirty-eighth week', "FAIL"),
                            ('the thirty-ninth week', "FAIL"), ('the fortieth week', "FAIL"),
                            ('the forty-first week', "FAIL"), ('the forty-second week', "FAIL"),
                           ('the final week', "WEEK16")]
        _22MasterArray = [(3, _22ArrayLength3),(2, _22ArrayLength2)]
        subCompares.append(_22MasterArray)

        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        # ARRAY OF [23] WORDS
        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        _23ArrayLength1 = [('write', 'NULL')]
        _23ArrayLength2 = [('work on', 'NULL'), ('working on', 'NULL')]
        _23MasterArray = [(2, _23ArrayLength2), (1, _23ArrayLength1)]
        subCompares.append(_23MasterArray)

        # =============================================================================================================
        # Example 0
        # =============================================================================================================
        example0 = ("when will <0> be <1>".split(), 0, 9, "-0", "-1", "@")
        masterExamplesArray.append(example0)

        # =============================================================================================================
        # Example 1
        # =============================================================================================================
        # When "can/must/should" "we/i/you" "start/begin" working on "Object"
        example1 = ("when <6> <2> <3> working on <0>".split(), 1, 9, "-3", "+RELEASEDATE", "@")
        masterExamplesArray.append(example1)

        # =============================================================================================================
        # Example 2
        # =============================================================================================================
        # What "can/must/should" "you/we/i" "start/begin" on "Object"
        example2 = ("when <6> <2> <3> on <0> ".split(), 1, 9, "-3", "+RELEASEDATE", "@")
        masterExamplesArray.append(example2)

        # =============================================================================================================
        # Example 3
        # =============================================================================================================
        # What "can/must/should" "you/we/i" "start/begin" "Object"
        example3 = ("when <6> <2> <3> <0> ".split(), 1, 9, "-3", "+RELEASEDATE", "@")
        masterExamplesArray.append(example3)

        # =============================================================================================================
        # Example 4
        # =============================================================================================================
        # what "time" "does/will" "object" "start/begin/open"
        example4 = ("what <4> <5> <0> <3>".split(), 1, 9, "-2", "+RELEASEDATE", "@")
        masterExamplesArray.append(example4)

        # =============================================================================================================
        # Example 5
        # =============================================================================================================
        # What "time" "is/will-be" "assignment", What day is the midterm
        example5 = ("what <4> <7> <0>".split(), 1, 9, "-2", "+RELEASEDATE", "@")
        masterExamplesArray.append(example5)

        # =============================================================================================================
        # Example 6
        # =============================================================================================================
        # "What" "is/will-be" the "release/due" "date/week" "for/on/in" "Object"
        example6 = ("[10] <7> the <9> <4> <8> <0>".split(), 1, 9, "-5", "-2", "@")
        masterExamplesArray.append(example6)

        # =============================================================================================================
        # Example 7
        # =============================================================================================================
        # "when "will/does" "object" "open/start"
        example7 = ("when <5> <0> <3>".split(), 1, 9, "-1", "+RELEASEDATE", "@")
        masterExamplesArray.append(example7)

        # =============================================================================================================
        # Example 8
        # =============================================================================================================
        # "when is "object" due
        example8 = ("when <7> <0> due".split(), 1, 9, "-1", "+DUEDATE", "@")
        masterExamplesArray.append(example8)

        # =============================================================================================================
        # Example 9
        # =============================================================================================================
        # "what "time/date/day/week" is "object" "released"
        example9 = ("What <4> <7> <0> [11]".split(), 1, 9, "-2", "+RELEASEDATE", "@")
        masterExamplesArray.append(example9)

        # =============================================================================================================
        # Example 10
        # =============================================================================================================
        # "what "time/date/day/week" is the "object"
        example10 = ("What <4> <7> the <0>".split(), 1, 9, "-2", "+RELEASEDATE", "@")
        masterExamplesArray.append(example10)

        # =============================================================================================================
        # Example 11
        # =============================================================================================================
        # "what "time/date/day/week" is the "object"
        example11 = ("When <5> <0> <9>".split(), 1, 9, "-1", "+RELEASEDATE", "@")
        masterExamplesArray.append(example11)

        # =============================================================================================================
        # Example 12
        # =============================================================================================================
        # "when "will/does" "object" need to be "submitted/Turned in"
        example12 = ("when <5> <0> need to be [12]".split(), 1, 9, "-1", "+DUEDATE", "@")
        masterExamplesArray.append(example12)

        # =============================================================================================================
        # Example 13
        # =============================================================================================================
        # when will i need to submit assignment 2
        example13 = ("when <5> <2> need to [13] <0>".split(), 1, 9, "-3", "+DUEDATE", "@")
        masterExamplesArray.append(example13)

        # =============================================================================================================
        # Example 14
        # =============================================================================================================
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        example14 = ("when <7> the <0> [11] by".split(), 1, 9, "-1", "+RELEASEDATE", "@")
        masterExamplesArray.append(example14)

        # =============================================================================================================
        # Example 15
        # =============================================================================================================
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        example15 = ("when <7> the <0> due by".split(), 1, 9, "-1", "+DUEDATE", "@")
        masterExamplesArray.append(example15)

        # =============================================================================================================
        # Example 16
        # =============================================================================================================
        # when should we have project 2 completed by
        example16 = ("when <6> <2> [14] <0> [15]".split(), 1, 9, "-3", "+DUEDATE", "@")
        masterExamplesArray.append(example16)

        # =============================================================================================================
        # Example 17
        # =============================================================================================================
        # when do I need to turn in assignment 3
        example17 = ("when <6> <2> <6> to [13] <0>".split(), 1, 9, "-4", "+DUEDATE", "@")
        masterExamplesArray.append(example17)

        # =============================================================================================================
        # Example 18
        # =============================================================================================================
        # when will submissions close for project 3
        example18 = ("when <5> submissions [16] <8> <0>".split(), 1, 9, "-3", "+DUEDATE", "@")
        masterExamplesArray.append(example18)

        # =============================================================================================================
        # Example 19
        # =============================================================================================================
        # how much time is there for submitting assignment 1
        example19 = ("how [17] <4> <7> [18] <8> [13] <0>".split(), 1, 9, "-6", "+DURATION", "@")
        masterExamplesArray.append(example19)

        # =============================================================================================================
        # Example 20
        # =============================================================================================================
        # how long do we have to complete project 1
        example20 = ("how long <6> <2> [14] to [13] <0>".split(), 1, 9, "-4", "+DURATION", "@")
        masterExamplesArray.append(example20)

        # =============================================================================================================
        # Example 21
        # =============================================================================================================
        # how many weeks to write assignment 3
        example21 = ("how many <4> to [13] <0>".split(), 1, 9, "-2", "+DURATION", "@")
        masterExamplesArray.append(example21)

        # =============================================================================================================
        # Example 22
        # =============================================================================================================
        # what percentage of my grade is assignment 1 worth
        example22 = ("what [19] <8> <2> [19] <7> <0> [19]".split(), 1, 9, "-5", "+WEIGHT", "@")
        masterExamplesArray.append(example22)

        # =============================================================================================================
        # Example 23
        # =============================================================================================================
        # how much is project 1 worth
        example23 = ("how much <7> <0> [19]".split(), 1, 9, "-1", "+WEIGHT", "@")
        masterExamplesArray.append(example23)

        # =============================================================================================================
        # Example 24
        # =============================================================================================================
        # what is the weight of assignment 2
        example24 = ("what <7> the [19] of <0>".split(), 1, 9, "-2", "+WEIGHT", "@")
        masterExamplesArray.append(example24)

        # =============================================================================================================
        # Example 25
        # =============================================================================================================
        # how much will the midterm be worth
        example25 = ("how much <7> <0> be [19]".split(), 1, 9, "-1", "+WEIGHT", "@")
        masterExamplesArray.append(example25)

        # =============================================================================================================
        # Example 26
        # =============================================================================================================
        # what percentage of the total grade is project 2
        exampleNumber = ("what [19] <8> the total [19] <7> <0>".split(), 1, 9, "-4", "+WEIGHT", "@")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 27
        # =============================================================================================================
        # how much does assignment 3 contribute to my grade
        exampleNumber = ("how much <5> <0> contribute to <2> [19]".split(), 1, 9, "-1", "+WEIGHT", "@")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 28
        # =============================================================================================================
        # how much is project 3 contributing to my grade
        exampleNumber = ("how much <7> <0> contributing to <2> [19]".split(), 1, 9, "-1", "+WEIGHT", "@")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 29
        # =============================================================================================================
        # how much is project 3 contributing to my grade
        exampleNumber = ("how much <7> <0> contributing to [19]".split(), 1, 9, "-1", "+WEIGHT", "@")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 30
        # =============================================================================================================
        # what is the process for submitting assignment 1
        exampleNumber = ("what <7> the process <8> [13] <0>".split(), 1, 9, "-3", "+PROCESS", "@")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 31
        # =============================================================================================================
        # what is the process of getting project 1
        exampleNumber = ("what <7> the process <8> <3> <0>".split(), 1, 9, "-3", "+PROCESS", "@")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 32
        # =============================================================================================================
        # where do i turn in assignment 2
        exampleNumber = ("where <6> <2> [13] <0>".split(), 1, 9, "-3", "+PROCESS", "@")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 32
        # =============================================================================================================
        # where do i turn in my midterm
        exampleNumber = ("where <6> <2> [13] <2> <0>".split(), 1, 9, "-4", "+PROCESS", "@")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 34
        # =============================================================================================================
        # How do I turn in my final
        exampleNumber = ("how <6> <2> [13] <2> <0>".split(), 1, 9, "-4", "+PROCESS", "@")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 35
        # =============================================================================================================
        # what is the procedure for submitting the final
        exampleNumber = ("what <7> the procedure <8> [13] <0>".split(), 1, 9, "-3", "+PROCESS", "@")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 36
        # =============================================================================================================
        # where do i go to get class announcements
        exampleNumber = ("where <6> <2> go to <3> [20]".split(), 1, 9, "+ANNOUNCEMENT", "+GENERAL", "@")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 37
        # =============================================================================================================
        # what are the primary learning goals for the class
        exampleNumber = ("what <7> the [21] <8> [18] class".split(), 1, 9, "+GOALS", "+GENERAL", "@")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 38
        # =============================================================================================================
        # What assignment can we start during week 1
        exampleNumber = ("what <0> <6> <2> <3> <8> [22]".split(), 1, 9, "-0", "-5", "START")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 39
        # =============================================================================================================
        # What assignment can we work on during week 1?
        exampleNumber = ("what <0> <6> <2> [23] <8> [22]".split(), 1, 9, "-0", "-5", "WORK")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 40
        # =============================================================================================================
        #  What assignment can we turn in during week 1
        exampleNumber = ("what <0> <6> <2> [13] <8> [22]".split(), 1, 9, "-0", "-5", "SUBMIT")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 41
        # =============================================================================================================
        #  What can we start during week 1?
        exampleNumber = ("what <6> <2> <3> <8> [22]".split(), 1, 9, "+ANY/WEEK?", "-4", "START")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 42
        # =============================================================================================================
        #  What can we work on during week 1?
        exampleNumber = ("what <6> <2> [23] <8> [22]".split(), 1, 9, "+ANY/WEEK?", "-4", "WORK")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 43
        # =============================================================================================================
        #  What can we turn in during week 1?
        exampleNumber = ("what <6> <2> [13] <8> [22]".split(), 1, 9, "+ANY/WEEK?", "-4", "SUBMIT")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 44
        # =============================================================================================================
        #  What will be available in week 15
        exampleNumber = ("what <7> <9> <8> [22]".split(), 1, 9, "+ANY/WEEK?", "-3", "START")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 45
        # =============================================================================================================
        #  What project will be available in week 15
        exampleNumber = ("what <0> <7> <9> <8> [22]".split(), 1, 9, "-0", "-4", "START")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 46
        # =============================================================================================================
        #  What project starts during week 4
        exampleNumber = ("what <0> <3> <8> [22]".split(), 1, 9, "-0", "-3", "START")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 47
        # =============================================================================================================
        #  How long for project 1 to be completed
        exampleNumber = ("how long <8> <0> <7> [13]".split(), 1, 9, "-1", "+DURATION", "@")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 48
        # =============================================================================================================
        #  What is the final day to turn in assignment 1
        exampleNumber = ("what <7> the final <4> to [13] <0>".split(), 1, 10, "-3", "+DUEDATE", "@")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 49
        # =============================================================================================================
        #  How much is the project beginning week 4 worth
        exampleNumber = ("how much <7> the <0> beginning [22] [19]".split(), 1, 10, "-1", "-2", "WEIGHT")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 50
        # =============================================================================================================
        #  What assignment is during week 2
        exampleNumber = ("what <0> <7> <8> [22]".split(), 1, 10, "-0", "-3", "WORK")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 51
        # =============================================================================================================
        #  When will the assignment on week 2 be due
        exampleNumber = ("when <5> <0> <8> [22] <7> <1>".split(), 1, 10, "-1", "-3", "DUEDATE")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 52
        # =============================================================================================================
        #  how to submit the code for assignment 1
        exampleNumber = ("how to [13] the code <8> <0>".split(), 1, 10, "-2", "+PROCESS", "CODE")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 53
        # =============================================================================================================
        #  how do i submit the code for assignment 1
        exampleNumber = ("how <6> <2> [13] the code <8> <0>".split(), 1, 10, "-4", "+PROCESS", "CODE")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 54
        # =============================================================================================================
        #  how do i get the code for assignment 1
        exampleNumber = ("how <6> <2> <3> the code <8> <0>".split(), 1, 10, "-4", "+PROCESS", "CODE")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 55
        # =============================================================================================================
        #  what can we work on week 4
        exampleNumber = ("what <6> <2> [23] [22]".split(), 1, 10, "+ANY/WEEK?", "-3", "WORK")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 56
        # =============================================================================================================
        #  What can we start week 1?
        exampleNumber = ("what <6> <2> <3> [22]".split(), 1, 9, "+ANY/WEEK?", "-3", "START")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 57
        # =============================================================================================================
        #  What can we finish/turn in week 1?
        exampleNumber = ("what <6> <2> [13] [22]".split(), 1, 9, "+ANY/WEEK?", "-3", "SUBMIT")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 58
        # =============================================================================================================
        #  what can be submitted in week 3
        exampleNumber = ("what <7> [13] <8> [22]".split(), 1, 9, "+ANY/WEEK?", "-3", "SUBMIT")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 59
        # =============================================================================================================
        #  what can be submitted week 3
        exampleNumber = ("what <7> [13] [22]".split(), 1, 9, "+ANY/WEEK?", "-2", "SUBMIT")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 60
        # =============================================================================================================
        #  what can be distributed in week 3
        exampleNumber = ("what <7> [11] <8> [22]".split(), 1, 9, "+ANY/WEEK?", "-3", "SUBMIT")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 61
        # =============================================================================================================
        #  what can be distributed week 3
        exampleNumber = ("what <7> [11] [22]".split(), 1, 9, "+ANY/WEEK?", "-2", "SUBMIT")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 62
        # =============================================================================================================
        #  what must I start by week 3
        exampleNumber = ("what <7> <2> <3> by [22]".split(), 1, 9, "+ANY/WEEK?", "-3", "START")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 63
        # =============================================================================================================
        #  what must I finish by week 3
        exampleNumber = ("what <7> <2> [13] by [22]".split(), 1, 9, "+ANY/WEEK?", "-3", "SUBMIT")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 64
        # =============================================================================================================
        #  what project is released week 4
        exampleNumber = ("what <0> is [11] [22]".split(), 1, 9, "-0", "-2", "RELEASEDATE")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 65
        # =============================================================================================================
        #  what project is due week 4
        exampleNumber = ("what <0> is due [22]".split(), 1, 9, "-0", "-1", "DUEDATE")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 66
        # =============================================================================================================
        #  how long does one have for project 2
        exampleNumber = ("how long <7> <2> [14] <8> <0>".split(), 1, 9, "-4", "+DURATION", "@")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 67
        # =============================================================================================================
        #  when is the assignment 1 release day
        exampleNumber = ("when <7> the <0>  <9> <4>".split(), 1, 9, "-1", "-2", "@")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 68
        # =============================================================================================================
        #  when can i turn in the midterm
        exampleNumber = ("when <7> <2> [13] the <0>".split(), 1, 9, "-3", "+DUEDATE", "@")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 69
        # =============================================================================================================
        #  when do i need to start the midterm
        exampleNumber = ("when <6> <2> need to <3> <0>".split(), 1, 9, "-3", "+DUEDATE", "@")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 70
        # =============================================================================================================
        #  When can assignment 1 be turned in
        exampleNumber = ("when <6> <0> <7> [13]".split(), 1, 9, "-1", "+DUEDATE", "@")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 71
        # =============================================================================================================
        #  how long is project 3 available
        exampleNumber = ("how long <7> <0> [11]".split(), 1, 9, "-1", "+DURATION", "@")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 72
        # =============================================================================================================
        #  How long is the project from week 8 available
        exampleNumber = ("how long <7> the <0> [11]".split(), 1, 9, "-1", "+DURATION", "@")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 73
        # =============================================================================================================
        #  How do i turn in the project due week 6
        exampleNumber = ("how <6> <2> [13] the <0>".split(), 1, 9, "-3", "+PROCESS", "@")
        masterExamplesArray.append(exampleNumber)

        # =============================================================================================================
        # Example 33 BROUGHT DOWN TO PREVENT ERROR
        # =============================================================================================================
        # How do I turn in project 2
        exampleNumber = ("how <6> <2> [13] <0>".split(), 1, 9, "-3", "+PROCESS", "@")
        masterExamplesArray.append(exampleNumber)













        finalResultsTuple = isExample(word_list, masterExamplesArray, subCompares)
        _intent = convertToIntent(finalResultsTuple, word_list)
        #print(_intent)
        #print(" ")

        return _intent

