'''
This adapter is for prototyping classifiers
'''


class TestAdapter:
    """ Test adapter """
    def __init__(self, training_data):
        self._engine_name = "Project3"
        self._training_data = training_data

    def get_engine(self):
        """ Get engine name """
        return self._engine_name

    def ask_question(self, question):
        """
            returns {
                        'question':question,
                        'label':confidence
                    }
        """
        d_of_intents_confidence = {'question':question}
        label,confidence = self._your_classifier(question)
        d_of_intents_confidence[label] = confidence
        return d_of_intents_confidence

    def _your_classifier(self, question):
        """
            Your code here
        """
#       print(question, end=" -> ")
        label = 'test'
        confidence = 0.0
#       print(label)
        return label,confidence
