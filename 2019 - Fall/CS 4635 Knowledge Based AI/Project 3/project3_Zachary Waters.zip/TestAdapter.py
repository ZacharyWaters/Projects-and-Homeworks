'''
This adapter is for prototyping classifiers
'''


class TestAdapter:
    """ Test adapter """
    def __init__(self, training_data):
        self._engine_name = "Project3"
        self._training_data = training_data

    def get_engine(self):
        """ Get engine name """
        return self._engine_name

    def ask_question(self, question):
        """
            returns {
                        'question':question,
                        'label':confidence
                    }
        """
        d_of_intents_confidence = {'question':question}
        label,confidence = self._your_classifier(question)
        d_of_intents_confidence[label] = confidence
        return d_of_intents_confidence

    def _your_classifier(self, question):
        """
            Your code here
        """
        my_training_data = self._training_data

        # /////////////////////////////////////////////////////////////////////////////////////////////////////////
        # ||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
        # \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\


        def myWordDistance(word1, word2):
            # gets the smaller word
            smallerWord = word1
            largerWord = word2
            if(len(word2) < len(word1)):
                smallerWord = word2
                largerWord = word1
            charIndex = 0
            brakes = False
            matches = 0
            # gets the number of matching Characters starting from the front
            while charIndex < len(smallerWord) and brakes is False:
                characterA = smallerWord[charIndex]
                characterB = largerWord[charIndex]
                if(characterA == characterB):
                    matches = matches + 1
                else:
                    brakes = True
                charIndex = charIndex + 1
            return matches




        # Tokenized words are the base words that are expanded upon to form more complex varieties of the token
        # ie. the word causality vs casualty
        # TOKENIZE WORD -------------------------------------------------------------------------------------------
        def tokenize(word):
            # handles a word ending with pluralization 's
            if word[-2:] == "'s":
                word = word[:-2]
            # handles a word ending with s
            # if (len(word) > 2):
            #     if (word.endswith("ss")):
            #         word = word
            #     elif (word.endswith("s")):
            #         word = word[:-1]
            # handles a word ending with ies

            return word

        # TOKENIZE END -------------------------------------------------------------------------------------------

        # /////////////////////////////////////////////////////////////////////////////////////////////////////////
        # ||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
        # \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

        # TIE BRAKE WORD -------------------------------------------------------------------------------------------

        def tiebrakeLast(peakList):
            chosenPeak = peakList[-1]
            return chosenPeak

        def tiebrakeFirst(peakList):
            chosenPeak = peakList[0]
            return chosenPeak

        def tiebrakeRandom(peakList):
            import random
            chosenPeak = random.choice(peakList)
            return chosenPeak

        def tieBrakeWeight(peakList):
            #print(all_Labels)
            #print(incrementalList)
            #print(tiebrakerList)
            q = 0
            myTestingmax = -1
            while q < len(tiebrakerList):
                if tiebrakerList[q] > myTestingmax and q in peakList:
                    myTestingmax = tiebrakerList[q]
                q = q + 1
            #weightPeakValue = max(tiebrakerList)
            weightPeakValue = myTestingmax
            #print(weightPeakValue)
            weightPeakList = []
            k = 0
            while k < len(tiebrakerList):
                weightValue = tiebrakerList[k]
                if weightValue == weightPeakValue and k in peakList:
                    weightPeakList.append(k)
                k = k + 1

            if(len(weightPeakList) == 1):
                tieTuple = [1, weightPeakList[0]]
                #print(tieTuple)
                return tieTuple
            else:
                chosenPeakValue = tiebrakeFirst(weightPeakList)
                recalculatedConfidence = 1 / len(weightPeakList)
                tieTuple = [recalculatedConfidence,chosenPeakValue]
                #print(tieTuple)
                return tieTuple


        def tiebrake(peaksList):
            if(len(peaksList) == 1):
                tieTuple = [1, peaksList[0]]
                return tieTuple

            tieTuple = tieBrakeWeight(peaksList)
            # result = tiebrakeRandom(peaksList)
            # tieTuple = [0, result]
            return tieTuple

        # TIE BRAKE END -------------------------------------------------------------------------------------------

        # /////////////////////////////////////////////////////////////////////////////////////////////////////////
        # ||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
        # \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

        # Syllogistic words are words that have the same meaning and function, that we can anticipate for our domain
        # ie. the words "course" is syllogistic to "class"
        # Syllogistic Words ---------------------------------------------------------------------------------------

        def isSyllogism(word, wordSize, syllogisms):
            for sylloTuple in syllogisms:
                reducedWord = sylloTuple[0]
                masterList = sylloTuple[1]
                matchFound = False
                for sizeTuple in masterList:
                    listSize = sizeTuple[0]
                    if (listSize == wordSize):
                        compareList = sizeTuple[1]
                        for compareWord in compareList:
                            if compareWord == word:
                                matchFound = True
                                return (True, reducedWord)

                # if matchFound is True:
                #     return (True, reducedWord)
            return (False, word)



        syllogisms = []

        # List of the words syllogistic to course, including itself, also the number of words of the syllogism
        course_Syllogisms_Size1 = ["course", "courses"]
        course_Syllogisms_MasterList = [(1, course_Syllogisms_Size1)]
        # contains the Master list, and the word we are going to reduce it down to if we find a match
        course_Tuple = ("course", course_Syllogisms_MasterList)
        syllogisms.append(course_Tuple)

        # List of the words syllogistic to class, including itself, also the number of words of the syllogism
        class_Syllogisms_Size1 = ["class", "classes"]
        class_Syllogisms_MasterList = [(1, class_Syllogisms_Size1)]
        # contains the Master list, and the word we are going to reduce it down to if we find a match
        class_Tuple = ("class", class_Syllogisms_MasterList)
        syllogisms.append(class_Tuple)

        # List of the words syllogistic to Teach, including itself, also the number of words of the syllogism
        teach_Syllogisms_Size1 = ["teach", "teaching", "teaches", "taught"]
        teach_Syllogisms_MasterList = [(1, teach_Syllogisms_Size1)]
        # contains the Master list, and the word we are going to reduce it down to if we find a match
        teach_Tuple = ("teach", teach_Syllogisms_MasterList)
        syllogisms.append(teach_Tuple)

        # List of the words syllogistic to Offer, including itself, also the number of words of the syllogism
        offer_Syllogisms_Size1 = ["offer", "offered", "offering"]
        offer_Syllogisms_MasterList = [(1, offer_Syllogisms_Size1)]
        # contains the Master list, and the word we are going to reduce it down to if we find a match
        offer_Tuple = ("offer", offer_Syllogisms_MasterList)
        syllogisms.append(offer_Tuple)

        # List of the words syllogistic to Learn, including itself, also the number of words of the syllogism
        learn_Syllogisms_Size1 = ["learn", "learned", "learning"]
        learn_Syllogisms_MasterList = [(1, learn_Syllogisms_Size1)]
        # contains the Master list, and the word we are going to reduce it down to if we find a match
        learn_Tuple = ("learn", learn_Syllogisms_MasterList)
        syllogisms.append(learn_Tuple)

        # List of the words syllogistic to submit, including itself, also the number of words of the syllogism
        submit_Syllogisms_Size1 = ["submit", "submitting", "submitted", "submits"]
        submit_Syllogisms_MasterList = [(1, submit_Syllogisms_Size1)]
        # contains the Master list, and the word we are going to reduce it down to if we find a match
        submit_Tuple = ("submit", submit_Syllogisms_MasterList)
        syllogisms.append(submit_Tuple)

        # List of the words syllogistic to goals, including itself, also the number of words of the syllogism
        goals_Syllogisms_Size1 = ["goal", "goals"]
        goals_Syllogisms_MasterList = [(1, goals_Syllogisms_Size1)]
        # contains the Master list, and the word we are going to reduce it down to if we find a match
        goals_Tuple = ("goal", goals_Syllogisms_MasterList)
        syllogisms.append(goals_Tuple)

        # List of the words syllogistic to turn, including itself, also the number of words of the syllogism
        turns_Syllogisms_Size1 = ["turn", "turning", "turns", "turned"]
        turns_Syllogisms_MasterList = [(1, turns_Syllogisms_Size1)]
        # contains the Master list, and the word we are going to reduce it down to if we find a match
        turns_Tuple = ("turn", turns_Syllogisms_MasterList)
        syllogisms.append(turns_Tuple)

        # List of the words syllogistic to take, including itself, also the number of words of the syllogism
        take_Syllogisms_Size1 = ["take", "takes", "taking", "takings"]
        take_Syllogisms_MasterList = [(1, take_Syllogisms_Size1)]
        # contains the Master list, and the word we are going to reduce it down to if we find a match
        take_Tuple = ("take", take_Syllogisms_MasterList)
        syllogisms.append(take_Tuple)

        # List of the words syllogistic to Strategy, including itself, also the number of words of the syllogism
        strategy_Syllogisms_Size1 = ["strategy", "strategies"]
        strategy_Syllogisms_MasterList = [(1, strategy_Syllogisms_Size1)]
        # contains the Master list, and the word we are going to reduce it down to if we find a match
        strategy_Tuple = ("strategy", strategy_Syllogisms_MasterList)
        syllogisms.append(strategy_Tuple)

        # List of the words syllogistic to talk, including itself, also the number of words of the syllogism
        talk_Syllogisms_Size1 = ["talk", "talked", "talks", "talking"]
        talk_Syllogisms_MasterList = [(1, talk_Syllogisms_Size1)]
        # contains the Master list, and the word we are going to reduce it down to if we find a match
        talk_Tuple = ("talk", talk_Syllogisms_MasterList)
        syllogisms.append(talk_Tuple)

        # List of the words syllogistic to discuss, including itself, also the number of words of the syllogism
        newwords_Size1 = ["discuss", "discussing", "discussed", "discusses"]
        new_Syllogisms_MasterList = [(1, newwords_Size1)]
        # contains the Master list, and the word we are going to reduce it down to if we find a match
        new_Tuple = ("discuss", new_Syllogisms_MasterList)
        syllogisms.append(new_Tuple)

        # List of the words syllogistic to tell, including itself, also the number of words of the syllogism
        newwords_Size1 = ["tell", "told", "telling"]
        new_Syllogisms_MasterList = [(1, newwords_Size1)]
        # contains the Master list, and the word we are going to reduce it down to if we find a match
        new_Tuple = ("tell", new_Syllogisms_MasterList)
        syllogisms.append(new_Tuple)

        # List of the words syllogistic to XXX, including itself, also the number of words of the syllogism
        newwords_Size1 = ["contact", "contacting", "contacted"]
        new_Syllogisms_MasterList = [(1, newwords_Size1)]
        # contains the Master list, and the word we are going to reduce it down to if we find a match
        new_Tuple = ("contact", new_Syllogisms_MasterList)
        syllogisms.append(new_Tuple)

        # List of the words syllogistic to XXX, including itself, also the number of words of the syllogism
        newwords_Size1 = ["communicate", "communicated", "communicating"]
        new_Syllogisms_MasterList = [(1, newwords_Size1)]
        # contains the Master list, and the word we are going to reduce it down to if we find a match
        new_Tuple = ("communicate", new_Syllogisms_MasterList)
        syllogisms.append(new_Tuple)

        # List of the words syllogistic to XXX, including itself, also the number of words of the syllogism
        newwords_Size1 = ["prepare", "prepared", "preparing"]
        new_Syllogisms_MasterList = [(1, newwords_Size1)]
        # contains the Master list, and the word we are going to reduce it down to if we find a match
        new_Tuple = ("prepare", new_Syllogisms_MasterList)
        syllogisms.append(new_Tuple)

        # List of the words syllogistic to XXX, including itself, also the number of words of the syllogism
        newwords_Size1 = ["reach", "reached", "reaching", 'reaches']
        new_Syllogisms_MasterList = [(1, newwords_Size1)]
        # contains the Master list, and the word we are going to reduce it down to if we find a match
        new_Tuple = ("reach", new_Syllogisms_MasterList)
        syllogisms.append(new_Tuple)

        # List of the words syllogistic to XXX, including itself, also the number of words of the syllogism
        newwords_Size1 = ["exam", "exams"]
        new_Syllogisms_MasterList = [(1, newwords_Size1)]
        # contains the Master list, and the word we are going to reduce it down to if we find a match
        new_Tuple = ("exam", new_Syllogisms_MasterList)
        syllogisms.append(new_Tuple)

        # List of the words syllogistic to XXX, including itself, also the number of words of the syllogism
        newwords_Size1 = ["project", "projects"]
        new_Syllogisms_MasterList = [(1, newwords_Size1)]
        # contains the Master list, and the word we are going to reduce it down to if we find a match
        new_Tuple = ("project", new_Syllogisms_MasterList)
        syllogisms.append(new_Tuple)

        # List of the words syllogistic to XXX, including itself, also the number of words of the syllogism
        newwords_Size1 = ["prerequisites", "preresiquites"]
        new_Syllogisms_MasterList = [(1, newwords_Size1)]
        # contains the Master list, and the word we are going to reduce it down to if we find a match
        new_Tuple = ("prerequisites", new_Syllogisms_MasterList)
        syllogisms.append(new_Tuple)

        # List of the words syllogistic to XXX, including itself, also the number of words of the syllogism
        newwords_Size1 = ["your", "yourself", "yours", "your", "yourselves"]
        new_Syllogisms_MasterList = [(1, newwords_Size1)]
        # contains the Master list, and the word we are going to reduce it down to if we find a match
        new_Tuple = ("your", new_Syllogisms_MasterList)
        syllogisms.append(new_Tuple)

        # List of the words syllogistic to XXX, including itself, also the number of words of the syllogism
        newwords_Size1 = ["who", "whom"]
        new_Syllogisms_MasterList = [(1, newwords_Size1)]
        # contains the Master list, and the word we are going to reduce it down to if we find a match
        new_Tuple = ("who", new_Syllogisms_MasterList)
        syllogisms.append(new_Tuple)

        # List of the words syllogistic to XXX, including itself, also the number of words of the syllogism
        newwords_Size1 = ["make", "makes", "made"]
        new_Syllogisms_MasterList = [(1, newwords_Size1)]
        # contains the Master list, and the word we are going to reduce it down to if we find a match
        new_Tuple = ("make", new_Syllogisms_MasterList)
        syllogisms.append(new_Tuple)

        # List of the words syllogistic to XXX, including itself, also the number of words of the syllogism
        newwords_Size1 = ["take", "takes", "took", "taking", "taken"]
        new_Syllogisms_MasterList = [(1, newwords_Size1)]
        # contains the Master list, and the word we are going to reduce it down to if we find a match
        new_Tuple = ("take", new_Syllogisms_MasterList)
        syllogisms.append(new_Tuple)

        # List of the words syllogistic to XXX, including itself, also the number of words of the syllogism
        newwords_Size1 = ["answer", "answered", "answering", "answerable"]
        new_Syllogisms_MasterList = [(1, newwords_Size1)]
        # contains the Master list, and the word we are going to reduce it down to if we find a match
        new_Tuple = ("answer", new_Syllogisms_MasterList)
        syllogisms.append(new_Tuple)

        # List of the words syllogistic to XXX, including itself, also the number of words of the syllogism
        newwords_Size1 = ["try", "tried", "trying", "tries"]
        new_Syllogisms_MasterList = [(1, newwords_Size1)]
        # contains the Master list, and the word we are going to reduce it down to if we find a match
        new_Tuple = ("try", new_Syllogisms_MasterList)
        syllogisms.append(new_Tuple)

        # Syllogistic Ends ----------------------------------------------------------------------------------------

        syllogisms_2 = []

        wordNetEntree = ["talk", "discuss", "tell", "contact", "communicate", "reach"]
        new_Syllogisms_WordNet = [(1, wordNetEntree)]
        new_WordNet_Tuple = ("communicate", new_Syllogisms_WordNet)
        syllogisms_2.append(new_WordNet_Tuple)

        wordNetEntree = ["course", "class"]
        new_Syllogisms_WordNet = [(1, wordNetEntree)]
        new_WordNet_Tuple = ("class", new_Syllogisms_WordNet)
        syllogisms_2.append(new_WordNet_Tuple)

        # /////////////////////////////////////////////////////////////////////////////////////////////////////////
        # ||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
        # \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\


        all_Labels = my_training_data.get("LabelMasterList")

        # make an array of size all_labels full of zeroes
        incrementalList = [0] * len(all_Labels)

        # makes an array of the weight of labels for tie brakers
        tiebrakerList = [0] * len(all_Labels)

        # iterate through each word in question
        split_Question = question.split()

        for word in split_Question:

            # Tokenizes the word ------------------------------------------------------------------------
            word = tokenize(word)
            # Tokenizes end -----------------------------------------------------------------------------

            # Checks if the word is on the Syllogistic List
            #-------------------------------------------------------------------------------------------
            sylloTuple = isSyllogism(word, 1, syllogisms)
            if(sylloTuple[0] == True):
                word = sylloTuple[1]
            #-------------------------------------------------------------------------------------------
            sylloTuple = isSyllogism(word, 1, syllogisms_2)
            if(sylloTuple[0] == True):
                word = sylloTuple[1]
            #-------------------------------------------------------------------------------------------

            #word = stem(word)

            if word in my_training_data:

                # get its corresponding label tags
                word_Tags = my_training_data.get(word)

                # iterate through this list of tags
                for tagTuple in word_Tags:

                    tag = tagTuple[0]
                    tagWeight = tagTuple[1]

                    # get the index of the tag that corresponds to the incrementalList
                    countIndex = all_Labels.index(tag)

                    # increments that spot in the array
                    incrementalList[countIndex] = incrementalList[countIndex] + 1;

                    # increments that spot in the tiebrakeList
                    tiebrakerList[countIndex] = tiebrakerList[countIndex] + tagWeight
            else:
                sanitizedList = ["a", "above", "about", "after", "again", "against", "all", "am", "an", "and", "any",
                                 "are", "as", "at", "be",
                                 "because", "been", "before", "being", "below", "between", "both", "but", "by", "can",
                                 "did", "do", "does",
                                 "doing", "down", "during", "each", "few", "for", "from", "further", "had", "has",
                                 "have", "having",
                                 "he", "her", "here", "hers", "herself", "him", "himself", "his", "how", "i", "if",
                                 "in", "into", "is", "it",
                                 "its", "itself", "just", "me", "more", "most", "my", "myself", "no", "nor", "not",
                                 "now", "of", "off", "on",
                                 "once", "only", "or", "other", "our", "ours", "ourselves", "out", "over", "own",
                                 "same", "she", "should",
                                 "so", "some", "such", "than", "that", "the", "their", "theirs", "them", "themselves",
                                 "then", "there",
                                 "these", "they", "this", "those", "through", "to", "too", "under", "until", "up",
                                 "very", "was", "we",
                                 "were", "what", "where", "which", "while", "why", "will", "with",
                                 "you", "your", "yours", "yourself", "yourselves"]

                if(word not in sanitizedList):
                    #print("~~~~~~~~~ Unhandled Word: "+word)
                    allSavedwords = sorted(my_training_data.keys())
                    comparedWordsTuples = []

                    for otherword in allSavedwords:

                        myfirstChar = word[0]
                        oldFirstChar = otherword[0]

                        if(myfirstChar == oldFirstChar):
                            #distance = levenshteinDistance(word, otherword)
                            distance = myWordDistance(word, otherword)
                            compareTuple = [otherword, distance]
                            comparedWordsTuples.append(compareTuple)

                    firstTuple = comparedWordsTuples[0]
                    # minDisWord = firstTuple[0]
                    # minDistance = firstTuple[1]
                    #
                    # for compareTuple in comparedWordsTuples:
                    #     if(compareTuple[1] < minDistance):
                    #         minDisWord = compareTuple[0]
                    #         minDistance = compareTuple[1]
                    maxDisWord = firstTuple[0]
                    maxDistance = firstTuple[1]

                    for compareTuple in comparedWordsTuples:
                        if(compareTuple[1] > maxDistance):
                            maxDisWord = compareTuple[0]
                            maxDistance = compareTuple[1]

                    #print("minimum Word: " + minDisWord + " with value: " + str(minDistance))
                    #print("\t \t maximum Word: " +maxDisWord +" with value: " +str(maxDistance))
                    # iterate through this list of tags
                    if(maxDistance > 2):
                        word_Tags = my_training_data.get(maxDisWord)
                        for tagTuple in word_Tags:
                            tag = tagTuple[0]
                            tagWeight = tagTuple[1]

                            # get the index of the tag that corresponds to the incrementalList
                            countIndex = all_Labels.index(tag)

                            # increments that spot in the array
                            incrementalList[countIndex] = incrementalList[countIndex] + 1;

                            # increments that spot in the tiebrakeList
                            tiebrakerList[countIndex] = tiebrakerList[countIndex] + tagWeight
                    else:
                        y = 0
                        #print("\t \t \t not enough")


        # Iterate though the incremental-List and find the largest "peak" value
        peakValue = max(incrementalList)

        # Iterate though the incremental-List again and add each "peak" to peak list
        peakList = []
        i = 0
        while i < len(incrementalList):
            incValue = incrementalList[i]
            if incValue == peakValue:
                peakList.append(i)
            i = i + 1

        # perform the a tie-brake operation,
        tieTuple = tiebrake(peakList)
        secondConfidence = tieTuple[0]
        chosenPeak = tieTuple[1]

        # make a confidence value that reflects the number of peaks you had to choose from
        numberOfPeaks = len(peakList)
        myConfidence_Level = 1/numberOfPeaks

        # get the corresponding label from the all_Labels list
        myChosen_Label = all_Labels[chosenPeak]

        # set the final label and confidence result equal to our work
        label = myChosen_Label
        confidence = myConfidence_Level

        # if(confidence != 1):
        #     print("%.2f%% Uncertain:" %(myConfidence_Level))
        #     print("\t \t \tQuestion:  " +question)
        #     allPossiblelabels = ""
        #     for peakIterator in peakList:
        #         possibleLabel = all_Labels[peakIterator]
        #         allPossiblelabels = allPossiblelabels + possibleLabel +", "
        #     print("\t \t \t Options:  " +allPossiblelabels[:-2])
        #     print("\t \tSecondConfidence:  " +str(secondConfidence))
        #     print("\t \t \t  Chosen:  "+myChosen_Label)
        return label,confidence
