"""
-------------------------------------------------------------
"""

import sys
import getopt
from TestAdapter import TestAdapter


def _train_agent(train_test_questions):
    """
        Call your code from here
    """
    training_data = {}

    def getSmallerLargeTuple(word1, word2):
        # gets the smaller word
        smallerWord = word1
        largerWord = word2
        if (len(word2) < len(word1)):
            smallerWord = word2
            largerWord = word1
        return [smallerWord, largerWord]

    def myWordDistance(word1, word2):
        # gets the smaller word
        orderTuple = getSmallerLargeTuple(word1, word2)
        smallerWord = orderTuple[0]
        largerWord = orderTuple[1]
        charIndex = 0
        brakes = False
        matches = 0
        # gets the number of matching Characters starting from the front
        while charIndex < len(smallerWord) and brakes is False:
            characterA = smallerWord[charIndex]
            characterB = largerWord[charIndex]
            if (characterA == characterB):
                matches = matches + 1
            else:
                brakes = True
            charIndex = charIndex + 1
        return matches

    def getRootWord(word1, word2):
        orderTuple = getSmallerLargeTuple(word1, word2)
        smallerWord = orderTuple[0]
        matchAmount = myWordDistance(word1, word2)
        root = smallerWord[0:matchAmount]
        return root


    def closeEnough(word1, word2):
        rootWord = getRootWord(word1, word2)
        if len(rootWord) <= 2:
            return False
        adages = ["", "s", "es", "ies", "ion", "ing", "ed", "ied", "y", 'sses', "eed", "ate", "ize", "ble", "tion", "ence",
                  "ance", "able", "ible", "al", "ent", "e", "ous", "ive", "ful", "bl", "ic", "ment", "ity", "ism", "er",
                  "ant", "ement", "ou"]
        oneMatch = False
        twoMatch = False
        firstAdage = ""
        secondAdage = ""
        lastChar = rootWord[-1]
        rootWord2 = rootWord + lastChar
        for adage in adages:
            testingWord = rootWord + adage
            testingWord2 = rootWord2 + adage
            if (testingWord == word1) or (testingWord2 == word1):
                firstAdage = adage
                oneMatch = True
        if(oneMatch is False):
            return False
        else:
            for adage in adages:
                testingWord = rootWord + adage
                testingWord2 = rootWord2 + adage
                if (testingWord == word2) or (testingWord2 == word2):
                    secondAdage = adage
                    twoMatch = True
        if(oneMatch is True and twoMatch is True):
            #print("match found: " + word1 + ", " + word2 + ". Because of: " + firstAdage +", " +secondAdage)
            return True
        return False

    # Sanitized words are words that appear so commonly we can "remove" them from our system
    # ie. the words "a" and "the"
    # SANITIZED WORDS -----------------------------------------------------------------------------------------
    def isSantized(word):
        isSantizied = False;
        if word in sanitizedList:
            isSantizied = True;
        return isSantizied

    # SO far i'm just using "and
    sanitizedList = ["a","above","about","after","again","against","all","am","an","and","any","are","as","at","be",
                     "because","been","before","being","below","between","both","but","by","can","did","do","does",
                     "doing","down","during","each","few","for","from","further","had","has","have","having",
                     "he","her","here","hers","herself","him","himself","his","how","i", "if","in","into","is","it",
                     "its","itself","just","me","more","most","my","myself","no","nor","not","now","of","off","on",
                     "once","only","or","other","our","ours","ourselves","out","over","own","same","she","should",
                     "so","some","such","than","that","the","their","theirs","them","themselves","then","there",
                     "these","they","this","those","through","to","too","under","up","very","was","we",
                     "were","what","where","which","while","why","will","with",
                     "you","your","yours","yourself","yourselves"]

    # SANITIZE END -- -----------------------------------------------------------------------------------------

    # /////////////////////////////////////////////////////////////////////////////////////////////////////////
    # ||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
    # \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    # Syllogistic words are words that have the same meaning and function, that we can anticipate for our domain
    # ie. the words "course" is syllogistic to "class"
    # Syllogistic Words ---------------------------------------------------------------------------------------

    def isSyllogism(word, wordSize, syllogisms):
        for sylloTuple in syllogisms:
            reducedWord = sylloTuple[0]
            masterList = sylloTuple[1]
            matchFound = False
            for sizeTuple in masterList:
                listSize = sizeTuple[0]
                if(listSize == wordSize):
                    compareList = sizeTuple[1]
                    for compareWord in compareList:
                        if compareWord == word:
                            matchFound = True

            if matchFound is True:
                return (True, reducedWord)
        return (False, word)


    syllogisms = []

    # List of the words syllogistic to course, including itself, also the number of words of the syllogism
    course_Syllogisms_Size1 = ["course", "courses"]
    course_Syllogisms_MasterList = [(1, course_Syllogisms_Size1)]
    # contains the Master list, and the word we are going to reduce it down to if we find a match
    course_Tuple = ("course", course_Syllogisms_MasterList)
    syllogisms.append(course_Tuple)

    # List of the words syllogistic to class, including itself, also the number of words of the syllogism
    class_Syllogisms_Size1 = ["class", "classes"]
    class_Syllogisms_MasterList = [(1, class_Syllogisms_Size1)]
    # contains the Master list, and the word we are going to reduce it down to if we find a match
    class_Tuple = ("class", class_Syllogisms_MasterList)
    syllogisms.append(class_Tuple)

    # List of the words syllogistic to Teach, including itself, also the number of words of the syllogism
    teach_Syllogisms_Size1 = ["teach", "teaching", "teaches", "taught"]
    teach_Syllogisms_MasterList = [(1, teach_Syllogisms_Size1)]
    # contains the Master list, and the word we are going to reduce it down to if we find a match
    teach_Tuple = ("teach", teach_Syllogisms_MasterList)
    syllogisms.append(teach_Tuple)

    # List of the words syllogistic to Offer, including itself, also the number of words of the syllogism
    offer_Syllogisms_Size1 = ["offer", "offered", "offering"]
    offer_Syllogisms_MasterList = [(1, offer_Syllogisms_Size1)]
    # contains the Master list, and the word we are going to reduce it down to if we find a match
    offer_Tuple = ("offer", offer_Syllogisms_MasterList)
    syllogisms.append(offer_Tuple)

    # List of the words syllogistic to Learn, including itself, also the number of words of the syllogism
    learn_Syllogisms_Size1 = ["learn", "learned", "learning", "learnt", "learns"]
    learn_Syllogisms_MasterList = [(1, learn_Syllogisms_Size1)]
    # contains the Master list, and the word we are going to reduce it down to if we find a match
    learn_Tuple = ("learn", learn_Syllogisms_MasterList)
    syllogisms.append(learn_Tuple)

    # List of the words syllogistic to submit, including itself, also the number of words of the syllogism
    submit_Syllogisms_Size1 = ["submit", "submitting", "submitted", "submits"]
    submit_Syllogisms_MasterList = [(1, submit_Syllogisms_Size1)]
    # contains the Master list, and the word we are going to reduce it down to if we find a match
    submit_Tuple = ("submit", submit_Syllogisms_MasterList)
    syllogisms.append(submit_Tuple)

    # List of the words syllogistic to goals, including itself, also the number of words of the syllogism
    goals_Syllogisms_Size1 = ["goal", "goals"]
    goals_Syllogisms_MasterList = [(1, goals_Syllogisms_Size1)]
    # contains the Master list, and the word we are going to reduce it down to if we find a match
    goals_Tuple = ("goal", goals_Syllogisms_MasterList)
    syllogisms.append(goals_Tuple)

    # List of the words syllogistic to turn, including itself, also the number of words of the syllogism
    turns_Syllogisms_Size1 = ["turn", "turning", "turns", "turned"]
    turns_Syllogisms_MasterList = [(1, turns_Syllogisms_Size1)]
    # contains the Master list, and the word we are going to reduce it down to if we find a match
    turns_Tuple = ("turn", turns_Syllogisms_MasterList)
    syllogisms.append(turns_Tuple)

    # List of the words syllogistic to take, including itself, also the number of words of the syllogism
    take_Syllogisms_Size1 = ["take", "takes", "taking", "takings"]
    take_Syllogisms_MasterList = [(1, take_Syllogisms_Size1)]
    # contains the Master list, and the word we are going to reduce it down to if we find a match
    take_Tuple = ("take", take_Syllogisms_MasterList)
    syllogisms.append(take_Tuple)

    # List of the words syllogistic to Strategy, including itself, also the number of words of the syllogism
    strategy_Syllogisms_Size1 = ["strategy", "strategies"]
    strategy_Syllogisms_MasterList = [(1, strategy_Syllogisms_Size1)]
    # contains the Master list, and the word we are going to reduce it down to if we find a match
    strategy_Tuple = ("strategy", strategy_Syllogisms_MasterList)
    syllogisms.append(strategy_Tuple)

    # List of the words syllogistic to talk, including itself, also the number of words of the syllogism
    talk_Syllogisms_Size1 = ["talk", "talked", "talks", "talking"]
    talk_Syllogisms_MasterList = [(1, talk_Syllogisms_Size1)]
    # contains the Master list, and the word we are going to reduce it down to if we find a match
    talk_Tuple = ("talk", talk_Syllogisms_MasterList)
    syllogisms.append(talk_Tuple)

    # List of the words syllogistic to discuss, including itself, also the number of words of the syllogism
    newwords_Size1 = ["discuss", "discussing", "discussed", "discusses"]
    new_Syllogisms_MasterList = [(1, newwords_Size1)]
    # contains the Master list, and the word we are going to reduce it down to if we find a match
    new_Tuple = ("discuss", new_Syllogisms_MasterList)
    syllogisms.append(new_Tuple)

    # List of the words syllogistic to tell, including itself, also the number of words of the syllogism
    newwords_Size1 = ["tell", "told", "telling"]
    new_Syllogisms_MasterList = [(1, newwords_Size1)]
    # contains the Master list, and the word we are going to reduce it down to if we find a match
    new_Tuple = ("tell", new_Syllogisms_MasterList)
    syllogisms.append(new_Tuple)

    # List of the words syllogistic to XXX, including itself, also the number of words of the syllogism
    newwords_Size1 = ["contact", "contacting", "contacted"]
    new_Syllogisms_MasterList = [(1, newwords_Size1)]
    # contains the Master list, and the word we are going to reduce it down to if we find a match
    new_Tuple = ("contact", new_Syllogisms_MasterList)
    syllogisms.append(new_Tuple)

    # List of the words syllogistic to XXX, including itself, also the number of words of the syllogism
    newwords_Size1 = ["communicate", "communicated", "communicating"]
    new_Syllogisms_MasterList = [(1, newwords_Size1)]
    # contains the Master list, and the word we are going to reduce it down to if we find a match
    new_Tuple = ("communicate", new_Syllogisms_MasterList)
    syllogisms.append(new_Tuple)

    # List of the words syllogistic to XXX, including itself, also the number of words of the syllogism
    newwords_Size1 = ["prepare", "prepared", "preparing"]
    new_Syllogisms_MasterList = [(1, newwords_Size1)]
    # contains the Master list, and the word we are going to reduce it down to if we find a match
    new_Tuple = ("prepare", new_Syllogisms_MasterList)
    syllogisms.append(new_Tuple)

    # List of the words syllogistic to XXX, including itself, also the number of words of the syllogism
    newwords_Size1 = ["reach", "reached", "reaching", 'reaches']
    new_Syllogisms_MasterList = [(1, newwords_Size1)]
    # contains the Master list, and the word we are going to reduce it down to if we find a match
    new_Tuple = ("reach", new_Syllogisms_MasterList)
    syllogisms.append(new_Tuple)

    # List of the words syllogistic to XXX, including itself, also the number of words of the syllogism
    newwords_Size1 = ["exam", "exams"]
    new_Syllogisms_MasterList = [(1, newwords_Size1)]
    # contains the Master list, and the word we are going to reduce it down to if we find a match
    new_Tuple = ("exam", new_Syllogisms_MasterList)
    syllogisms.append(new_Tuple)

    # List of the words syllogistic to XXX, including itself, also the number of words of the syllogism
    newwords_Size1 = ["project", "projects"]
    new_Syllogisms_MasterList = [(1, newwords_Size1)]
    # contains the Master list, and the word we are going to reduce it down to if we find a match
    new_Tuple = ("project", new_Syllogisms_MasterList)
    syllogisms.append(new_Tuple)

    # List of the words syllogistic to XXX, including itself, also the number of words of the syllogism
    newwords_Size1 = ["prerequisites", "prerequisite"]
    new_Syllogisms_MasterList = [(1, newwords_Size1)]
    # contains the Master list, and the word we are going to reduce it down to if we find a match
    new_Tuple = ("prerequisite", new_Syllogisms_MasterList)
    syllogisms.append(new_Tuple)

    # List of the words syllogistic to XXX, including itself, also the number of words of the syllogism
    newwords_Size1 = ["your", "yourself", "yours", "your", "yourselves"]
    new_Syllogisms_MasterList = [(1, newwords_Size1)]
    # contains the Master list, and the word we are going to reduce it down to if we find a match
    new_Tuple = ("your", new_Syllogisms_MasterList)
    syllogisms.append(new_Tuple)

    # List of the words syllogistic to XXX, including itself, also the number of words of the syllogism
    newwords_Size1 = ["who", "whom"]
    new_Syllogisms_MasterList = [(1, newwords_Size1)]
    # contains the Master list, and the word we are going to reduce it down to if we find a match
    new_Tuple = ("who", new_Syllogisms_MasterList)
    syllogisms.append(new_Tuple)

    # List of the words syllogistic to XXX, including itself, also the number of words of the syllogism
    newwords_Size1 = ["make", "makes", "made", "making"]
    new_Syllogisms_MasterList = [(1, newwords_Size1)]
    # contains the Master list, and the word we are going to reduce it down to if we find a match
    new_Tuple = ("make", new_Syllogisms_MasterList)
    syllogisms.append(new_Tuple)

    # List of the words syllogistic to XXX, including itself, also the number of words of the syllogism
    newwords_Size1 = ["take", "takes", "took", "taking", "taken"]
    new_Syllogisms_MasterList = [(1, newwords_Size1)]
    # contains the Master list, and the word we are going to reduce it down to if we find a match
    new_Tuple = ("take", new_Syllogisms_MasterList)
    syllogisms.append(new_Tuple)

    # List of the words syllogistic to XXX, including itself, also the number of words of the syllogism
    newwords_Size1 = ["answer", "answered", "answering", "answerable"]
    new_Syllogisms_MasterList = [(1, newwords_Size1)]
    # contains the Master list, and the word we are going to reduce it down to if we find a match
    new_Tuple = ("answer", new_Syllogisms_MasterList)
    syllogisms.append(new_Tuple)

    # List of the words syllogistic to XXX, including itself, also the number of words of the syllogism
    newwords_Size1 = ["try", "tried", "trying", "tries"]
    new_Syllogisms_MasterList = [(1, newwords_Size1)]
    # contains the Master list, and the word we are going to reduce it down to if we find a match
    new_Tuple = ("try", new_Syllogisms_MasterList)
    syllogisms.append(new_Tuple)

    # Syllogistic Ends ----------------------------------------------------------------------------------------

    syllogisms_2 = []

    wordNetEntree = ["talk", "discuss", "tell", "contact", "communicate", "reach"]
    new_Syllogisms_WordNet = [(1, wordNetEntree)]
    new_WordNet_Tuple = ("communicate", new_Syllogisms_WordNet)
    syllogisms_2.append(new_WordNet_Tuple)

    wordNetEntree = ["course", "class"]
    new_Syllogisms_WordNet = [(1, wordNetEntree)]
    new_WordNet_Tuple = ("class", new_Syllogisms_WordNet)
    syllogisms_2.append(new_WordNet_Tuple)

    # wordNetEntree = ["course", "class"]
    # wordNetList.append(wordNetEntree)

    # Tokenized words are the base words that are expanded upon to form more complex varieties of the token
    # ie. the word causality vs casualty
    # TOKENIZE WORD -------------------------------------------------------------------------------------------
    def tokenize(word):
        # handles a word ending with pluralization 's
        if word[-2:] == "'s":
            word = word[:-2]
        # handles a word ending with s
        # if(len(word) > 2):
        #     if(word.endswith("ss")):
        #         word = word
        #     elif(word.endswith("s")):
        #         word = word[:-1]
        # handles a word ending with ies

        return word
    # TOKENIZE END -------------------------------------------------------------------------------------------

    # /////////////////////////////////////////////////////////////////////////////////////////////////////////
    # ||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
    # \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    def addWord(inputWord):
        if inputWord in training_data:
            labelList = training_data.get(inputWord)
            i = 0
            labelInList = False
            while i < len(labelList) and labelInList is False:
                labelTuple = labelList[i]
                if (label == labelTuple[0]):
                    labelInList = True
                    labelTuple[1] = labelTuple[1] + 1
                i = i + 1
            if labelInList is False:
                newLabelTuple = [label, 1]
                labelList.append(newLabelTuple)
            training_data[inputWord] = labelList
            # if label not in labelList:
            #     labelList.append(label)
            #
            #     # reAdd the new label-list back into the dictionary
            #     training_data[word] = labelList
        else:
            # We have not seen this word before, we create
            # its list, and assign it the first label
            my_list = []
            newLabelTuple = [label, 1]
            my_list.append(newLabelTuple)

            # we now add the new word, list combination to the dictionary
            training_data.update({inputWord: my_list})

    def addWordImproved(inputWord):
        if inputWord in training_data:
            labelList = training_data.get(inputWord)
            i = 0
            labelInList = False
            while i < len(labelList) and labelInList is False:
                labelTuple = labelList[i]
                if (label == labelTuple[0]):
                    labelInList = True
                    labelTuple[1] = labelTuple[1] + 1
                i = i + 1
            if labelInList is False:
                newLabelTuple = [label, 1]
                labelList.append(newLabelTuple)
            training_data[word] = labelList
        else:
            # SEE IF WE CAN FIND A CLOSE ENOUGH BEFORE GIVING UP

            # check if identical match
            # or if close enough

            # get list of all words in training data
            allSavedwords = sorted(training_data.keys())

            closeEnoughwasFound = False

            # iterate through the list
            for otherword in allSavedwords:

                if closeEnough(inputWord, otherword) is True:
                    closeEnoughwasFound = True
                    labelList = training_data.get(otherword)
                    i = 0
                    labelInList = False
                    while i < len(labelList) and labelInList is False:
                        labelTuple = labelList[i]
                        if (label == labelTuple[0]):
                            labelInList = True
                            labelTuple[1] = labelTuple[1] + 1
                        i = i + 1
                    if labelInList is False:
                        newLabelTuple = [label, 1]
                        labelList.append(newLabelTuple)
                    sizeTuple = getSmallerLargeTuple(inputWord, otherword)
                    smallerWord = sizeTuple[0]
                    #print("popping: " +otherword +", replacing with: " +smallerWord)
                    training_data[smallerWord] = training_data.pop(otherword)
                    #training_data[otherword] = labelList
            if(closeEnoughwasFound is False):
                # We have not seen this word before, we create
                # its list, and assign it the first label
                my_list = []
                newLabelTuple = [label, 1]
                my_list.append(newLabelTuple)
                # we now add the new word, list combination to the dictionary
                training_data.update({inputWord: my_list})



    # This is the loop that goes though the entire set of questions/labels provided to train the agent
    for row in train_test_questions:

        label = row[0]
        training_question = row[1]

        # make a master-list of labels
        if "LabelMasterList" in training_data:
            allLabels = training_data.get("LabelMasterList")
            if(label not in allLabels):
                allLabels.append(label)
                training_data["LabelMasterList"] = allLabels
        else:
            new_list = []
            new_list.append(label)
            training_data.update({"LabelMasterList": new_list})

        # Break training_question into a set of words
        split_Question = training_question.split()

        # make a label-list for each word
        for index, word in enumerate(split_Question):

            # Tokenizes the word ------------------------------------------------------------------------
            word = tokenize(word)
            # Tokenizes end -----------------------------------------------------------------------------

            # Checks if the word is on the Sanitize List ------------------------------------------------
            isSantizied = isSantized(word)
            # Sanitize end ------------------------------------------------------------------------------

            # Checks if the word is on the Syllogistic List
            # -------------------------------------------------------------------------------------------
            sylloTuple = isSyllogism(word, 1, syllogisms)
            if(sylloTuple[0] == True):
                word = sylloTuple[1]
            # -------------------------------------------------------------------------------------------
            # Checks if the word is on the Syllogistic List
            # -------------------------------------------------------------------------------------------
            sylloTuple = isSyllogism(word, 1, syllogisms_2)
            if(sylloTuple[0] == True):
                word = sylloTuple[1]
            # -------------------------------------------------------------------------------------------

            #word = stem(word)

            if(isSantizied is False):
                addedAlready = False
                if(addedAlready is False):
                    #addWord(word)
                    addWordImproved(word)




    # your training code should create rules that your classifier can use.
    # store those rules in training_data
    return training_data


def main(argv):
    """
        This is your test main. This main WILL NOT be used by the autograder.
        When grading your agent, we will call _train_agent() and _train_agent() from our autograder.
        DO NOT MAKE ANY CHANGES IN THIS FUNCTION THAT ARE REQUIRED BY YOUR AGENT TO FUNCTION.
    """
    print(__doc__)

    train_test_filename = argv[0]
    training_questions = []
    test_questions = []
    header = True
    print("Opening test file: " + train_test_filename)
    try:
        with open(train_test_filename, "r", encoding='ascii', errors='backslashreplace') as data:
            for line in data:
                if header:
                    header = False
                    continue
                line = line.split(',')
                training_questions.append([line[0].lower().strip(), line[1].lower().strip()])
                test_questions.append([line[0].lower().strip(), line[2].lower().strip()])
    except IOError as err:
        print("Failure opening or reading test questions filename: " + str(err))
        sys.exit(-1)


    print("Training")
    training_data = _train_agent(training_questions)
    jw_adapter = TestAdapter(training_data)
    print("Testing")
    total_questions = 0
    correct_answers = 0
    results = {}
    for row in test_questions:
        label = row[0]
        test_question = row[1]
        result_dict = jw_adapter.ask_question(test_question)
        del result_dict['question']
        result_label = list(result_dict.keys())[0]
        print(test_question+" -> "+label+" -> "+result_label)
        results.update({'test_question':test_question, 'label':label, 'result_label':result_label})
        total_questions += 1
        if label == result_label:
            correct_answers += 1
    print("results")
    print("Total Questions: "+str(total_questions))
    print("Correct Answers: "+str(correct_answers))
    sys.exit(0)

if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))

