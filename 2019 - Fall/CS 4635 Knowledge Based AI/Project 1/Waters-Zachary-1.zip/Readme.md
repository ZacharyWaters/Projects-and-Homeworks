The code included in this project is limited to StudentAgent.py, all the project files are in the Project1 folder
