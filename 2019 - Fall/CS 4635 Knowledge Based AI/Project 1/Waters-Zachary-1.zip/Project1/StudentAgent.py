"""
ADD YOUR CODE HERE

Please read project directions before importing anything
"""


import common


class StudentAgent:

    def __init__(self, verbose):
        self._verbose = verbose
        # TODO: Add your init code here
        return

    # takes in list of words, returns question_object and data_requested
    def input_output(self, word_list):
        #print(word_list) # for debugging only

        # TODO: Add your code here
        from random import randint

        def RepresentsInt(s):
            try:
                int(s)
                return True
            except ValueError:
                return False

        def PrintStuff(input1, input2):
            print(input1)
            print(input2)
            print("")

        def getNextXwordsandConjoin(list, startIndex, nextX):
            returnWord = ""
            if(nextX <= 0):
                return list[startIndex]
            else:
                for i in range(nextX):
                    if(i == 0):
                        returnWord = returnWord + list[startIndex + i]
                    else:
                        returnWord = returnWord +" "+ list[startIndex + i]
            return returnWord


        def zerolistmaker(n):
            listofzeroes = [0] * n
            return listofzeroes

        def returnRandomElement(ramdomArray):
            import random
            randomElement = random.choice(ramdomArray)
            return randomElement


        def getNextOpenSlot(stringRep2, start):
            if(start == len(stringRep2) - 1):
                return (False, -1, len(stringRep2) - 1)
            i = start;
            brakes = False
            foundSlot = False
            slotIndex = -1
            slotEndIndex = -1
            while i < len(stringRep2) and brakes != True:
                slotValue = stringRep2[i]
                if(slotValue == 0):
                    brakes = True;
                    foundSlot = True
                    slotIndex = i
                else:
                    i = i + 1
            if(foundSlot == True):
                brakes2 = False
                j = i
                slotEndIndex = len(stringRep2) - 1
                while j < len(stringRep2) and brakes2 != True:
                    slotValue = stringRep2[j]
                    if (slotValue != 0):
                        brakes2 = True;
                        slotEndIndex = j;
                    j = j + 1
            return(foundSlot, slotIndex, slotEndIndex)

        def checkSlotContains(list, lookingfor2, slotStart, slotEnd):
            if(slotStart > slotEnd):
                return (False, -1, slotEnd)
            for i in range(len(lookingfor2)):
                tuple = lookingfor2[i]
                matchLength = tuple[0]
                if(sRep[slotStart] == 0):
                    if(slotStart + matchLength <= slotEnd + 1):
                        ourWords = getNextXwordsandConjoin(list, slotStart, matchLength)
                        if(ourWords in tuple[1]):
                            return (True, slotStart, matchLength)
            return checkSlotContains(list, lookingfor2, slotStart + 1, slotEnd)


        def findAndMark(stringRep1, list, lookingfor, remainingUnknowns):
            i = 0
            brakes = False
            madeAchange = False
            while(i <= len(stringRep1) and brakes != True):
                nextSlot = getNextOpenSlot(stringRep1, i)
                if ( nextSlot[0] == True and brakes != True):
                    slotStart = nextSlot[1]
                    slotEnd = nextSlot[2]
                    wordsToFind = lookingfor[1]
                    containsTuple = checkSlotContains(list, wordsToFind, slotStart, slotEnd)
                    if(containsTuple[0] == True):
                        k = containsTuple[1]
                        while k <= containsTuple[1] + containsTuple[2] - 1:
                            if(madeAchange == False):
                                madeAchange = True
                            stringRep1[k] = lookingfor[0]
                            remainingUnknowns = remainingUnknowns - 1
                            k = k + 1
                        i = containsTuple[1] + containsTuple[2] - 1
                    else:
                        i = slotEnd
                else:
                    brakes = True
            return [stringRep1, madeAchange, remainingUnknowns]

        def findAndMarkNumbers(stringRep3, input_list, input_list_prov_Length, remainingUnknowns):
            iterator = 0
            changesMade = False;
            while iterator < input_list_prov_Length:
                value = input_list[iterator]
                if(RepresentsInt(value)):
                    stringRep3[iterator] = -1
                    changesMade = True;
                    remainingUnknowns = remainingUnknowns - 1
                iterator = iterator + 1;
            return [stringRep3, changesMade, remainingUnknowns]

        def findLastZeroIndex(stringRep3):
            iterator = 0
            fLength = len(stringRep3)
            while iterator < fLength:
                value = stringRep3[iterator]
                if(value == 0):
                    return iterator;
                iterator = iterator + 1;

        def findLastWhenType(stringRep5, wordList3, dataRequested2):
            typeIterator = 0
            duedateCount = 0
            releaseDateCount = 0
            fLength = len(wordList3)
            while typeIterator < fLength:
                pointValue = stringRep5[typeIterator]
                if(pointValue > 20 and pointValue < 30):
                    duedateCount = duedateCount + 1;
                if(pointValue > 30 and pointValue < 40):
                    releaseDateCount = releaseDateCount + 1;
                typeIterator = typeIterator + 1;
            if(duedateCount > releaseDateCount):
                dataRequested2 = "DUEDATE"
            elif(duedateCount < releaseDateCount):
                dataRequested2 = "RELEASEDATE"
            else:
                # THIS IS A TIE STATE, YOU NEED TO FIGURE OUT HOW TO HANDLE THIS
                dataRequested2 = returnRandomElement(("DUEDATE", "RELEASEDATE"))
            return dataRequested2

        def findLastHowType(stringRep6, wordList4, dataRequested3):
            typeIterator = 0
            howTimeCounter = 0
            howDurationCounter = 0
            howReleaseCounter = 0
            howWeightCounter = 0
            fLength = len(wordList4)
            while typeIterator < fLength:
                pointValue = stringRep6[typeIterator]
                if(pointValue > 20 and pointValue < 30):
                    howDurationCounter = howDurationCounter + 1;
                if(pointValue > 30 and pointValue < 40):
                    howReleaseCounter = howReleaseCounter + 1;
                if(pointValue > 40 and pointValue < 50):
                    howWeightCounter = howWeightCounter + 1;
                if (pointValue > 50 and pointValue < 60):
                        howTimeCounter = howTimeCounter + 1;
                typeIterator = typeIterator + 1;

            howProccessCheck = stringRep6[1]
            if not(howProccessCheck > 50 and howProccessCheck < 60) and not(howProccessCheck > 40 and howProccessCheck < 50):
                #print("got here")
                dataRequested3 = "PROCESS"
                return dataRequested3

            if(howDurationCounter > howReleaseCounter) and (howDurationCounter > howWeightCounter):
                dataRequested3 = "DURATION"
            elif(howReleaseCounter > howDurationCounter and howReleaseCounter > howWeightCounter):
                dataRequested3 = "RELEASEDATE"
            elif(howWeightCounter > howDurationCounter and howWeightCounter > howReleaseCounter):
                dataRequested3 = "WEIGHT"
            elif (howTimeCounter > howWeightCounter):
                #dataRequested3 = returnRandomElement(("DURATION", "RELEASEDATE"))
                dataRequested3 = "DURATION"
            elif (howWeightCounter > howTimeCounter):
                dataRequested3 = "WEIGHT"
            else:
                dataRequested3 = returnRandomElement(("DURATION", "RELEASEDATE", "WEIGHT"))
            return dataRequested3

        def findLastWhatType(stringRep7, wordList5, dataRequested4):
            typeIterator = 0
            whatDueCounter = 0
            whatReleaseCounter = 0
            whatWeightCounter = 0
            whatDurationCounter = 0
            whatProcessCounter = 0
            whatTimeCounter = 0
            f1Length = len(wordList5)
            while typeIterator < f1Length:
                pointValue = stringRep7[typeIterator]
                if(pointValue > 20 and pointValue < 30):
                    whatDueCounter = whatDueCounter + 1;
                if(pointValue > 30 and pointValue < 40):
                    whatReleaseCounter = whatReleaseCounter + 1;
                if(pointValue > 40 and pointValue < 50):
                    whatWeightCounter = whatWeightCounter + 1;
                if(pointValue > 50 and pointValue < 60):
                    whatDurationCounter = whatDurationCounter + 1;
                if(pointValue > 60 and pointValue < 70):
                    whatProcessCounter = whatProcessCounter + 1;
                if (pointValue == 82):
                    whatTimeCounter = whatTimeCounter + 1;
                typeIterator = typeIterator + 1;
            if(whatDueCounter > whatReleaseCounter) and (whatDueCounter > whatWeightCounter) and \
                    (whatDueCounter > whatDurationCounter) and (whatDueCounter > whatProcessCounter):
                dataRequested4 = "DUEDATE"
            elif(whatReleaseCounter > 0):
                dataRequested4 = "RELEASEDATE"
            elif(whatWeightCounter > whatDueCounter) and (whatWeightCounter > whatReleaseCounter) and \
                    (whatWeightCounter > whatDurationCounter) and (whatWeightCounter > whatProcessCounter):
                dataRequested4 = "WEIGHT"
            elif(whatReleaseCounter > whatDueCounter) and (whatReleaseCounter > whatWeightCounter) and \
                    (whatReleaseCounter > whatDurationCounter) and (whatReleaseCounter > whatProcessCounter):
                dataRequested4 = "RELEASEDATE"
            elif(whatDurationCounter > whatDueCounter) and (whatDurationCounter > whatWeightCounter) and \
                    (whatDurationCounter > whatReleaseCounter) and (whatDurationCounter > whatProcessCounter):
                dataRequested4 = "DURATION"
            elif (whatProcessCounter > whatDurationCounter) and (whatProcessCounter > whatWeightCounter) and \
                    (whatProcessCounter > whatReleaseCounter) and (whatProcessCounter > whatDueCounter):
                dataRequested4 = "PROCESS"
            else:
                if(whatTimeCounter > 0):
                    dataRequested4 = returnRandomElement(("DURATION", "RELEASEDATE", "DUEDATE"))
                else:
                    dataRequested4 = "PROCESS"
            return dataRequested4



        def findLastType(stringRep4, wordList2, dataRequested1):
            if(wordList2[0] == "when"):
                dataRequested1 = findLastWhenType(stringRep4, wordList2, dataRequested1)
            if(wordList2[0] == "how"):
                dataRequested1 = findLastHowType(stringRep4, wordList2, dataRequested1)
            if (wordList2[0] == "what"):
                dataRequested1 = findLastWhatType(stringRep4, wordList2, dataRequested1)
            return dataRequested1



        def setupToFinish1(mysRep, myuNum, wordList, questionObject, data_requested):
            nounIndex = findLastZeroIndex(sRep)
            questionObject = wordList[nounIndex]
            wordListLength = len(wordList)
            if (nounIndex < wordListLength - 1):
                if (mysRep[nounIndex + 1] == -1):
                    questionObject = questionObject + " " + wordList[nounIndex + 1]
                if (mysRep[nounIndex - 1] == -2):
                    questionObject = wordList[nounIndex - 1] + " " + questionObject
            data_requested = findLastType(mysRep, wordList, data_requested)
            #print(mysRep)
            #PrintStuff(data_requested, questionObject)
            return (questionObject, data_requested)

        def findRemainingObjectSimple(sRep, wordlist9, uNum):
            # GETS ANY SUBJECT THAT HAS A NUMBER IN FRONT OR AFTER IT
            subjectIterator = 0
            wordLLength = len(wordlist9)
            while subjectIterator < wordLLength:
                if(sRep[subjectIterator] == -2):
                    result = wordlist9[subjectIterator] + " " + wordlist9[subjectIterator + 1]
                    return (True, result)
                if(sRep[subjectIterator] == -1):
                    result = wordlist9[subjectIterator - 1] + " " + wordlist9[subjectIterator]
                    return (True, result)
                subjectIterator = subjectIterator + 1
            return(False, "")

        def twoZeroesAdjacent(sRep):
            # GETS ANY SUBJECT THAT HAS A NUMBER IN FRONT OR AFTER IT
            zeroIterator = 0
            wordLLength = len(sRep)
            firstZero = -1;
            secondZero = -1
            while zeroIterator < wordLLength:
                if (sRep[zeroIterator] == 0 and firstZero == -1):
                    if (zeroIterator < wordLLength - 1):
                        if (sRep[zeroIterator + 1] == 0):
                            return (True, zeroIterator, zeroIterator + 1)
                        else:
                            firstZero = zeroIterator
                if(sRep[zeroIterator] == 0 and firstZero != -1):
                    secondZero = zeroIterator
                zeroIterator = zeroIterator + 1
            return (False, firstZero, secondZero)

        def getMoreLikelyFromTwoSplit(sRep, indexOne, indexTwo, wordList):
            firstScore = 0
            secondScore = 0
            SrepLength = len(sRep)

            if (sRep[indexOne - 1] == 5):
                firstScore = firstScore + 3

            if (sRep[indexTwo - 1] == 5):
                secondScore = secondScore + 3

            if (sRep[indexOne - 1] == -3):
                firstScore = firstScore + 4

            if (sRep[indexTwo - 1] == -3):
                secondScore = secondScore + 4

            if(sRep[indexOne - 1] == 3):
                if(indexOne - 2 >= 0):
                    if (sRep[indexOne - 2] == 5):
                        firstScore = firstScore + 5

            if(sRep[indexTwo - 1] == 3):
                if(indexTwo - 2 >= 0):
                    if (sRep[indexTwo - 2] == 5):
                        secondScore = secondScore + 5

            if(indexOne + 1 < SrepLength):
                if(sRep[indexOne + 1] == 2):
                        firstScore = firstScore + 4

            if(indexTwo + 1 < SrepLength):
                if(sRep[indexTwo + 1] == 2):
                        secondScore = secondScore + 4



            if(firstScore > secondScore):
                return (True, wordList[indexOne])
            elif(secondScore > firstScore):
                return (True, wordList[indexTwo])
            else:
                x = randint(1, 2)
                if(x == 1):
                    return (False, wordList[indexOne])
                else:
                    return (False, wordList[indexTwo])

        def ifRepHasPattern(sRep, wordList, pattern):
            iterator = 0
            wordLLength = len(sRep)
            patternLength = len(pattern)
            stringTotal = ""
            while iterator < wordLLength:
                if(sRep[iterator] == pattern[0]):
                    if(sRep[iterator] == 0):
                        stringTotal = wordList[iterator]
                    if(iterator + 1 + patternLength - 1 <=  wordLLength):
                        patternCounter = 1
                        brakes = False
                        while patternCounter < patternLength and brakes != True:
                            if pattern[patternCounter] != sRep[iterator + patternCounter]:
                                brakes = True;
                            if pattern[patternCounter] == sRep[iterator + patternCounter]:
                                if (sRep[iterator + patternCounter] == 0):
                                    if stringTotal == "":
                                        stringTotal = word_list[iterator + patternCounter]
                                    else:
                                        stringTotal = stringTotal + " " + word_list[iterator + patternCounter]
                            patternCounter = patternCounter + 1
                        if brakes == False:
                            return (True, stringTotal)

                iterator = iterator + 1
            return (False, stringTotal)

        def updateUnknownCount(sRep):
            count = 0
            for value in sRep:
                if value == 0:
                    count = count + 1;
            return count







        # Default Values
        _question_object = "Project"
        _data_requested = "DUEDATE"


        wordList_Length = len(word_list)

        # This Checks if the Question is longer than 8 characters
        # if(wordList_Length > 8):
        #     _question_object = "Invalid Question, more than 8 words"
        #     _data_requested = "DUEDATE"
        #     PrintStuff(_data_requested,_question_object)
        #     return _question_object, _data_requested

        # _____________________________________
        #              Being
        # _____________________________________
        toBeFormsSize1 = {'be', 'is','was','will','were','are', 'been'}
        toBeFormsSize2 = ['will be', 'had been', 'has been']
        toBeForms = [(2,toBeFormsSize2),(1,toBeFormsSize1)]
        holderToBeForms = (2,toBeForms)

        # _____________________________________
        #              ARTICLES
        # _____________________________________
        articleFormsSize1 = {'the', "a", "an"}
        articleForms = [(1,articleFormsSize1)]
        holderArticleForms = (3,articleForms)

        # _____________________________________
        #              MODAL VERBS
        # _____________________________________
        modalVerbForms1 = {'can', 'should','could','would', 'must', 'need', 'gotta'}
        modalVerbForms2 = {'should have','would have','could have', 'have to', 'got to', 'ought to'}
        modalVerbForms3 = {'be required to', 'have got to', 'need to get', 'be supposed to', 'have to get',
                           'have to have'}
        modalVerbForms = [(3,modalVerbForms3),(2,modalVerbForms2),(1,modalVerbForms1)]
        holderModalVerbForms = (4, modalVerbForms)

        # _____________________________________
        #              FOR SYNONYMS
        # _____________________________________
        forSynoForms1 = {'for', 'of', 'about', 'in'}
        forSynoForms3 = {'with respect to', 'in terms of'}
        forSynoForms = [(3, forSynoForms3), (1, forSynoForms1)]
        holderForSynoForms = (5, forSynoForms)

        # _____________________________________
        #              Doing SYNONYMS
        # _____________________________________
        doSynoForms1 = {'do', 'does', 'did', 'doing', 'done'}
        doSynoForms2 = {'to do'}
        doSynoForms = [(2, doSynoForms2), (1, doSynoForms1)]
        holderDoForms = (6, doSynoForms)

        # _____________________________________
        #              Negations
        #           Should come before
        #           all the other defaults
        # _____________________________________
        negationForms1 = {'cannot'}
        negationForms2 = {'will not','can not','do not','could not','has not','is not','should not','was not','did not',
                        'does not','are not','had not'}
        negationForms = [(2, negationForms2), (1, negationForms1)]
        holderNegationForms = (7, negationForms)

        # _____________________________________
        #            personal Pronouns
        # _____________________________________
        persProForms1 = {'i', 'we'}
        persProForms = [(1, persProForms1)]
        holderpersProForms = (8, persProForms)

        # _____________________________________
        #            FINAL  Prepositions
        # _____________________________________
        prepositionsForms1 = {'aboard','about','above','across','after','against','along','amid','among','anti','around',
                         'as','at','before','behind','below','beneath','beside','besides','between','beyond','but',
                         'by','concerning','considering','despite','down','during','except','excluding','following',
                         'from','including','inside','into','like','minus','near','off','on','onto',
                         'opposite','outside','over','past','per','plus','regarding','round','save','since',
                         'than','through','throughout','to','toward','towards','under','underneath','unlike','until',
                         'up','upon','versus','via','with','within','without', 'there'}
        prepositionsForms = [(1, prepositionsForms1)]
        holderpersPrepositionsForms = (9, prepositionsForms)

        # _____________________________________
        #              ORDINALS
        # _____________________________________
        ordinalsForms1 = {'first', 'second', 'third', 'fourth', 'fifth', 'sixth', 'seventh', 'eighth', 'ninth'
                    , 'tenth','eleventh', 'twelfth','thirteenth', 'fourteenth', 'fifteenth', 'sixteenth',
                    'seventeenth', 'eighteenth', 'nineteenth', 'twentieth', 'last','1st','2nd','3rd','4th','5th','6th',
                          '7th','8th','9th','10th','11th','12th','13th','14th','15th','16th','17th','18th','19th','20th'}
        ordinalsForms = [(1,ordinalsForms1)]
        holderOrdinalsForms = (-2, ordinalsForms)

        # _____________________________________
        #          Possessive Determiners
        # _____________________________________
        possDetForms1 = {'my', 'your', 'his', 'her', 'its', 'our', 'their'}
        possDetForms = [(1,possDetForms1)]
        holderPossDetForms = (-3, possDetForms)

        # _____________________________________
        #              NUMBER STRINGS
        # _____________________________________
        numberStringsForms1 = {"zero", "one", "two", "three", "four", "five", "six", "seven", "eight",
            "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen",
            "sixteen", "seventeen", "eighteen", "nineteen", "twenty"}
        numberStringsForms = [(1,numberStringsForms1)]
        holderNumberStringsForms = (-1, numberStringsForms)

        # ==========================================================================================================
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        # ==========================================================================================================

        # _____________________________________
        #              DUE SYNONYMS
        #              Past Tense
        # _____________________________________
        dueSynoForms1 = {'due', 'owed', 'receivable', 'payable'}
        dueSynoForms = [(1,dueSynoForms1)]
        holderDueSynoForms = (21, dueSynoForms)

        # _____________________________________
        #              SUBMIT SYNONYMS
        #        verb like present tense
        # _____________________________________
        submitSynoForms1 = {'submit','deliver','submitted','delivered'}
        submitSynoForms2 = {'turn in','send in', 'hand in'}
        submitSynoForms = [(2,submitSynoForms2),(1,submitSynoForms1)]
        holderSubmitSynoForms = (22, submitSynoForms)

        # _____________________________________
        #              SUBMITED SYNONYMS
        #        verb like, past and present
        # _____________________________________
        submitedSynoForms1 = {'submitted','delivered'}
        submitedSynoForms2 = {'turned in','sent in', 'handed in'}
        submitedSynoForms = [(2,submitedSynoForms2),(1,submitedSynoForms1)]
        holderSubmitedSynoForms = (23, submitedSynoForms)

        # _____________________________________
        #              DEADLINE SYNONYMS
        #                 noun like
        #        must run before DUE because
        #        due subset of this
        # _____________________________________
        deadlineSynoForms1 = {'deadline','cutoff','end','conclusion', 'submission',  'complete', 'finish'}
        deadlineSynoForms2 = {'time limit', 'target date', 'target time','target day','target period',
                              'due date', 'due time','due day','due period','expiry date', 'expiry time','expiry day',
                              'expiry period','end date', 'end time','end day','end period','finish date',
                              'finish time','finish day','finish period','submission date', 'submission time',
                              'submission day','submission period', 'expiration date', 'expiration day',
                              'expiration time', 'deadline date', 'deadline day'}
        deadlineSynoForms = [(2, deadlineSynoForms2), (1, deadlineSynoForms1)]
        holderDeadlineSynoForms = (24, deadlineSynoForms)

        # _____________________________________
        #          RELEASED SYNONYMS
        #         verb like Past Tense
        # _____________________________________
        releasedSynoForms1 = {'released','announced','issued','published','disseminated','distributed',
                              'posted','opened','publicized', 'get', 'receive', 'acquire', 'obtain', 'given'}
        releasedSynoForms2 = {'given out','made public','made available'}
        releasedSynoForms = [(2, releasedSynoForms2), (1, releasedSynoForms1)]
        holderReleasedSynoForms = (31, releasedSynoForms)

        # _____________________________________
        #          RELEASE SYNONYMS
        #            present Tense
        # _____________________________________
        releaseSynoForms1 = ['publicize','release','issue','publish','announce','post','disseminate','distribute',
                             'open', 'start', 'begin', 'available']
        releaseSynoForms2 = ['shall publish','make public','make available']
        releaseSynoForms = [(2, releaseSynoForms2), (1, releaseSynoForms1)]
        holderReleaseSynoForms= (32, releaseSynoForms)

        # _____________________________________
        #          RELEASE DATE SYNONYMS
        #                 Nouns
        # _____________________________________
        releaseDateSynoForms2 = ['release date','announcement date','publication date','issue date','opening date',
                             'issuing date','published date','release day','announcement day','publication day',
                             'issue day','opening day','issuing day','published day','release time','announcement time',
                             'publication time','issue time','opening time','issuing time','published time',
                             'release period','announcement period','publication period','issue period',
                             'opening period','issuing period','published period']
        releaseDateSynoForms = [(2, releaseDateSynoForms2)]
        holderReleaseDateSynoForms = (33, releaseDateSynoForms)

        # _____________________________________
        #          HOW Weight SYNONYMS
        # _____________________________________
        howWeightSynoForms1 = ['much', 'little', 'large', 'amount', 'heavily']
        howWeightSynoForms = [(1, howWeightSynoForms1)]
        holderHowWeightSynoForms = (41, howWeightSynoForms)

        # _____________________________________
        #          HOW Duration SYNONYMS
        # _____________________________________
        howDurationSynoForms1 = ['long', 'short', 'soon', 'quickly', 'fast', 'late', 'till', 'time']
        howDurationSynoForms2 = ['much longer', 'much time', 'long have', 'many days','many weeks', 'long till',
                                 'short till']
        howDurationSynoForms = [(2, howDurationSynoForms2),(1, howDurationSynoForms1)]
        holderHowDurationSynoForms = (52, howDurationSynoForms)

        # _____________________________________
        #      Weight Attributes SYNONYMS
        #                Nouns
        # _____________________________________
        weightAtributeSynoForms1 = ['score','weight','weigh','percentage', 'worth', 'cost', 'value', 'grade', 'scoring',
                                    'rating', 'rank', 'degree', 'tier', 'portion', 'proportion', 'ratio', 'measure',
                                    'weighted', 'fraction', 'average']
        weightAtributeSynoForms = [(1, weightAtributeSynoForms1)]
        holderWeightAtributeSynoForms1 = (43, weightAtributeSynoForms)

        # _____________________________________
        #        WHAT Duration SYNONYMS
        #               NOUNS
        # _____________________________________
        whatDurationSynoForms1 = ['duration', 'period', 'timespan', 'timeframe']
        whatDurationSynoForms2 = ['time duration', 'time period', 'time length', 'time span', 'term length',
                                  'time interval', 'time frame', 'time remaining']
        whatDurationSynoForms3 = ['period of time', 'length of time', 'number of days', 'amount of time',
                                  'interval of time']
        whatDurationSynoForms = [(3, whatDurationSynoForms3),(2, whatDurationSynoForms2), (1, whatDurationSynoForms1)]
        holderWhatDurationSynoForms = (51, whatDurationSynoForms)

        # _____________________________________
        #        WHAT PROCESS SYNONYMS
        #               NOUNS
        # _____________________________________
        whatProcessSynoForms1 = ['location', 'specification', 'specifications', 'description', 'descriptions',
                                 'detail', 'requirement', 'requirements', 'details', 'rules', 'conditions',
                                 'prerequisite', 'provisions', 'necessities', 'place']
        whatProcessSynoForms = [(1, whatProcessSynoForms1)]
        holderWhatProcessSynoForms = (61, whatProcessSynoForms)

        # _____________________________________
        #        verbs to fill SYNONYMS
        #               verbs
        # _____________________________________
        verbFillerSynoForms1 = ['expect', 'download', 'downloaded', 'expected', 'install','installed', 'anticipate',
                                'anticipated', 'upload', 'work', 'working', 'worked', 'contribute', 'remaining', 'left',
                                'available', 'weights', 'scores', 'find', 'locate', 'access', 'turn', 'out']
        verbFillerSynoForms2 = ['have until', 'have left']
        verbFillerSynoForms = [(2, verbFillerSynoForms2), (1, verbFillerSynoForms1)]
        holderVerbFillerSynoForms = (81, verbFillerSynoForms)

        # _____________________________________
        #        what time special fill
        #               verbs
        # _____________________________________
        whatTimeSynoForms1 = ['time', 'date', 'day', 'week', 'period']
        whatTimeSynoForms = [(1, whatTimeSynoForms1)]
        holderWhatTimeSynoForms = (82, whatTimeSynoForms)


        firstWord = word_list[0];
        uNum = wordList_Length
        isChanged = False
        sRep = zerolistmaker(wordList_Length)
        #print(sRep)

        # Sets index 0 for 1 to represent the Question Words
        sRep[0] = 1;
        uNum = uNum - 1

        # ______________WHEN_______________
        # _________________________DUE______
        # _________________________RELEASE__
        if (firstWord == "when"):
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderDeadlineSynoForms, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderReleaseDateSynoForms, uNum)

            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderDueSynoForms,uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderSubmitSynoForms, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderSubmitedSynoForms, uNum)

            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderReleasedSynoForms, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderReleaseSynoForms, uNum)

        # _______________WHERE_______________
        # _________________________PROCESS___
        if(firstWord == "where"):
            _data_requested = "PROCESS"
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderDeadlineSynoForms, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderReleaseDateSynoForms, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderSubmitSynoForms, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderDueSynoForms, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderReleasedSynoForms, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderReleaseSynoForms, uNum)

        # _______________HOW_______________
        # _________________________WEIGHT___
        # _________________________DURATION_
        # _________________________RELEASE_
        if(firstWord == "how"):
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderHowDurationSynoForms, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderHowWeightSynoForms, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderWeightAtributeSynoForms1, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderDeadlineSynoForms, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderDueSynoForms,uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderSubmitSynoForms, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderReleasedSynoForms, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderReleaseSynoForms, uNum)

        # _______________WHAT_______________
        # _________________________DUE______
        # _________________________RELEASE__
        # _________________________WEIGHT___
        # _________________________DURATION_
        if (firstWord == "what"):
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderWhatDurationSynoForms, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderDeadlineSynoForms, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderSubmitSynoForms, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderReleaseDateSynoForms, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderReleasedSynoForms, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderWeightAtributeSynoForms1, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderWhatProcessSynoForms, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderReleaseSynoForms, uNum)


        # GENERIC SEARCHES
        # you should probably call this AFTER finding the "trigger" words

        # GENERIC SEARCH FOR NEGATION TERMS: DON'T, CAN'T, WON'T
        # sRep, isChanged, uNum = findAndMark(sRep, word_list, holderNegationForms, uNum)
        # if(uNum == 1):
        #     _question_object,_data_requested = setupToFinish(sRep, uNum, word_list, _question_object, _data_requested)
        #     return _question_object, _data_requested

        # GENERIC SEARCH FOR BEING TERMS: BE, IS, WAS, WILL
        sRep, isChanged, uNum = findAndMark(sRep, word_list, holderToBeForms, uNum)
        uNum = updateUnknownCount(sRep)
        if(uNum == 1):
            _question_object,_data_requested = setupToFinish1(sRep, uNum, word_list, _question_object, _data_requested)
            return _question_object, _data_requested

        # GENERIC SEARCH FOR ARTICLE TERMS: THE, A, AN
        sRep, isChanged, uNum = findAndMark(sRep, word_list, holderArticleForms, uNum)
        uNum = updateUnknownCount(sRep)
        if(uNum == 1):
            _question_object,_data_requested = setupToFinish1(sRep, uNum, word_list, _question_object, _data_requested)
            return _question_object, _data_requested

        # GENERIC SEARCH FOR MODAL VERBS TERMS: CAN, SHOULD, COULD, WOULD
        sRep, isChanged, uNum = findAndMark(sRep, word_list, holderModalVerbForms, uNum)
        uNum = updateUnknownCount(sRep)
        if(uNum == 1):
            _question_object,_data_requested = setupToFinish1(sRep, uNum, word_list, _question_object, _data_requested)
            return _question_object, _data_requested

        # GENERIC SEARCH FOR NUMBERS: 1, 2, 3, 4 ...
        sRep, isChanged, uNum = findAndMarkNumbers(sRep, word_list, wordList_Length, uNum)
        uNum = updateUnknownCount(sRep)
        if(uNum == 1):
            _question_object,_data_requested = setupToFinish1(sRep, uNum, word_list, _question_object, _data_requested)
            return _question_object, _data_requested

        # GENERIC SEARCH FOR STRING-NUMBERS: ONE, TWO, THREE, FOUR ...
        sRep, isChanged, uNum = findAndMark(sRep, word_list, holderNumberStringsForms, uNum)
        uNum = updateUnknownCount(sRep)
        if(uNum == 1):
            _question_object,_data_requested = setupToFinish1(sRep, uNum, word_list, _question_object, _data_requested)
            return _question_object, _data_requested

        # GENERIC SEARCH FOR ORDINAL-NUMBERS: FIRST, SECOND, THIRD, FOURTH, ...
        sRep, isChanged, uNum = findAndMark(sRep, word_list, holderOrdinalsForms, uNum)
        uNum = updateUnknownCount(sRep)
        if(uNum == 1):
            _question_object,_data_requested = setupToFinish1(sRep, uNum, word_list, _question_object, _data_requested)
            return _question_object, _data_requested

        # GENERIC SEARCH FOR POSSESSIVE NOUNS: MY, OUR, HIS, ...
        sRep, isChanged, uNum = findAndMark(sRep, word_list, holderPossDetForms, uNum)
        uNum = updateUnknownCount(sRep)
        if(uNum == 1):
            _question_object,_data_requested = setupToFinish1(sRep, uNum, word_list, _question_object, _data_requested)
            return _question_object, _data_requested

        # GENERIC SEARCH COMPRISED OF FORMS: FOR, OF, ABOUT, IN
        sRep, isChanged, uNum = findAndMark(sRep, word_list, holderForSynoForms, uNum)
        uNum = updateUnknownCount(sRep)
        if(uNum == 1):
            _question_object,_data_requested = setupToFinish1(sRep, uNum, word_list, _question_object, _data_requested)
            return _question_object, _data_requested

        # GENERIC SEARCH DOING FORMS: DO, DOING, DONE
        sRep, isChanged, uNum = findAndMark(sRep, word_list, holderDoForms, uNum)
        uNum = updateUnknownCount(sRep)
        if(uNum == 1):
            _question_object,_data_requested = setupToFinish1(sRep, uNum, word_list, _question_object, _data_requested)
            return _question_object, _data_requested

        # GENERIC SEARCH PERSONAL PRONOUNS: I, WE
        sRep, isChanged, uNum = findAndMark(sRep, word_list, holderpersProForms, uNum)
        uNum = updateUnknownCount(sRep)
        if(uNum == 1):
            _question_object,_data_requested = setupToFinish1(sRep, uNum, word_list, _question_object, _data_requested)
            return _question_object, _data_requested

        # GENERIC SEARCH PREPOSITIONS: OFF, ON, ONTO
        sRep, isChanged, uNum = findAndMark(sRep, word_list, holderpersPrepositionsForms, uNum)
        uNum = updateUnknownCount(sRep)
        if(uNum == 1):
            _question_object,_data_requested = setupToFinish1(sRep, uNum, word_list, _question_object, _data_requested)
            return _question_object, _data_requested

        # GENERIC SEARCH FILLERS
        sRep, isChanged, uNum = findAndMark(sRep, word_list, holderVerbFillerSynoForms, uNum)
        uNum = updateUnknownCount(sRep)
        if(uNum == 1):
            _question_object,_data_requested = setupToFinish1(sRep, uNum, word_list, _question_object, _data_requested)
            return _question_object, _data_requested

        # GENERIC SEARCH WHAT TIME NOUNS
        sRep, isChanged, uNum = findAndMark(sRep, word_list, holderWhatTimeSynoForms, uNum)
        uNum = updateUnknownCount(sRep)
        if(uNum == 1):
            _question_object,_data_requested = setupToFinish1(sRep, uNum, word_list, _question_object, _data_requested)
            return _question_object, _data_requested

        _data_requested = findLastType(sRep, word_list, _data_requested)
        subject_Tuple = findRemainingObjectSimple(sRep, word_list, uNum)
        if(subject_Tuple[0] == True):
            _question_object = subject_Tuple[1]
            #print(sRep)
            #PrintStuff(_data_requested, _question_object)
            return _question_object, _data_requested

        uNum = updateUnknownCount(sRep)
        # handle double 00 case
        if (uNum == 2):
            doubleZeroTuple = twoZeroesAdjacent(sRep)
            zeroIndexOne = doubleZeroTuple[1]
            zeroIndexTwo = doubleZeroTuple[2]
            if(doubleZeroTuple[0] == True):
                _question_object = word_list[zeroIndexOne] + " " + word_list[zeroIndexTwo]
                #print(sRep)
                #PrintStuff(_data_requested, _question_object)
                return _question_object, _data_requested
        # handle split 0-0 case
            else:
                splitTwoZeroTuple = getMoreLikelyFromTwoSplit(sRep, zeroIndexOne, zeroIndexTwo, word_list)
                if(splitTwoZeroTuple[0] == True):
                    _question_object = splitTwoZeroTuple[1]
                    #print(sRep)
                    #PrintStuff(_data_requested, _question_object)
                    return _question_object, _data_requested


        # _____________________________________
        #            MAX Filler/VERB LIST
        # _____________________________________
        fillerForm1 = {}
        fillerForm = [(1, fillerForm1)]
        holderMaxFillerList = (91, fillerForm)

        # OVERPOWERING SEARCH FOR FILLERS
        sRep, isChanged, uNum = findAndMark(sRep, word_list, holderMaxFillerList, uNum)
        uNum = updateUnknownCount(sRep)



        if (firstWord != "when"):
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderDeadlineSynoForms, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderReleaseDateSynoForms, uNum)

            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderDueSynoForms,uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderSubmitSynoForms, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderSubmitedSynoForms, uNum)

            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderReleasedSynoForms, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderReleaseSynoForms, uNum)

        if(firstWord != "where"):
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderDeadlineSynoForms, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderReleaseDateSynoForms, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderSubmitSynoForms, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderDueSynoForms, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderReleasedSynoForms, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderReleaseSynoForms, uNum)

        if(firstWord != "how"):
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderHowWeightSynoForms, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderHowDurationSynoForms, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderWeightAtributeSynoForms1, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderDeadlineSynoForms, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderDueSynoForms,uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderSubmitSynoForms, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderReleasedSynoForms, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderReleaseSynoForms, uNum)

        if (firstWord != "what"):
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderWhatDurationSynoForms, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderDeadlineSynoForms, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderReleaseDateSynoForms, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderWeightAtributeSynoForms1, uNum)
            sRep, isChanged, uNum = findAndMark(sRep, word_list, holderWhatProcessSynoForms, uNum)

        uNum = updateUnknownCount(sRep)
        # check for single 0
        if (uNum == 1):
            lastZeroIndex2 = findLastZeroIndex(sRep)
            _question_object = word_list[lastZeroIndex2]
            #print(sRep)
            #PrintStuff(_data_requested, _question_object)
            return _question_object, _data_requested

        uNum = updateUnknownCount(sRep)
        # handle double 00 case
        if (uNum == 2):
            doubleZeroTuple = twoZeroesAdjacent(sRep)
            zeroIndexOne = doubleZeroTuple[1]
            zeroIndexTwo = doubleZeroTuple[2]
            if(doubleZeroTuple[0] == True):
                _question_object = word_list[zeroIndexOne] + " " + word_list[zeroIndexTwo]
                #print(sRep)
                #PrintStuff(_data_requested, _question_object)
                return _question_object, _data_requested
        # handle split 0-0 case
            else:
                splitTwoZeroTuple2 = getMoreLikelyFromTwoSplit(sRep, zeroIndexOne, zeroIndexTwo, word_list)
                if (splitTwoZeroTuple2[0] == True):
                    _question_object = splitTwoZeroTuple2[1]
                    #print(sRep)
                    #PrintStuff(_data_requested, _question_object)
                    return _question_object, _data_requested

        # handle 2+ 0 case
        #  5 0 0
        thePattern = (5,0,0)
        isContains, theWord = ifRepHasPattern(sRep, word_list, thePattern)
        if(isContains == True):
            _question_object = theWord
            #print(sRep)
            #PrintStuff(_data_requested, _question_object)
            return _question_object, _data_requested
        #  5 0
        thePattern = (5,0)
        isContains, theWord = ifRepHasPattern(sRep, word_list, thePattern)
        if(isContains == True):
            _question_object = theWord
            #print(sRep)
            #PrintStuff(_data_requested, _question_object)
            return _question_object, _data_requested
        #  5 3 0 0
        thePattern = (5,3,0,0)
        isContains, theWord = ifRepHasPattern(sRep, word_list, thePattern)
        if(isContains == True):
            _question_object = theWord
            #print(sRep)
            #PrintStuff(_data_requested, _question_object)
            return _question_object, _data_requested
        #  5 3 0
        thePattern = (5,3,0)
        isContains, theWord = ifRepHasPattern(sRep, word_list, thePattern)
        if(isContains == True):
            _question_object = theWord
            #print(sRep)
            #PrintStuff(_data_requested, _question_object)
            return _question_object, _data_requested
        #  -3 0 0
        thePattern = (-3,0,0)
        isContains, theWord = ifRepHasPattern(sRep, word_list, thePattern)
        if(isContains == True):
            _question_object = theWord
            #print(sRep)
            #PrintStuff(_data_requested, _question_object)
            return _question_object, _data_requested
        #  -3 0
        thePattern = (-3,0)
        isContains, theWord = ifRepHasPattern(sRep, word_list, thePattern)
        if(isContains == True):
            _question_object = theWord
            #print(sRep)
            #PrintStuff(_data_requested, _question_object)
            return _question_object, _data_requested
        #  0 0 2
        thePattern = (0,0,2)
        isContains, theWord = ifRepHasPattern(sRep, word_list, thePattern)
        if(isContains == True):
            _question_object = theWord
            #print(sRep)
            #PrintStuff(_data_requested, _question_object)
            return _question_object, _data_requested
        #  0 2
        thePattern = (0,2)
        isContains, theWord = ifRepHasPattern(sRep, word_list, thePattern)
        if(isContains == True):
            _question_object = theWord
            #print(sRep)
            #PrintStuff(_data_requested, _question_object)
            return _question_object, _data_requested
        #  22 0 0
        thePattern = (22,0, 0)
        isContains, theWord = ifRepHasPattern(sRep, word_list, thePattern)
        if(isContains == True):
            _question_object = theWord
            #print(sRep)
            #PrintStuff(_data_requested, _question_object)
            return _question_object, _data_requested
        #  22 0
        thePattern = (22,0)
        isContains, theWord = ifRepHasPattern(sRep, word_list, thePattern)
        if(isContains == True):
            _question_object = theWord
            #print(sRep)
            #PrintStuff(_data_requested, _question_object)
            return _question_object, _data_requested
        #  23 0 0
        thePattern = (22,0, 0)
        isContains, theWord = ifRepHasPattern(sRep, word_list, thePattern)
        if(isContains == True):
            _question_object = theWord
            #print(sRep)
            #PrintStuff(_data_requested, _question_object)
            return _question_object, _data_requested
        #  23 0
        thePattern = (22,0)
        isContains, theWord = ifRepHasPattern(sRep, word_list, thePattern)
        if(isContains == True):
            _question_object = theWord
            #print(sRep)
            #PrintStuff(_data_requested, _question_object)
            return _question_object, _data_requested


        # get the last 0 or 00 pair in the sRep
        lastZeroFinder = len(sRep) - 1
        brakes2 = False
        while(lastZeroFinder > 0 and brakes2 != True):
            if(sRep[lastZeroFinder] == 0):
                brakes2 = True
                _question_object = word_list[lastZeroFinder]
            lastZeroFinder = lastZeroFinder - 1;

        #  random
        # x = randint(1, uNum)
        # count = 1;
        # randomZeroCounter = 0;

        #print(sRep)
        #PrintStuff(_data_requested, _question_object)
        return _question_object, _data_requested

